<?php if (array_key_exists($this->iwb->set['iwb_version'],$iwb)):?>
<?php end($iwb); $key = key($iwb);?>
<div class="panel">
  <div class="panel-heading">
    Pembaruan IndoWapBlog
  </div>
  <div class="panel-body">
    <div class="alert alert-danger">
      <p>
        IndoWapBlog v<?=$iwb[$this->iwb->set['iwb_version']]['version']?> <?=($iwb[$this->iwb->set['iwb_version']]['version'] == $iwb[$key]['version'] ? '(versi terbaru) ' : '')?>sudah tersedia.
      </p>
      <p>
        Rilis: <?=format_date(strtotime($iwb[$this->iwb->set['iwb_version']]['updated']))?>
      </p>
      <p>
        Berkas pembaruan: <a href="<?=$iwb[$this->iwb->set['iwb_version']]['file']?>" target="_blank"><?=$iwb[$this->iwb->set['iwb_version']]['file']?></a>
      </p>
    </div>
    <div class="alert alert-info">
      <h3 style="margin-top: 0;">
        Perubahan
      </h3>
      <ul>
        <?php foreach ($iwb[$this->iwb->set['iwb_version']]['changelog'] as $cl):?>
        <li>
          <?=esc_html($cl)?>
        </li>
        <?php endforeach?>
      </ul>
    </div>
    <?php if ($iwb[$this->iwb->set['iwb_version']]['message']):?>
    <div class="alert alert-warning">
        <?=nl2br(esc_html($iwb[$this->iwb->set['iwb_version']]['message']))?>
    </div>
    <?php endif?>
  </div>
  <div class="panel-footer">
    <a class="btn btn-primary pull-left" href="<?=site_url('admin/indowapblog/update')?>">Perbarui</a>
    <a class="btn btn-default pull-right" href="<?=$iwb[$this->iwb->set['iwb_version']]['file']?>" target="_blank">Download</a>
    <div class="clear"></div>
  </div>
</div>
<?php else:?>
<div class="alert alert-success">
    Saat ini kamu menggunakan IndoWapBlog versi terbaru.
</div>
<?php endif?>