<div class="list-group">
  <div class="list-group-item list-group-item-default">
    <h3>
      IndoWapBlog
    </h3>
  </div>
  <a class="list-group-item" href="<?=site_url('admin/indowapblog/update_settings')?>">Pengaturan Pembaruan</a>
  <a class="list-group-item" href="<?=site_url('admin/indowapblog/check_for_update')?>">Periksa Pembaruan</a>
  <a class="list-group-item" href="<?=site_url('admin/indowapblog/install_update')?>">Install Pembaruan</a>
  <a class="list-group-item" href="<?=site_url('admin/indowapblog/update_history')?>">Riwayat Pembaruan</a>
</div>