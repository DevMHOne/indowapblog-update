<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Install_update_206
{
    protected $CI;
    protected $version = '2.0.6';

    public function __construct()
    {
        $this->CI = &get_instance();
    }

    public function install($auto = false)
    {
        $this->CI->db->where('set_key', 'iwb_version')->update('settings', array('set_value' =>
                $this->version));
        rmdir_recursive(APPPATH . 'views/desktop/admin/iwb_update');
        rmdir_recursive(APPPATH . 'views/mobile/admin/iwb_update');
        unlink(__file__);
        if (!$auto)
        {
            $this->CI->session->set_flashdata('alert-success',
                'Installasi pembaruan IndoWapBlog v' . $this->version .
                ' berhasil diselesaikan.');
            redirect('admin/indowapblog');
        }
    }
}
