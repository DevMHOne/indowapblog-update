<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Upload extends IWB_Controller
{
    private $blog = false;

    public function __construct()
    {
        parent::__construct();
        $this->lang->load('panel');
        if (!$this->iwb->is_user)
        {
            $this->session->set_userdata('login_redirect', current_url());
            redirect('site/login');
        }
        $this->load->model('blog_model');
        if (!$blog = $this->blog_model->authorization())
        {
            $this->session->set_flashdata('alert-info', lang('iwb_blog_not_logged_in'));
            redirect('account/blog?redirect_uri=' . urlencode(current_url() . '?' . $this->
                input->server('QUERY_STRING', true)));
        }
        $this->blog = $blog;
        $this->blog->{'url'} = blog_url($blog);
        $this->config->set_item('page_title', lang('panel_files'));
        $this->breadcrumbs->set(lang('iwb_dashboard'), 'dashboard');
    }

    public function index()
    {
        $image_types = image_types();
        $audio_types = array(
            '.mp3',
            '.mid',
            '.amr',
            '.wav',
            '.aac',
            '.m4a',
            );
        $video_types = array(
            '.mp4',
            '.3gp',
            '.mpeg',
            '.avi',
            '.flv',
            );
        $other_types = array_merge($image_types, $audio_types, $video_types);
        $data = array();
        $data['image_types'] = $image_types;
        $data['show'] = in_array($this->input->get('show'), array(
            'all',
            'images',
            'audios',
            'videos',
            'others',
            )) ? $this->input->get('show') : 'all';
        $data['blog'] = $this->blog;
        $data['search_keyword'] = $this->input->get('search', true);

        $page = abs(intval($this->input->get('page')));
        $data['current_page'] = $page < 1 ? 1 : $page;

        $this->db->select('count(*) as total');
        $this->db->where('site_id', $data['blog']->id);
        if ($data['show'] == 'images')
        {
            $this->db->where_in('file_ext', $image_types);
            $where_ext = "AND `file_ext` IN ('" . implode("','", $image_types) . "')";
        }
        elseif ($data['show'] == 'audios')
        {
            $this->db->where_in('file_ext', $audio_types);
            $where_ext = "AND `file_ext` IN ('" . implode("','", $audio_types) . "')";
        }
        elseif ($data['show'] == 'videos')
        {
            $this->db->where_in('file_ext', $video_types);
            $where_ext = "AND `file_ext` IN ('" . implode("','", $video_types) . "')";
        }
        elseif ($data['show'] == 'others')
        {
            $this->db->where_not_in('file_ext', $other_types);
            $where_ext = "AND `file_ext` NOT IN ('" . implode("','", $other_types) . "')";
        }
        else
        {
            if ($data['search_keyword'] != null)
            {
                $this->db->like('file_name', $data['search_keyword']);
                $where_ext = "AND `file_name` LIKE '%" . $this->db->escape_like_str($data['search_keyword']) .
                    "%'";
            }
            else
            {
                $where_ext = "";
            }
        }
        $data['total_files'] = $this->db->get('blog_files')->row()->total;
        if ($data['total_files'])
        {
            $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                "blog_files` WHERE `site_id` = '" . $data['blog']->id . "' {$where_ext} ORDER BY `file_time` DESC LIMIT " .
                sql_offset($this->iwb->user_set['offset'], $data['current_page']) . ", " . $this->
                iwb->user_set['offset']);
            $data['files'] = $query->result();
        }
        $this->breadcrumbs->set(lang('panel_files'));

        $this->load->view('includes/header');
        $this->load->view('upload/index', $data);
        $this->load->view('includes/footer');
    }

    public function add_new()
    {
        $this->breadcrumbs->set(lang('panel_files'), 'upload');
        $this->breadcrumbs->set(lang('iwb_upload'));

        $data = array();
        $data['blog'] = $this->blog;
        $file_set = $this->iwb->get_setting(array('upload_file_types',
                'upload_file_size'));
        $data = array_merge($data, $file_set);
        $data['error'] = false;
        if ($this->input->post())
        {
            $configs = array(
                'upload_path' => FCPATH . 'files/blogs/' . $this->blog->id . '/media',
                'allowed_types' => json_decode($file_set['upload_file_types']),
                'file_ext_tolower' => true,
                'max_size' => $file_set['upload_file_size'], // In Kilobytes
                'overwrite' => true,
                );
            $this->load->library('upload', $configs);
            if (!$this->upload->do_upload())
            {
                $data['error'] = $this->upload->display_errors('<div class="alert alert-danger">',
                    '</div>');
            }
            else
            {
                $file = $this->upload->data();
                $file_name = substr(str_link($file['raw_name']), 0, 35);
                $file_name = strlen($file_name) <= 1 ? 'no-name' : $file_name;
                rename(FCPATH . 'files/blogs/' . $this->blog->id . '/media/' . $file['file_name'],
                    FCPATH . 'files/blogs/' . $this->blog->id . '/media/' . $file_name . $file['file_ext']);
                $query = $this->db->where(array(
                    'site_id' => $this->blog->id,
                    'file_name' => $file_name,
                    'file_ext' => $file['file_ext'],
                    ))->get('blog_files');
                if ($query->num_rows() != 0)
                {
                    $this->db->where(array(
                        'site_id' => $this->blog->id,
                        'file_name' => $file_name,
                        'file_ext' => $file['file_ext'],
                        ))->delete('blog_files');

                }
                $this->db->insert('blog_files', array(
                    'user_id' => $this->blog->user_id,
                    'site_id' => $this->blog->id,
                    'file_name' => $file_name,
                    'file_size' => $file['file_size'],
                    'file_type' => $file['file_type'],
                    'file_ext' => $file['file_ext'],
                    'file_time' => time(),
                    ));
                $this->session->set_flashdata('alert-success', lang('panel_file_uploaded'));
                redirect('upload/add_new');
            }
        }
        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('upload/add_new', $data);
        $this->load->view('includes/footer');
    }

    public function rename($id = 0)
    {
        $this->breadcrumbs->set(lang('panel_files'), 'upload');
        $this->breadcrumbs->set(lang('panel_rename'));

        $file = $this->get_file($id);
        if (!$file)
        {
            return $this->display_error(lang('panel_file_not_found'));
        }
        if ($this->input->post('file_name'))
        {
            $this->load->library('form_validation');
            $input = array('file_name' => substr(str_link($this->input->post('file_name')),
                    0, 35));
            $this->form_validation->set_data($input);
            $this->form_validation->set_rules('file_name', lang('panel_file_name'), array(
                'required',
                'min_length[2]',
                'max_length[35]',
                array('cfn', function ($fn)use ($file)
                    {
                        $CI = &get_instance(); $query = $CI->db->where(array(
                            'id !=' => $file->id,
                            'site_id' => $CI->blog->id,
                            'file_name' => $fn,
                            'file_ext' => $file->file_ext,
                            ))->get('blog_files'); if ($query->num_rows() != 0)
                        {
                            $CI->form_validation->set_message('cfn', lang('panel_file_already_exist'));
                                return false; }
                    }
                    ),
                ));
            if ($this->form_validation->run() != false)
            {
                if (rename(FCPATH . 'files/blogs/' . $this->blog->id . '/media/' . $file->
                    file_name . $file->file_ext, FCPATH . 'files/blogs/' . $this->blog->id .
                    '/media/' . $input['file_name'] . $file->file_ext))
                {
                    $this->db->where('id', $file->id)->update('blog_files', array('file_name' => $input['file_name']));
                }
                $this->session->set_flashdata('alert-success', lang('panel_file_renamed'));
                redirect('upload');
            }
        }
        $data = array();
        $data['blog'] = $this->blog;
        $data['file'] = $file;

        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('upload/rename', $data);
        $this->load->view('includes/footer');
    }

    public function delete($id = 0)
    {
        $file = $this->get_file($id);
        if (!$file)
        {
            return $this->display_error(lang('panel_file_not_found'));
        }
        $this->get_skip_confirm();
        if ($this->input->post() || $this->session->has_userdata('skip_confirm'))
        {
            $this->db->where('id', $file->id)->delete('blog_files');
            @unlink(FCPATH . 'files/blogs/' . $this->blog->id . '/media/' . $file->
                file_name . $file->file_ext);
            $this->session->set_flashdata('alert-success', lang('panel_file_deleted'));
            redirect('upload');
        }
        return $this->confirm(current_url(), lang('panel_delete_file_conf'), false, $this->
            set_skip_confirm());
    }

    private function get_file($id)
    {
        $id = abs(intval($id));
        $query = $this->db->get_where('blog_files', array('id' => $id, 'site_id' => $this->
                blog->id));
        if ($query->num_rows() == 0)
        {
            return false;
        }
        return $query->row();
    }
}
