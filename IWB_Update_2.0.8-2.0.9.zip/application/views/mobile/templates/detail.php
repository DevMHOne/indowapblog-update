<?php if ($template->moderation == 'yes'):?>
<div class="alert alert-warning">
This theme is still in moderation.
</div>
<?php endif?>
<ul class="list-group">
  <li class="list-group-item list-group-item-default">
    <h3 class="pull-left"><?=esc_html($template->name)?></h3><span class="pull-right">(<?=$template->theme?>)</span>
  </li>
  <li class="list-group-item text-center">
    <img src="<?=site_url('templates/'.$template->theme.'/'.$template->link.'/screenshoot.png')?>" style="width: 100%;height:auto;"/>
  </li>
  <li class="list-group-item">
    Theme: <?=$template->theme?>
  </li>
  <li class="list-group-item">
    Published by: <a href="<?=site_url('user/'.$template->user_username)?>"><?=$template->user_name?></a>
  </li>
  <li class="list-group-item">
    Uploaded: <?=format_date(strtotime($template->upload_time))?>
  </li>
  <li class="list-group-item">
    Description: <?=esc_html($template->description)?>
  </li>
  <li class="list-group-item list-group-item-footer">
    <?php if ($template->moderation == 'no'):?>
    <span class="pull-left">
    <a class="btn btn-default btn-sm" href="<?=site_url('templates/set/'.$template->theme.'/'.$template->link)?>">Use Template</a>
    <?php if ($this->iwb->user->rights == 10 || $this->iwb->user_id == $template->user_id):?>
    <a class="btn btn-default btn-sm" href="<?=site_url('templates/delete/'.$template->theme.'/'.$template->link)?>">Delete</a>
    <?php endif?>
    </span>
    <a class="btn btn-default btn-sm pull-right" href="<?=site_url('templates/preview/'.$template->theme.'/'.$template->link)?>" target="_blank">Preview</a>
    <?php elseif ($template->moderation == 'yes' && $this->iwb->user->rights == 10):?>
    <span class="pull-left">
    <a class="btn btn-default btn-sm" href="<?=site_url('templates/confirm_template/'.$template->theme.'/'.$template->link)?>">Confirm</a>
    <a class="btn btn-default btn-sm" href="<?=site_url('templates/reject/'.$template->theme.'/'.$template->link)?>">Reject</a>
    </span>
    <a class="btn btn-default btn-sm pull-right" href="<?=site_url('templates/preview/'.$template->theme.'/'.$template->link)?>" target="_blank">Preview</a>
    <?php endif?>
  </li>
</ul>