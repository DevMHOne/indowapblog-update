<?php if ($theme != 'moderated'):?>
<div class="row margin-bottom">
  <div class="col-sm-4">
    <a class="btn btn-primary" href="<?=site_url('templates/upload')?>">Upload</a>
  </div>
  <div class="col-sm-8">
    <form method="get" action="<?=site_url('templates/'.$theme)?>">
      <div class="input-group">
        <input class="form-control" type="text" name="search" placeholder="Search template" value=""/>
        <span class="input-group-btn">
          <button class="btn btn-primary" type="submit">
            Search
          </button>
        </span>
      </div>
    </form>
  </div>
</div>
<?php endif?>
<div class="menu-bar">
  <ul>
    <li class="<?=($theme == '' ? 'active' : '')?>">
      <a href="<?=site_url('templates')?>">All</a>
    </li>
    <li class="<?=($theme == 'mobile' ? 'active' : '')?>">
      <a href="<?=site_url('templates/mobile')?>">Mobile</a>
    </li>
    <li class="<?=($theme == 'desktop' ? 'active' : '')?>">
      <a href="<?=site_url('templates/desktop')?>">Desktop</a>
    </li>
    <?php if ($this->iwb->user->rights == 10):?>
    <li class="<?=($theme == 'moderated' ? 'active' : '')?>">
      <a href="<?=site_url('templates/moderated')?>">Moderated<?=($total_moderated ? ' ('.$total_moderated.')' : '')?></a>
    </li>
    <?php endif?>
  </ul>
</div>
<?php if (!empty($search_query)):?>
<div class="alert alert-info">Search for <strong><?=esc_html($search_query)?></strong>, result <strong><?=$total?></strong> templates.</div>
<?php endif?>
<?php if ($total == 0):?>
<div class="alert alert-danger">
  No template.
</div>
<?php else:?>
<?php foreach ($templates as $template):?>
<ul class="list-group">
  <li class="list-group-item list-group-item-default">
    <a href="<?=site_url('templates/'.$template->theme.'/'.$template->link)?>"><h3 class="pull-left"><?=esc_html($template->name)?></h3><span class="pull-right">(<?=$template->theme?>)</span></a>
  </li>
  <li class="list-group-item text-center">
    <a href="<?=site_url('templates/'.$template->theme.'/'.$template->link)?>">
    <img src="<?=site_url('templates/'.$template->theme.'/'.$template->link.'/screenshoot.png')?>" style="width: 100%;height:180px;"/>
    </a>
  </li>
  <li class="list-group-item list-group-item-footer">
    <?php if ($template->moderation == 'no'):?>
    <span class="pull-left">
    <a class="btn btn-default btn-sm" href="<?=site_url('templates/set/'.$template->theme.'/'.$template->link)?>">Use Template</a>
    <?php if ($this->iwb->user->rights == 10 || $this->iwb->user_id == $template->user_id):?>
    <a class="btn btn-default btn-sm" href="<?=site_url('templates/delete/'.$template->theme.'/'.$template->link)?>">Delete</a>
    <?php endif?>
    </span>
    <a class="btn btn-default btn-sm pull-right" href="<?=site_url('templates/preview/'.$template->theme.'/'.$template->link)?>" target="_blank">Preview</a>
    <?php else:?>
    <span class="pull-left">
    <a class="btn btn-default btn-sm" href="<?=site_url('templates/confirm_template/'.$template->theme.'/'.$template->link)?>">Confirm</a>
    <a class="btn btn-default btn-sm" href="<?=site_url('templates/reject/'.$template->theme.'/'.$template->link)?>">Reject</a>
    </span>
    <a class="btn btn-default btn-sm pull-right" href="<?=site_url('templates/preview/'.$template->theme.'/'.$template->link)?>" target="_blank">Preview</a>
    <?php endif?>
  </li>
</ul>
<?php endforeach?>
<?= pagination_link(site_url('templates/'.$theme) . '?'.(!empty($search_query) ? 'search='.esc_html($search_query).'&amp;' : '').'page=', sql_offset($offset,
    $current_page), $total, $offset) ?>
<?php endif?>