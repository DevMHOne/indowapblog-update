<ul class="list-group">
  <li class="list-group-item list-group-item-<?=($template->theme == 'mobile' ? 'default' : 'info')?> text-center">
    <a href="<?=site_url('templates/'.$template->theme.'/'.$template->link)?>"><h3><?=esc_html($template->name)?></h3></a>
  </li>
  <li class="list-group-item text-center">
    <a href="<?=site_url('templates/'.$template->theme.'/'.$template->link)?>">
    <img src="<?=site_url('templates/'.$template->theme.'/'.$template->link.'/screenshoot.png')?>" style="width: 100%;height:180px;"/>
    </a>
  </li>
  <li class="list-group-item list-group-item-footer text-center">
  <?=$template->theme;?>
  </li>
</ul>
<div>
  <?= form_open() ?>
    <div class="form-group">
        <label for="blog">
        Select Blog
        </label>
        <?= form_dropdown('blog', $blog, 'none','class="form-control" id="blog"') . "\r\n" ?>
    </div>
<button class="btn btn-primary" type="submit" name="set">
      Set Template
    </button>
  <?= form_close() ?>
</div>