<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Install_update_201
{
    protected $CI;
    protected $version = '2.0.1';

    public function __construct()
    {
        $this->CI = &get_instance();
    }

    public function install($auto = false)
    {
        $this->CI->db->where('set_key', 'iwb_version')->update('settings', array('set_value' =>
                $this->version));
        unlink(__file__);
        if (!$auto)
        {
            $this->CI->session->set_flashdata('alert-success',
                'Installasi pembaruan IndoWapBlog v' . $this->version .
                ' berhasil diselesaikan.');
            redirect('admin/iwb_update');
        }
    }
}
