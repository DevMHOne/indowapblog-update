<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Dropdown_date
{
    protected $CI;

    /**
     * Dropdown_date::__construct()
     * 
     * @return
     */
    public function __construct()
    {
        $this->CI = &get_instance();
    }

    /**
     * Dropdown_date::html_form()
     * 
     * @param integer $default
     * @return HTML form dropdown
     */
    public function html($default = 0)
    {
        $this->CI->lang->load('calendar');
        $timestamp = $default == 0 ? time() : $default;
        $time = $timestamp + (3600 * timezones($this->CI->iwb->user_set['time_zone']));
        $out = '';
        $out .= '<input type="hidden" name="current_date" value="' . $time .
            '" style="display:none"/>';
        $out .= '<div class="select-group">';
        $out .= '<select class="form-control auto-width" name="dd">';
        for ($i = 1; $i <= 31; $i++)
        {
            $dd = (strlen($i) == 1 ? '0' . $i : $i);
            $out .= '<option value="' . $dd . '"' . $this->get_selected('dd', $dd, date('d',
                $time)) . '>' . $dd . '</option>';
        }
        $out .= '</select>';
        $out .= '<select class="form-control auto-width" name="mm">';
        $months = array(
            lang('cal_jan'),
            lang('cal_feb'),
            lang('cal_mar'),
            lang('cal_apr'),
            lang('cal_may'),
            lang('cal_jun'),
            lang('cal_jul'),
            lang('cal_aug'),
            lang('cal_sep'),
            lang('cal_oct'),
            lang('cal_nov'),
            lang('cal_dec'),
            );
        foreach ($months as $month)
        {
            $out .= '<option value="' . $month . '" ' . $this->get_selected('mm', $month,
                date('M', $time)) . '>' . $month . '</option>';
        }
        $out .= '</select>';
        $out .= '<select class="form-control auto-width" name="yy">';
        $year = date('Y', time());
        $default_year = $default == 0 ? $year : date('Y', $time);
        for ($i = 1; $i <= 2; $i++)
        {
            $out .= '<option value="' . (($year + $i) - 1) . '" ' . $this->get_selected('yy',
                (($year + $i) - 1), $default_year) . '>' . (($year + $i) - 1) . '</option>';
        }
        $out .= '</select>';
        $out .= '<select class="form-control auto-width" name="hh">';
        for ($i = 0; $i <= 23; $i++)
        {
            $hh = (strlen($i) == 1 ? '0' . $i : $i);
            $out .= '<option value="' . $hh . '" ' . $this->get_selected('hh', $hh, date('H',
                $time)) . '>' . $hh . '</option>';
        }
        $out .= '</select>';
        $out .= '<select class="form-control auto-width" name="ii">';
        for ($i = 0; $i <= 59; $i++)
        {
            $ii = (strlen($i) == 1 ? '0' . $i : $i);
            $out .= '<option value="' . $ii . '" ' . $this->get_selected('ii', $ii, date('i',
                $time)) . '>' . $ii . '</option>';
        }
        $out .= '</select>';
        $out .= '<input type="hidden" name="ss" value="00" style="display:none"/>';
        $out .= '</div>';
        return $out;
    }

    /**
     * Dropdown_date::get_selected()
     * 
     * @param mixed $field
     * @param mixed $value
     * @param mixed $default
     * @return selected post
     */
    private function get_selected($field, $value, $default)
    {
        if ($this->CI->input->post($field) == null)
        {
            if ($value == $default)
            {
                return ' selected="selected"';
            }
        }
        if ($this->CI->input->post($field) == $value)
        {
            return ' selected="selected"';
        }
        return '';
    }

    /**
     * Dropdown_date::get_data()
     * 
     * @param integer $default
     * @return Unix timestamp
     */
    public function get_data($default = 0)
    {
        $timestamp = $default == 0 ? time() : $default;
        $str = $this->CI->input->post('dd', true) . '-' . $this->CI->input->post('mm', true) .
            '-' . $this->CI->input->post('yy', true) . ' ' . $this->CI->input->post('hh', true) .
            ':' . $this->CI->input->post('ii', true) . ':' . $this->CI->input->post('ss', true);
        $time = strtotime($str);
        if ($time === false)
        {
            return $timestamp;
        }
        $time -= 3600 * timezones($this->CI->iwb->user_set['time_zone']);
        if ($time < time())
        {
            return time();
        }
        return $time;
    }
}
