<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

class IWB_Form_validation extends CI_Form_validation
{
    public function __construct($rules = array())
    {
        parent::__construct($rules);
    }

    public function captcha($str)
    {
        if (!$this->CI->session->has_userdata('iwb_sess') || md5(strtolower($str)) != $this->
            CI->session->userdata('iwb_sess') || strlen($str) != 5)
        {
            $this->CI->session->unset_userdata('iwb_sess');
            return false;
        }
        $this->CI->session->unset_userdata('iwb_sess');
        return true;
    }
}
