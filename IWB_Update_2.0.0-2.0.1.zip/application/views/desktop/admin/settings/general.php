<?php if (validation_errors() != null):?>
<div class="alert alert-danger">
	<strong>
		<?=lang('iwb_error')?>!
	</strong>
	<ol class="list-unstyled">
		<?=validation_errors( '<li>', '</li>')?>
	</ol>
</div>
<?php endif?>
<?=form_open()?>
  <div class="form-group">
    <label for="site_name">
      Site Name
    </label>
    <input type="text" class="form-control" name="site_name" id="site_name" value="<?=set_value('site_name',$set['site_name'])?>"/>
  </div>
  <div class="form-group">
    <label for="site_email">
      Site Email
    </label>
    <input type="text" class="form-control" name="site_email" id="site_email" value="<?=set_value('site_email',$set['site_email'])?>"/>
  </div>
  <div class="form-group">
    <label for="time_zone">
      Time Zone
    </label>
    <?= timezone_menu($set['time_zone'], 'form-control', 'time_zone',
    'id="time_zone"') . "\r\n" ?>
  </div>
  <div class="form-group">
    <label for="offset">
      List Per Page
    </label>
    <?= form_dropdown('offset', array(
    '5' => '5',
    '10' => '10',
    '15' => '15',
    '20' => '20',
    ), $set['offset'], 'class="form-control" id="offset"') . "\r\n" ?>
  </div>
  <button class="btn btn-primary" type="submit" name="submit"><?=lang('iwb_save')?></button>
  </p>
<?=form_close()?>