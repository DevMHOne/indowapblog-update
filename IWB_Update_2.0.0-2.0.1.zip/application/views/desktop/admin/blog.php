<div class="menu-bar">
  <ul>
    <li class="<?=($show == 'all' ? 'active' : '')?>">
      <a href="<?=site_url('admin/blog/all')?>">All</a>
    </li>
    <li class="<?=($show == 'moderated' ? 'active' : '')?>">
      <a href="<?=site_url('admin/blog/moderated')?>">Moderated</a>
    </li>
    <li class="<?=($show == 'blocked' ? 'active' : '')?>">
      <a href="<?=site_url('admin/blog/blocked')?>">Blocked</a>
    </li>
  </ul>
</div>
<?php if ($total == 0): ?>
<div class="alert alert-warning">
  Tidak ada blog.
</div>
<?php else: ?>
<?php foreach ($blogs as $blog): ?>
<ul class="list-group">
  <li class="list-group-item list-group-item-<?=$blog->mod_reg == 'yes' || $blog->block == 'yes' ? 'danger' : 'default'?>">
    <a href="<?= blog_url($blog) ?>" target="_blank"><h3><?= esc_html($blog->name) ?></h3></a>
    <span>(<?=blog_url($blog)?>)</span>
  </li>
  <li class="list-group-item">
    Author: <a href="<?=site_url('user/'.$blog->user_username)?>"><?=esc_html('user/'.$blog->user_name)?></a>
  </li>
  <li class="list-group-item">
    Status: <?= ($blog->mod_reg == 'yes' ? 'Waiting moderation' : ($blog->block == 'yes' ? 'Suspended' : 'Active')) ?>
  </li>
  <li class="list-group-item">
    Last post: <?=$blog->last_post != 0 ? format_date($blog->last_post) : ''?>
  </li>
  <li class="list-group-item">
    Last visited: <?=($blog->hits_today_date != '0000-00-00' ? substr(format_date(strtotime($blog->hits_today_date.' 00:00:00')),0,-8) : '')?>
  </li>
  <li class="list-group-item">
    Followers: <?=count(json_decode($blog->followers))?>
  </li>
  <li class="list-group-item">
    Created: <?=format_date($blog->created)?>
  </li>
  <li class="list-group-item list-group-item-footer">    
    <a class="btn btn-danger btn-sm" href="<?= site_url('admin/delete_blog/' . $blog->id) ?>"><?= lang('iwb_delete') ?></a>
  </li>
</ul>
<?php endforeach ?>
<?= pagination_link(site_url('admin/blog/'.$show) . '?page=', sql_offset($this->iwb->user_set['offset'],
    $current_page), $total, $this->iwb->user_set['offset']) ?>
<?php endif ?>