<?php if (validation_errors() != null):?>
<div class="alert alert-danger">
	<strong>
		<?=lang('iwb_error')?>!
	</strong>
	<ol class="list-unstyled">
		<?=validation_errors( '<li>', '</li>')?>
	</ol>
</div>
<?php endif?>
<?=form_open('messages/write')?>
<?php if ($user != false): ?>
<div class="margin-bottom">
    <div>
        <img style="display:block;margin-bottom:2px;" src="<?=user_photo($user->id,32)?>"/>
        <a href="<?=site_url('user/'.$user->username)?>">
            <strong><?=esc_html($user->name)?></strong>
        </a>
    </div>
    <input type="hidden" name="user" value="<?=$user->username?>"/>
    <input type="hidden" name="friends" value="null"/>
</div>
<?php else:?>
<div class="form-group">
    <label for="user"><?=lang('messages_user')?></label>
    <input type="text" name="user" placeholder="<?=lang('iwb_username')?>" value="<?=set_value(($this->input->post('user') != null ? implode(',',array_unique(preg_split("/[\s,]+/", htmlentities($this->input->post('user'))))): ''),$user_field)?>" class="form-control" id="user" />
    <p class="help-block"><?=lang('messages_pm_user_help')?></p>
</div>
<?php if ($total_friends != 0):?>
<div class="form-group">
    <?=form_dropdown('friends',$friends,'null','id="friends" class="form-control" onchange="this.form.submit()"')."\r\n"?>
</div>
<?php else:?>
<input type="hidden" name="friends" value="null"/>
<?php endif?>
<?php endif?>
<div class="form-group">
    <label for="message"><?=lang('messages_message')?></label>
    <textarea name="message" class="form-control" rows="4" cols="24" maxlength="1024" id="message"><?=set_value('message',$input['message'])?></textarea>
</div>
<p>
    <button class="btn btn-primary" type="submit">
        <?=lang('iwb_send')?>
    </button>
</p>
<?=form_close()?>