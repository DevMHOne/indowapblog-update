<?php $controller = strtolower($this->router->fetch_class());
$action = strtolower($this->router->fetch_method());
$default_data = render_data();
$page_title = $this->config->item('page_title');
$head_title = $page_title != null ? esc_html($page_title) . ' | ' . 
    esc_html($this->iwb->set['site_name']) : $default_data['head_title'];
$head_description = isset($head_description) ? trim($head_description) : $default_data['head_description'];
$head_keywords = isset($head_keywords) ? trim($head_keywords) : $default_data['head_keywords'];
$head_meta = isset($head_meta) ? trim($head_meta) : $default_data['head_meta']; ?>
<?php if (!$this->input->get('__modal')):?>
<!DOCTYPE html>
<html lang="en">
  
  <head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="description" content=""/>
    <meta name="author" content="Achunk JealousMan"/>
    <meta name="keyword" content=""/>
    <!--<link rel="shortcut icon" href="img/favicon.png"/>-->
    <?= $head_meta . "\r\n" ?>
    <title>
      <?= $head_title . "\r\n" ?>
    </title>
    <!-- Bootstrap CSS -->
    <link href="<?=base_url('assets/desktop/css/bootstrap.min.css')?>" rel="stylesheet"/>
    <!-- bootstrap theme -->
    <link href="<?=base_url('assets/desktop/css/bootstrap-theme.css')?>" rel="stylesheet"/>
    <!--external css-->
    <!-- font icon -->
    <link href="<?=base_url('assets/desktop/css/font-awesome.min.css')?>" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="<?=base_url('assets/desktop/css/style.css" rel="stylesheet')?>"/>
    <link href="<?=base_url('assets/desktop/css/style-responsive.css')?>" rel="stylesheet" />
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
      <script src="<?=base_url('assets/desktop/js/html5shiv.js')?>">
      </script>
      <script src="<?=base_url('assets/desktop/js/respond.min.js')?>">
      </script>
      <script src="<?=base_url('assets/desktop/js/lte-ie7.js')?>">
      </script>
    <![endif]-->
  </head>
  
  <body>
    <!-- container section start -->
    <section id="container" class="">
      <!--header start-->
      <header class="header dark-bg">
        <div class="toggle-nav">
          <div class="fa fa-bars fa-2x" data-original-title="Toggle Navigation" data-placement="bottom">
          </div>
        </div>
        <!--logo start-->
        <a href="<?=site_url()?>" class="logo"><?=esc_html($this->iwb->set['site_name'])?></a>
        <!--logo end-->
        <?php if ($this->iwb->is_user):?>
        <div class="top-nav notification-row">
          <!-- notificatoin dropdown start-->
          <ul class="nav pull-right top-menu">
            <!-- task notificatoin start
            <li id="task_notificatoin_bar" class="dropdown">
              <a data-toggle="dropdown" class="dropdown-toggle ajax-toggle" href="<?=site_url('quiz/ajax')?>" data-append=".tasks-bar">
              <span class="fa fa-puzzle-piece"></i>
              <span class="badge bg-important">5</span>
              </a>
              <ul class="dropdown-menu extended tasks-bar">
                <div class="notify-arrow notify-arrow-blue">
                </div>
                <li>
                  <p class="blue text-center">
                    <img src="<?=base_url('images/ajax-loader.gif')?>"/>
                  </p>
                </li>
              </ul>
            </li>
            task notificatoin end -->
            <!-- inbox notificatoin start-->
            <li id="mail_notificatoin_bar" class="dropdown">
              <a data-toggle="dropdown" class="dropdown-toggle ajax-toggle" href="<?=site_url('messages/ajax')?>" data-append=".inbox">
              <i class="fa fa-envelope-o"></i>
              <?php if ($this->iwb->user->alert['new_messages'] != 0):?>
              <span class="badge bg-important"><?=($this->iwb->user->alert['new_messages'] > 99 ? '99+' : $this->iwb->user->alert['new_messages'])?></span>
              <?php endif?>
              </a>
              <ul class="dropdown-menu extended inbox">
                <div class="notify-arrow notify-arrow-blue">
                </div>
                <li>
                  <p class="blue text-center">
                    <img src="<?=base_url('images/ajax-loader.gif')?>"/>
                  </p>
                </li>
              </ul>
            </li>
            <!-- inbox notificatoin end -->
            <!-- alert notification start-->
            <li id="alert_notificatoin_bar" class="dropdown">
              <a data-toggle="dropdown" class="dropdown-toggle ajax-toggle" href="<?=site_url('notifications/ajax')?>" data-append=".notification">
              <i class="fa fa-bell-o"></i>
              <?php if ($this->iwb->user->alert['notifications'] != 0):?>
              <span class="badge bg-important"><?=($this->iwb->user->alert['notifications'] > 99 ? '99+' : $this->iwb->user->alert['notifications'])?></span>
              <?php endif?>
              </a>
              <ul class="dropdown-menu extended notification">
                <div class="notify-arrow notify-arrow-blue">
                </div>
                <li>
                  <p class="blue text-center">
                    <img src="<?=base_url('images/ajax-loader.gif')?>"/>
                  </p>
                </li>
              </ul>
            </li>
            <!-- alert notification end-->
            <!-- user login dropdown start-->
            <li class="dropdown">
              <a data-toggle="dropdown" class="dropdown-toggle" href="#">
              <span class="profile-ava">
              <img alt="" src="<?=user_photo($this->iwb->user_id,32)?>"/>
              </span>
              <span class="username"><?=esc_html($this->iwb->user->name)?></span>
              <b class="caret"></b>
              </a>
              <ul class="dropdown-menu extended logout">
                <div class="log-arrow-up">
                </div>
                <li class="eborder-top">
                  <a href="<?=site_url('account')?>"><i class="fa fa-user"></i> My Account</a>
                </li>
                <li>
                  <a href="<?=site_url('account/blog')?>"><i class="fa fa-globe"></i> My Blogs</a>
                </li>
                <li>
                  <a href="<?=site_url('messages')?>"><i class="fa fa-envelope-o"></i> My Inbox</a>
                </li>
                <li>
                  <a href="<?=site_url('friends')?>"><i class="fa fa-users"></i> Friends</a>
                </li>
                <li>
                  <a href="<?=site_url('site/language')?>" data-toggle="modal" data-target="#iwb-modal"><i class="fa fa-flag-o"></i> Language</a>
                </li>
                <?php if ($this->iwb->user->rights == 10):?>
                <li>
                  <a href="<?=site_url('admin')?>"><i class="fa fa-shield"></i> Admin Panel</a>
                </li>
                <?php endif?>
                <li>
                  <a href="<?=site_url('site/logout')?>" data-toggle="modal" data-target="#iwb-modal"><i class="fa fa-sign-out"></i> Log Out</a>
                </li>
              </ul>
            </li>
            <!-- user login dropdown end -->
          </ul>
          <!-- notificatoin dropdown end-->        
        </div>
        <?php endif?>
      </header>
      <!--header end-->
      <!--sidebar start-->
      <aside>
        <div id="sidebar" class="nav-collapse ">
          <!-- sidebar menu start-->
          <ul class="sidebar-menu">
            <?php if ($this->iwb->is_user):?>
            <li class="">
              <a class="" href="<?=site_url('dashboard')?>">
              <i class="fa fa-dashboard"></i>
              <span>Dashboard</span>
              </a>
            </li>
            <li class="sub-menu">
              <a href="javascript:;" class="">
              <i class="fa fa-file-text-o"></i>
              <span>Posting</span>
              <span class="menu-arrow fa fa-angle-right"></span>
              </a>
              <ul class="sub">
                <li>
                  <a class="" href="<?=site_url('posts')?>"><span class="fa fa-angle-right"></span> Semua Posting</a>
                </li>
                <li>
                  <a class="" href="<?=site_url('posts/add_new')?>"><span class="fa fa-angle-right"></span> Menulis Posting</a>
                </li>
                <li>
                  <a class="" href="<?=site_url('categories')?>"><span class="fa fa-angle-right"></span> Kategori</a>
                </li>
              </ul>
            </li>
            <li class="sub-menu">
              <a href="javascript:;" class="">
              <i class="fa fa-file-o"></i>
              <span>Halaman</span>
              <span class="menu-arrow fa fa-angle-right"></span>
              </a>
              <ul class="sub">
                <li>
                  <a class="" href="<?=site_url('pages')?>"><span class="fa fa-angle-right"></span> Semua Halaman</a>
                </li>
                <li>
                  <a class="" href="<?=site_url('pages/add_new')?>"><span class="fa fa-angle-right"></span> Membuat Halaman</a>
                </li>
              </ul>
            </li>
            <li class="">
              <a class="" href="<?=site_url('comments')?>">
              <i class="fa fa-comments-o"></i>
              <span>Komentar</span>
              </a>
            </li>
            <li class="sub-menu">
              <a href="javascript:;" class="">
              <i class="fa fa-paperclip"></i>
              <span>Media</span>
              <span class="menu-arrow fa fa-angle-right"></span>
              </a>
              <ul class="sub">
                <li>
                  <a class="" href="<?=site_url('upload')?>"><span class="fa fa-angle-right"></span> Berkas</a>
                </li>
                <li>
                  <a class="" href="<?=site_url('upload/add_new')?>"><span class="fa fa-angle-right"></span> Unggah</a>
                </li>
              </ul>
            </li>
            <li class="sub-menu">
              <a href="javascript:;" class="">
              <i class="fa fa-desktop"></i>
              <span>Tampilan</span>
              <span class="menu-arrow fa fa-angle-right"></span>
              </a>
              <ul class="sub">
                <li>
                  <a class="" href="<?=site_url('theme')?>"><span class="fa fa-angle-right"></span> Tema</a>
                </li>
                <li>
                  <a class="" href="<?=site_url('navigation')?>"><span class="fa fa-angle-right"></span> Menu Navigasi</a>
                </li>
              </ul>
            </li>
            <li class="sub-menu">
              <a href="javascript:;" class="">
              <i class="fa fa-cogs"></i>
              <span>Pengaturan</span>
              <span class="menu-arrow fa fa-angle-right"></span>
              </a>
              <ul class="sub">
                <li>
                  <a class="" href="<?=site_url('settings/general')?>"><span class="fa fa-angle-right"></span> Umum</a>
                </li>
                <li>
                  <a class="" href="<?=site_url('settings/display')?>"><span class="fa fa-angle-right"></span> Tampilan</a>
                </li>
                <li>
                  <a class="" href="<?=site_url('settings/discussion')?>"><span class="fa fa-angle-right"></span> Diskusi</a>
                </li>
              </ul>
            </li>
            <li class="sub-menu">
              <a href="javascript:;" class="">
              <i class="fa fa-circle-o"></i>
              <span>Lainnya</span>
              <span class="menu-arrow fa fa-angle-right"></span>
              </a>
              <ul class="sub">
                <li>
                  <a class="" href="<?=site_url('followers')?>"><span class="fa fa-angle-right"></span> Pengikut</a>
                </li>
                <li>
                  <a class="" href="<?=site_url('stats')?>"><span class="fa fa-angle-right"></span> Statistik</a>
                </li>
                <li>
                  <a class="" href="<?=site_url('ads')?>"><span class="fa fa-angle-right"></span> Periklanan</a>
                </li>
              </ul>
            </li>
            <?php else:?>
            <li class="">
              <a class="" href="<?=site_url('site/login')?>" data-toggle="modal" data-target="#iwb-modal">
              <i class="fa fa-sign-in"></i>
              <span><?=lang('iwb_login')?></span>
              </a>
            </li>
            <li class="">
              <a class="" href="<?=site_url('site/registration')?>">
              <i class="fa fa-unlock-alt"></i>
              <span><?=lang('iwb_registration')?></span>
              </a>
            </li>
            <?php endif?>
          </ul>
          <!-- sidebar menu end-->
        </div>
      </aside>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
        <section class="wrapper">
          <div class="row">
            <div class="col-lg-12">
              <?= $this->breadcrumbs->show(false) . "\r\n" ?>
            </div>
            <?php $flashdata = $this->session->flashdata() ?>
            <?php if ($flashdata != null): ?>
            <div class="col-lg-12">
            <?php foreach ($flashdata as $flash_key => $flash_val): ?>
            <div class="alert <?= $flash_key ?>" id="flash-alert">
            <?= $flash_val ?>
            </div>
            <?php endforeach ?>
            </div>
            <?php endif ?>
          </div>
          <!-- page start-->
          <?php else:?>
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="iwb-modal-label"><?=$page_title != null ? esc_html($page_title) : esc_html($this->iwb->set['site_name'])?></h4>
          </div>
          <div class="modal-body">
          <?php endif?>