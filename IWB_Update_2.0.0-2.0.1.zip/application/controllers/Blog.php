<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Blog extends CI_Controller
{
    protected $tpl;
    protected $data = array();
    protected $theme = 'mobile';
    private $server_name;
    protected $load_stats = false;

    public function __construct()
    {
        parent::__construct();
        $domain = $this->config->item('domain');
        $this->server_name = $server_name = $this->config->item('server_name');
        if ($server_name == $domain)
        {
            show_404();
        }
    }

    private function blog_init()
    {
        $blog_domain = explode('.', $this->server_name, 2);
        $this->db->select('b.*, u.id as author_id, u.username as author_username, u.email as author_email, u.name as author_name, u.rights as author_rights, u.gender as author_gender, u.datebirth as author_datebirth, u.address as author_address, u.about as author_about, u.status as author_status, u.settings as author_settings, u.credit as author_credit, u.total_on_site as author_total_on_site, u.last_date as author_last_date, u.place as author_place, u.registered as author_registered, f.friends as author_friends');
        $this->db->from('blog_sites as b');
        $this->db->join('users as u', 'u.id = b.user_id', 'left');
        $this->db->join('friends as f', 'f.user_id = b.user_id', 'left');
        $this->db->where(array(
            'b.subdomain' => $blog_domain[0],
            'b.domain' => $blog_domain[1],
            'b.mod_reg' => 'no',
            ));
        $this->db->limit(1);
        $query = $this->db->get();
        if ($query->num_rows() == 0)
        {
            show_404('Blog not found.');
        }
        $blog = $query->row_array();
        unset($blog['user_id']);
        if ($blog['block'] != 'no')
        {
            show_error('This blog has been suspended.');
        }
        $this->load->model('notifications_model');
        $this->data['site'] = $blog;
        $this->data['site']['followers'] = json_decode($blog['followers'], true);
        $this->data['site']['modules'] = json_decode($blog['modules'], true);
        $this->data['site']['settings'] = get_blog_settings($blog['settings']);
        $this->data['site']['url'] = blog_url((object)array(
            'id' => $blog['id'],
            'subdomain' => $blog['subdomain'],
            'domain' => $blog['domain'],
            ));
        $this->data['site']['author_friends'] = json_decode($blog['author_friends'], true);
        $this->data['site']['author_settings'] = json_decode($blog['author_settings'], true);
        $this->data['home_page'] = false;
        $this->data['active_page'] = 'home_page';
        $this->data['blog_categories'] = array();

        $query = $this->db->where('site_id', $blog['id'])->order_by('name', 'ASC')->get('blog_categories');
        if ($query->num_rows() > 0)
        {
            foreach ($query->result_array() as $category)
                $this->data['blog_categories'][$category['link']] = $category;
        }

        $page = abs(intval($this->input->get('page')));
        $this->data['current_page'] = $page < 1 ? 1 : $page;
        $this->data['page_title'] = $blog['name'];
        $this->data['page_description'] = esc_html($this->data['site']['settings']['description']);
        $this->data['page_keywords'] = esc_html($this->data['site']['settings']['keywords']);
        $this->data['powered'] = array(
            'url' => $this->config->item('base_url'),
            'name' => $this->iwb->set['site_name'],
            );

        $this->data['search_query'] = '';

        if ($this->iwb->is_user)
        {
            $this->data['is_guest'] = 0;
            $this->data['is_user'] = 1;

            $user_set = array_merge($this->iwb->default_user_set(), json_decode($this->iwb->
                user->settings, true));
            $user = array(
                'id' => $this->iwb->user->id,
                'username' => $this->iwb->user->username,
                'name' => $this->iwb->user->name,
                'gender' => $this->iwb->user->gender,
                'datebirth' => ($user_set['show_datebirth'] == 'yes' ? $this->iwb->user->
                    datebirth : ''),
                'email' => ($user_set['show_email'] == 'yes' ? $this->iwb->user->email : ''),
                'address' => $this->iwb->user->address,
                'about' => '',
                );
            $this->data['user'] = $user;
            if ($this->iwb->user->friends != null)
            {
                $ufriends = json_decode($this->iwb->user->friends);
            }
            else
            {
                $this->iwb->user->{'friends'} = '[]';
                $ufriends = array();
            }
            if (in_array($this->data['site']['author_id'], $ufriends))
            {
                $this->data['is_friend'] = 1;
            }
            else
            {
                $this->data['is_friend'] = 0;
            }
            if (in_array($this->iwb->user->id, $this->data['site']['followers']))
            {
                $this->data['is_follower'] = 1;
            }
            else
            {
                $this->data['is_follower'] = 0;
            }
        }
        else
        {
            $this->data['is_guest'] = 1;
            $this->data['is_user'] = 0;
            $this->data['is_friend'] = 0;
            $this->data['is_follower'] = 0;
            $this->data['user'] = array(
                'id' => '',
                'username' => '',
                'name' => '',
                'gender' => '',
                'datebirth' => '',
                'email' => '',
                'address' => '',
                'about' => '',
                );
        }
        $this->load->model('blog_model');
        $this->data['navigations'] = $this->blog_model->read_navigation($this->data['site']['id'],
            $this->theme);
    }
    public function _remap()
    {
        $uri = $this->uri->uri_string();

        if (preg_match_all('/files\/([a-z0-9-]{2,35}+)\.([a-z0-9]{2,6}+)$/', $uri, $matches,
            PREG_SET_ORDER))
        {
            return $this->get_file($matches[0][1], $matches[0][2]);
        }

        $this->blog_init();

        if ($uri == '' || $uri == 'index.html')
        {
            return $this->index();
        }
        elseif ($uri == 'login.html')
        {
            return $this->login();
        }
        elseif ($uri == 'logout.html')
        {
            return $this->logout();
        }
        elseif ($uri == 'follow.html')
        {
            return $this->follow();
        }
        elseif (preg_match_all('/page\/([0-9]+)\.html$/', $uri, $matches, PREG_SET_ORDER))
        {
            $this->set_current_page($matches[0][1]);
            return $this->index();
        }
        elseif (preg_match_all('/pages\/([a-z0-9-]{2,120}+)\.html$/', $uri, $matches,
            PREG_SET_ORDER))
        {
            return $this->singlepage($matches[0][1]);
        }
        elseif (preg_match_all('/category\/([a-z0-9-]{2,40}+)\/([0-9]+)\.html$/', $uri,
            $matches, PREG_SET_ORDER))
        {
            if ($matches[0][1] != 'uncategorized' && !array_key_exists($matches[0][1], $this->
                data['blog_categories']))
            {
                return $this->error_page('Category not found.');
            }
            $this->set_current_page($matches[0][2]);
            return $this->category($matches[0][1]);
        }
        elseif (preg_match_all('/tag\/([a-z0-9-]{2,100}+)\/([0-9]+)\.html$/', $uri, $matches,
            PREG_SET_ORDER))
        {
            $this->set_current_page($matches[0][2]);
            return $this->tag($matches[0][1]);
        }
        elseif (preg_match_all('/([a-z0-9-]{2,120}+)\.html$/', $uri, $matches,
            PREG_SET_ORDER))
        {
            return $this->singlepost($matches[0][1]);
        }
        else
        {
            return $this->error_page();
        }
    }

    private function get_file($file_name, $file_ext)
    {
        $blog_domain = explode('.', $this->server_name, 2);
        $this->db->select('b.id,f.file_name,f.file_type,f.file_ext');
        $this->db->from('blog_sites AS b');
        $this->db->join('blog_files AS f', 'f.site_id=b.id AND f.file_name=' . $this->
            db->escape($file_name) . ' AND f.file_ext=' . $this->db->escape('.' . $file_ext),
            'LEFT');
        $this->db->where('b.subdomain', $blog_domain[0]);
        $this->db->where('b.domain', $blog_domain[1]);
        $this->db->limit(1);
        $query = $this->db->get();
        if ($query->num_rows() == 0)
        {
            show_404();
        }
        $data = $query->row();
        if ($data->file_name == null)
        {
            show_404();
        }

        $file = FCPATH . '/files/blogs/' . $data->id . '/media/' . $data->file_name . $data->
            file_ext;
        if (file_exists($file))
        {
            if (ob_get_level() !== 0 && @ob_end_clean() === false)
            {
                @ob_clean();
            }
            header('Content-Type: ' . $data->file_type);
            if (!in_array($data->file_ext, array(
                '.jpg',
                '.png',
                '.gif',
                '.jpeg',
                '.bmp',
                )))
            {
                header('Content-Disposition: attachment; filename="' . $data->file_name . $data->
                    file_ext . '"');
            }
            header('Expires: 0');
            header('Content-Transfer-Encoding: binary');
            header('Content-Length: ' . filesize($file));

            if (isset($_SERVER['HTTP_USER_AGENT']) && strpos($_SERVER['HTTP_USER_AGENT'],
                'MSIE') !== false)
            {
                header('Cache-Control: no-cache, no-store, must-revalidate');
            }

            header('Pragma: no-cache');

            $handle = fopen($file, "rb");
            while (!feof($handle))
            {
                echo fread($handle, 1000);
            }
            exit();
        }
        else
        {
            show_404();
        }

    }

    private function set_current_page($page)
    {
        $page = abs(intval($page));
        $this->data['current_page'] = $page < 1 ? 1 : $page;
    }
    private function load_template()
    {
        $this->load->library('twig');
        $loader = new Twig_Loader_Filesystem(FCPATH . 'files/blogs/' . $this->data['site']['id'] .
            '/templates/' . $this->theme);
        $this->tpl = new Twig_Environment($loader, array(
            'cache' => false,
            'debug' => true,
            'autoescape' => true,
            'auto_reload' => true,
            ));
        $this->tpl->getExtension('core')->setTimezone($this->data['site']['settings']['time_zone']);
        $this->tpl->addExtension(new Twig_Extension_Debug());
        $this->tpl->addFilter(new Twig_SimpleFilter('json_decode', 'json_decode'));
        $tags = array(
            'autoescape',
            //'block',
            'do',
            //'embed',
            //'extends',
            'filter',
            'flush',
            'for',
            //'from',
            'if',
            //'import',
            'include',
            //'macro',
            'sandbox',
            'set',
            'spaceless',
            //'use',
            'verbatim',
            );
        $filters = array(
            'abs',
            'batch',
            'capitalize',
            'convert_encoding',
            'date',
            'date_modify',
            'default',
            'escape',
            'first',
            'format',
            'join',
            'json_encode',
            'json_decode',
            'keys',
            'last',
            'length',
            'lower',
            'merge',
            'nl2br',
            'number_format',
            'raw',
            'replace',
            'reverse',
            'round',
            'slice',
            'sort',
            'split',
            'striptags',
            'title',
            'trim',
            'upper',
            'url_encode',
            );
        $methods = array();
        $properties = array();
        $functions = array(
            'attribute',
            //'block',
            //'constant',
            'cycle',
            'date',
            'dump',
            'include',
            'max',
            'min',
            //'parent',
            'random',
            'range',
            //'source',
            'template_from_string',
            );
        $policy = new Twig_Sandbox_SecurityPolicy($tags, $filters, $methods, $properties,
            $functions);
        $sandbox = new Twig_Extension_Sandbox($policy);
        $this->tpl->addExtension($sandbox);
    }

    private function index()
    {
        $this->load_stats = true;
        if ($this->input->get('search'))
        {
            return $this->search($this->input->get('search', true));
        }
        $this->data['total_posts'] = $this->db->query("SELECT COUNT(*) AS `total` FROM `" .
            $this->db->dbprefix . "blog_posts` WHERE `site_id` = ? AND (`user_id` = '" . $this->
            iwb->user_id . "' OR `visibility` = 'public' OR (`visibility` = 'friends' AND '1' = '" .
            $this->data['is_friend'] . "') OR (`visibility` = 'followers' AND '1' = '" . $this->
            data['is_follower'] . "')) AND `status` = 'publish' AND `type` = 'post'", array
            ($this->data['site']['id']))->row()->total;
        $this->data['posts'] = array();
        if ($this->data['total_posts'] > 0)
        {
            $total_pages = ceil($this->data['total_posts'] / $this->data['site']['settings']['post_per_page']);
            if ($this->data['current_page'] > $total_pages)
            {
                $this->data['current_page'] = $total_pages;
            }

            $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                "blog_posts` WHERE `site_id` = ? AND (`user_id` = '" . $this->iwb->user_id .
                "' OR `visibility` = 'public' OR (`visibility` = 'friends' AND '1' = '" . $this->
                data['is_friend'] . "') OR (`visibility` = 'followers' AND '1' = '" . $this->
                data['is_follower'] .
                "')) AND `status` = ?  AND `type` = ? ORDER BY `time` DESC LIMIT " . sql_offset
                ($this->data['site']['settings']['post_per_page'], $this->data['current_page']) .
                ", " . $this->data['site']['settings']['post_per_page'], array(
                $this->data['site']['id'],
                'publish',
                'post',
                ));
            if ($this->data['site']['settings']['display_thumbnail'] == 'yes')
            {
                $this->load->library('simple_html_dom');
                $dom = new simple_html_dom();
                $get_thumb = true;
            }
            else
            {
                $get_thumb = false;
            }
            foreach ($query->result_array() as $post)
            {
                if ($get_thumb)
                {
                    $dom->load($post['content']);
                    $image = $dom->find('img', 0);
                    $src = @$image->src;
                    if ($src)
                    {
                        $thumbnail = '<img src="' . $image->src . '" class="thumbnail" />';
                    }
                    else
                    {
                        $thumbnail = '';
                    }
                    $dom->clear();
                }
                else
                {
                    $thumbnail = '';
                }
                $this->data['posts'][] = array_merge($post, array('thumbnail' => $thumbnail));
            }
            $this->data['pagination'] = pagination_link($this->data['site']['url'] .
                '/page/', sql_offset($this->data['site']['settings']['post_per_page'], $this->
                data['current_page']), $this->data['total_posts'], $this->data['site']['settings']['post_per_page'],
                '.html');
        }
        return $this->show_output();
    }

    private function search($keyword)
    {
        $search = $keyword;
        if (mb_strlen($search) < 2 || mb_strlen($search) > 12)
        {
            return $this->error_page('The length of the search keyword minimum 2 and maximum 12 characters.');
        }
        $this->data['posts_by_search'] = $search;
        $this->data['search_query'] = esc_html($search);
        $this->data['total_posts'] = $this->db->query("SELECT COUNT(*) AS `total` FROM `" .
            $this->db->dbprefix .
            "blog_posts` WHERE `site_id` = ? AND `title` LIKE ? AND (`user_id` = '" . $this->
            iwb->user_id . "' OR `visibility` = 'public' OR (`visibility` = 'friends' AND '1' = '" .
            $this->data['is_friend'] . "') OR (`visibility` = 'followers' AND '1' = '" . $this->
            data['is_follower'] . "')) AND `status` = 'publish' AND `type` = 'post'", array
            ($this->data['site']['id'], '%' . $search . '%'))->row()->total;
        $this->data['posts'] = array();
        if ($this->data['total_posts'] > 0)
        {
            $total_pages = ceil($this->data['total_posts'] / $this->data['site']['settings']['post_per_page']);
            if ($this->data['current_page'] > $total_pages)
            {
                $this->data['current_page'] = $total_pages;
            }

            $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                "blog_posts` WHERE `site_id` = ? AND `title` LIKE ? AND (`user_id` = '" . $this->
                iwb->user_id . "' OR `visibility` = 'public' OR (`visibility` = 'friends' AND '1' = '" .
                $this->data['is_friend'] . "') OR (`visibility` = 'followers' AND '1' = '" . $this->
                data['is_follower'] .
                "')) AND `status` = ?  AND `type` = ? ORDER BY `time` DESC LIMIT " . sql_offset
                ($this->data['site']['settings']['post_per_page'], $this->data['current_page']) .
                ", " . $this->data['site']['settings']['post_per_page'], array(
                $this->data['site']['id'],
                '%' . $search . '%',
                'publish',
                'post',
                ));
            if ($this->data['site']['settings']['display_thumbnail'] == 'yes')
            {
                $this->load->library('simple_html_dom');
                $dom = new simple_html_dom();
                $get_thumb = true;
            }
            else
            {
                $get_thumb = false;
            }
            foreach ($query->result_array() as $post)
            {
                if ($get_thumb)
                {
                    $dom->load($post['content']);
                    $image = $dom->find('img', 0);
                    $src = @$image->src;
                    if ($src)
                    {
                        $thumbnail = '<img src="' . $image->src . '" class="thumbnail" />';
                    }
                    else
                    {
                        $thumbnail = '';
                    }
                    $dom->clear();
                }
                else
                {
                    $thumbnail = '';
                }
                $this->data['posts'][] = array_merge($post, array('thumbnail' => $thumbnail));
            }
            $this->data['pagination'] = pagination_link($this->data['site']['url'] .
                '/page/', sql_offset($this->data['site']['settings']['post_per_page'], $this->
                data['current_page']), $this->data['total_posts'], $this->data['site']['settings']['post_per_page'],
                '.html?search=' . esc_html($search));
        }
        return $this->show_output();
    }


    private function category($category)
    {
        $this->load_stats = true;
        if ($category == 'uncategorized')
        {
            $this->data['posts_by_category'] = 'Uncategorized.';
            $category_db = '[]';
        }
        else
        {
            $this->data['posts_by_category'] = $this->data['blog_categories'][$category]['name'];
            $category_db = '%"' . $category . '"%';
        }

        $this->data['total_posts'] = $this->db->query("SELECT COUNT(*) AS `total` FROM `" .
            $this->db->dbprefix .
            "blog_posts` WHERE `site_id` = ? AND `categories` LIKE ? AND (`user_id` = '" . $this->
            iwb->user_id . "' OR `visibility` = 'public' OR (`visibility` = 'friends' AND '1' = '" .
            $this->data['is_friend'] . "') OR (`visibility` = 'followers' AND '1' = '" . $this->
            data['is_follower'] . "')) AND `status` = 'publish' AND `type` = 'post'", array
            ($this->data['site']['id'], $category_db))->row()->total;
        $this->data['posts'] = array();
        if ($this->data['total_posts'] > 0)
        {
            $total_pages = ceil($this->data['total_posts'] / $this->data['site']['settings']['post_per_page']);
            if ($this->data['current_page'] > $total_pages)
            {
                $this->data['current_page'] = $total_pages;
            }

            $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                "blog_posts` WHERE `site_id` = ? AND `categories` LIKE ? AND (`user_id` = '" . $this->
                iwb->user_id . "' OR `visibility` = 'public' OR (`visibility` = 'friends' AND '1' = '" .
                $this->data['is_friend'] . "') OR (`visibility` = 'followers' AND '1' = '" . $this->
                data['is_follower'] .
                "')) AND `status` = ?  AND `type` = ? ORDER BY `time` DESC LIMIT " . sql_offset
                ($this->data['site']['settings']['post_per_page'], $this->data['current_page']) .
                ", " . $this->data['site']['settings']['post_per_page'], array(
                $this->data['site']['id'],
                $category_db,
                'publish',
                'post',
                ));
            if ($this->data['site']['settings']['display_thumbnail'] == 'yes')
            {
                $this->load->library('simple_html_dom');
                $dom = new simple_html_dom();
                $get_thumb = true;
            }
            else
            {
                $get_thumb = false;
            }
            foreach ($query->result_array() as $post)
            {
                if ($get_thumb)
                {
                    $dom->load($post['content']);
                    $image = $dom->find('img', 0);
                    $src = @$image->src;
                    if ($src)
                    {
                        $thumbnail = '<img src="' . $image->src . '" class="thumbnail" />';
                    }
                    else
                    {
                        $thumbnail = '';
                    }
                    $dom->clear();
                }
                else
                {
                    $thumbnail = '';
                }
                $this->data['posts'][] = array_merge($post, array('thumbnail' => $thumbnail));
            }
            $this->data['pagination'] = pagination_link($this->data['site']['url'] .
                '/category/' . $category . '/', sql_offset($this->data['site']['settings']['post_per_page'],
                $this->data['current_page']), $this->data['total_posts'], $this->data['site']['settings']['post_per_page'],
                '.html');
        }
        return $this->show_output();
    }

    private function tag($tag)
    {
        $this->load_stats = true;
        $tag = strtolower($tag);
        $this->data['posts_by_tag'] = strtolower(esc_html(router2word($tag)));
        $this->data['total_posts'] = $this->db->query("SELECT COUNT(*) AS `total` FROM `" .
            $this->db->dbprefix .
            "blog_posts` WHERE `site_id` = ? AND `tags` LIKE ? AND (`user_id` = '" . $this->
            iwb->user_id . "' OR `visibility` = 'public' OR (`visibility` = 'friends' AND '1' = '" .
            $this->data['is_friend'] . "') OR (`visibility` = 'followers' AND '1' = '" . $this->
            data['is_follower'] . "')) AND `status` = 'publish' AND `type` = 'post'", array
            ($this->data['site']['id'], '%"' . $tag . '"%'))->row()->total;
        $this->data['posts'] = array();
        if ($this->data['total_posts'] > 0)
        {
            $total_pages = ceil($this->data['total_posts'] / $this->data['site']['settings']['post_per_page']);
            if ($this->data['current_page'] > $total_pages)
            {
                $this->data['current_page'] = $total_pages;
            }

            $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                "blog_posts` WHERE `site_id` = ? AND `tags` LIKE ? AND (`user_id` = '" . $this->
                iwb->user_id . "' OR `visibility` = 'public' OR (`visibility` = 'friends' AND '1' = '" .
                $this->data['is_friend'] . "') OR (`visibility` = 'followers' AND '1' = '" . $this->
                data['is_follower'] .
                "')) AND `status` = ?  AND `type` = ? ORDER BY `time` DESC LIMIT " . sql_offset
                ($this->data['site']['settings']['post_per_page'], $this->data['current_page']) .
                ", " . $this->data['site']['settings']['post_per_page'], array(
                $this->data['site']['id'],
                '%"' . $tag . '"%',
                'publish',
                'post',
                ));
            if ($this->data['site']['settings']['display_thumbnail'] == 'yes')
            {
                $this->load->library('simple_html_dom');
                $dom = new simple_html_dom();
                $get_thumb = true;
            }
            else
            {
                $get_thumb = false;
            }
            foreach ($query->result_array() as $post)
            {
                if ($get_thumb)
                {
                    $dom->load($post['content']);
                    $image = $dom->find('img', 0);
                    $src = @$image->src;
                    if ($src)
                    {
                        $thumbnail = '<img src="' . $image->src . '" class="thumbnail" />';
                    }
                    else
                    {
                        $thumbnail = '';
                    }
                    $dom->clear();
                }
                else
                {
                    $thumbnail = '';
                }
                $this->data['posts'][] = array_merge($post, array('thumbnail' => $thumbnail));
            }
            $this->data['pagination'] = pagination_link($this->data['site']['url'] . '/tag/' .
                esc_html($tag) . '/', sql_offset($this->data['site']['settings']['post_per_page'],
                $this->data['current_page']), $this->data['total_posts'], $this->data['site']['settings']['post_per_page'],
                '.html');
        }
        return $this->show_output();
    }

    private function singlepost($permalink)
    {
        $this->data['active_page'] = 'singlepost_page';
        $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
            "blog_posts` WHERE `site_id` = ? AND `link` = ? AND (`user_id` = '" . $this->
            iwb->user_id . "' OR `status` = 'publish') AND (`user_id` = '" . $this->iwb->
            user_id . "' OR `visibility` = 'public' OR (`visibility` = 'friends' AND '1' = '" .
            $this->data['is_friend'] . "') OR (`visibility` = 'followers' AND '1' = '" . $this->
            data['is_follower'] . "')) AND `type` = 'post' LIMIT 1", array(
            $this->data['site']['id'],
            $permalink,
            ));
        if ($query->num_rows() > 0)
        {
            $this->data['post'] = $post = $query->row();
            $this->data['page_title'] = $post->title . ' | ' . $this->data['site']['name'];
            $this->data['page_description'] = mb_substr(strip_tags($post->content), 0, 200);
            $this->data['page_keywords'] = mb_substr(strip_tags($post->tags != '[]' ?
                implode(', ', json_decode($post->tags)) . ', ' . $this->data['site']['settings']['keywords'] :
                $this->data['site']['settings']['keywords']), 0, 200);

            // Update post hits
            $current_date = date('Y-m-d 00:00:00', time());
            $this->db->query("UPDATE `" . $this->db->dbprefix .
                "blog_posts` SET `hits_today` = `hits_today` + 1,
                `hits_total` = `hits_total` + 1, `last_view` = '" . date_sql(time
                ()) . "' WHERE `id` = {$post->id} AND 
                `hits_today_date` = '" . $current_date . "'");
            if ($this->db->affected_rows() == 0)
            {
                $this->db->query("UPDATE `" . $this->db->dbprefix .
                    "blog_posts` SET `hits_today` = 1, `hits_today_date` = '" . $current_date . "',
                    `hits_total` = `hits_total` + 1, `last_view` = '" . date_sql
                    (time()) . "' WHERE `id` = {$post->id}");
            }

            $query1 = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                "notifications` WHERE `users_id` LIKE '%\"" . $this->iwb->user_id . "\"%' AND (`type` = 'blog_comments_published' OR `type` = 'blog_comments_moderated' OR `type` = 'blog_comments_spam') AND `code` = '" .
                $post->id . "'");
            if ($query1->num_rows() > 0)
            {
                foreach ($query1->result() as $read)
                {
                    $this->notifications_model->read($read);
                }
            }

            if ($this->data['site']['settings']['display_breadcrumb'] == 'yes')
            {
                $category_link = array();
                if ($post->categories == '[]')
                {
                    $category_link[] = '<a href="' . $this->data['site']['url'] .
                        '/category/uncategorized/1.html">Uncategorized</a>';
                }
                else
                {
                    $cats = json_decode($post->categories);
                    foreach ($cats as $cat)
                    {
                        $category_link[] = '<a href="' . $this->data['site']['url'] . '/category/' . $cat .
                            '/1.html">' . esc_html($this->data['blog_categories'][$cat]['name']) . '</a>';
                    }
                }
                $br = '<ul class="breadcrumb">';
                $br .= '<li><a href="' . $this->data['site']['url'] . '">Home</a></li>';
                $br .= '<li class="divider"><span>/</span></li>';
                $br .= '<li>' . implode(', ', $category_link) . '</li>';
                $br .= '<li class="divider"><span>/</span></li>';
                $br .= '<li class="active"><span>' . esc_html($post->title) . '</span></li>';
                $br .= '</ul>';
                $this->data['breadcrumb'] = $br;
            }
            else
            {
                $this->data['breadcrumb'] = '';
            }

            if (isset($category_link))
            {
                $this->data['post']->post_categories = implode(', ', $category_link);
            }
            else
            {
                $category_link = array();
                if ($post->categories == '[]')
                {
                    $category_link[] = '<a href="' . $this->data['site']['url'] .
                        '/category/uncategorized/1.html">Uncategorized</a>';
                }
                else
                {
                    $cats = json_decode($post->categories);
                    foreach ($cats as $cat)
                    {
                        $category_link[] = '<a href="' . $this->data['site']['url'] . '/category/' . $cat .
                            '/1.html">' . esc_html($this->data['blog_categories'][$cat]['name']) . '</a>';
                    }
                }
                $this->data['post']->post_categories = implode(', ', $category_link);
            }
            $this->data['post']->tags = implode(', ', tags_link($this->data['site']['url'] .
                '/tag/', $post->tags, '/1.html'));
            $this->data['recent_posts'] = null;
            if ($post->status == 'publish' && $this->data['site']['settings']['allow_comments'] ==
                'yes')
            {
                $this->data['allow_comments'] = true;
                if ($post->user_id == $this->iwb->user_id || (($this->data['site']['settings']['close_comment_older_posts'] ==
                    'no' || ($this->data['site']['settings']['close_comment_older_posts'] == 'yes' &&
                    $this->data['post']->time > (time() - 1209600))) && ($this->data['site']['settings']['comment_user'] ==
                    'all' || ($this->data['site']['settings']['comment_user'] == 'users' && $this->
                    data['is_user'] != 0) || ($this->data['site']['settings']['comment_user'] ==
                    'friends' && $this->data['is_friend'] != 0) || ($this->data['site']['settings']['comment_user'] ==
                    'followers' && $this->data['is_follower'] != 0))))
                {
                    $this->form_comment();
                    $this->data['allow_new_comment'] = true;
                }
                else
                {
                    $this->data['allow_new_comment'] = false;
                }
                $this->get_comments();
            }
            else
            {
                $this->data['allow_comments'] = false;
                $this->data['allow_new_comment'] = false;
            }
            if ($this->data['site']['settings']['posts_list_in_singlepost'] != 'none')
            {
                if ($this->data['site']['settings']['posts_list_in_singlepost'] ==
                    'recent_posts' || $post->categories == '[]')
                {
                    $this->data['site']['settings']['posts_list_in_singlepost'] = 'recent_posts';
                    $where = "";
                }
                else
                {
                    $categories = json_decode($post->categories);
                    $rand = rand(0, count($categories) - 1);
                    $where = "AND `categories` LIKE '%\"" . $categories[$rand] . "\"%'";
                }
                $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                    "blog_posts` WHERE `id` != '" . $post->id . "' AND `site_id` = '" . $post->
                    site_id . "' {$where} AND (`user_id` = '" . $this->iwb->user_id .
                    "' OR `visibility` = 'public' OR (`visibility` = 'friends' AND '1' = '" . $this->
                    data['is_friend'] . "') OR (`visibility` = 'followers' AND '1' = '" . $this->
                    data['is_follower'] .
                    "')) AND `status` = 'publish' ORDER BY `time` DESC LIMIT 3");
                if ($query->num_rows() != 0)
                {
                    $this->data['recent_posts'] = $query->result();
                }
            }
            $this->load_stats = true;
        }
        else
        {
            $this->data['post'] = null;
        }
        return $this->show_output();
    }

    private function singlepage($permalink)
    {
        $this->data['active_page'] = 'singlepage_page';
        $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
            "blog_posts` WHERE `site_id` = ? AND `link` = ? AND (`user_id` = '" . $this->
            iwb->user_id . "' OR `status` = 'publish') AND (`user_id` = '" . $this->iwb->
            user_id . "' OR `visibility` = 'public' OR (`visibility` = 'friends' AND '1' = '" .
            $this->data['is_friend'] . "') OR (`visibility` = 'followers' AND '1' = '" . $this->
            data['is_follower'] . "')) AND `type` = 'page' LIMIT 1", array(
            $this->data['site']['id'],
            $permalink,
            ));
        if ($query->num_rows() > 0)
        {
            $this->load_stats = true;
            $this->data['page'] = $query->row();
        }
        else
        {
            $this->data['page'] = null;
        }
        return $this->show_output();
    }

    private function error_page($message = 'Page not found.')
    {
        $this->data['active_page'] = 'error_page';
        $this->data['error_message'] = $message;
        return $this->show_output();
    }

    private function form_comment()
    {
        $subscriber = json_decode($this->data['post']->comments_subscribe);
        if ($this->iwb->is_user && in_array($this->iwb->user_id, $subscriber))
        {
            $this->data['subscribe_comment'] = true;
        }
        else
        {
            $this->data['subscribe_comment'] = false;
        }
        $this->data['new_comment_published'] = $this->session->flashdata('new_comment_published') != null ?
            $this->session->flashdata('new_comment_published') : false;
        $this->data['new_comment_moderated'] = $this->session->flashdata('new_comment_moderated') != null ?
            $this->session->flashdata('new_comment_moderated') : false;
        $this->data['new_comment_errors'] = false;
        $this->data['form_comment_value'] = array(
            'author' => $this->iwb->is_user ? $this->iwb->user->name : ($this->session->
                has_userdata('author_name') ? $this->session->userdata('author_name') : ''),
            'email' => $this->iwb->is_user ? $this->iwb->user->email : ($this->session->
                has_userdata('author_email') ? $this->session->userdata('author_email') : ''),
            'homepage' => $this->iwb->is_user ? $this->iwb->user->site : ($this->session->
                has_userdata('author_homepage') ? $this->session->userdata('author_homepage') :
                ''),
            'comment_text' => '',
            );
        if (($this->data['site']['settings']['comment_captcha'] == 'always' || ($this->
            data['site']['settings']['comment_captcha'] == 'guests' && $this->data['is_guest'] ==
            1)) && ($this->iwb->user_id != $this->data['site']['author_id']))
        {
            $this->data['form_comment_captcha'] = true;
        }
        else
        {
            $this->data['form_comment_captcha'] = false;
        }

        if ($this->input->post('send_comment'))
        {
            $this->load->helper('htmlpurifier');
            $input = array(
                'author' => trim($this->input->post('author', true)),
                'email' => trim(strtolower($this->input->post('email', true))),
                'homepage' => trim($this->input->post('homepage', true)),
                'comment_text' => html_purify(trim($this->input->post('comment_text')),
                    'comment'),
                'captcha' => trim($this->input->post('captcha', true)),
                );
            $this->load->library('form_validation');
            $this->form_validation->set_data($input);
            $this->form_validation->set_rules('author', 'Name',
                'required|min_length[2]|max_length[18]|alpha_numeric_spaces' . (!$this->iwb->
                is_user ? '|is_unique[users.name]' : ''), array('is_unique' =>
                    'Please use other Name.'));
            if ($this->data['site']['settings']['comment_require_email'] == 'yes')
                $email_rules = 'required|min_length[10]|max_length[50]|valid_email';
            else
                $email_rules = 'min_length[10]|max_length[50]|valid_email';
            $this->form_validation->set_rules('email', 'Email', $email_rules);
            $this->form_validation->set_rules('homepage', 'Homepage', array(
                'valid_url',
                array('validate_url', function ($url)
                    {
                        if (!filter_var($url, FILTER_VALIDATE_URL, FILTER_FLAG_SCHEME_REQUIRED))
                        {
                            $this->form_validation->set_message('validate_url', 'Incorrect URL.'); return false; }
                        return true; }
                    ),
                ));
            $probabilities = 0;
            $this->form_validation->set_rules('comment_text', 'Comment', array(
                'required',
                'min_length[2]',
                'max_length[1024]',
                array('spam_check', function ($text)use (&$probabilities)
                    {
                        $probability = word_count($text, array('http://', 'https://')); $probabilities +=
                            $probability; if ($probability > 5)
                        {
                            $this->form_validation->set_message('spam_check', 'Spammer!'); return false; }
                        return true; }
                    ),
                ));
            if ($this->data['form_comment_captcha'])
            {
                $this->form_validation->set_rules('captcha', 'Captcha', array(
                    'required',
                    'exact_length[5]',
                    array('validate_captcha', function ($captcha)
                        {
                            if (!$this->session->has_userdata('iwb_sess') || md5(strtolower($captcha)) != $this->
                                session->userdata('iwb_sess'))
                            {
                                $this->form_validation->set_message('validate_captcha', 'Wrong Captcha code.');
                                    $this->session->unset_userdata('iwb_sess'); return false; }
                            $this->session->unset_userdata('iwb_sess'); return true; }
                        ),
                    ));
            }

            if ($this->form_validation->run() != false)
            {
                if ($this->iwb->user_id == $this->data['site']['author_id'] || $this->iwb->
                    user_rights == 10)
                {
                    $status = 'published';
                    $message = 'Comment successfully added and has been published.';
                }
                elseif ($this->data['site']['settings']['comment_moderation'] == 'on')
                {
                    $status = 'moderated';
                    $message = 'Comment successfully added and will be published after administrator approval.';
                }
                else
                {
                    if ($probabilities > 2)
                    {
                        $status = 'spam';
                        $message = 'Comment successfully added and will be published after administrator approval.';
                    }
                    else
                    {
                        $status = 'published';
                        $message = 'Comment successfully added and has been published.';
                    }
                }
                if (!$this->iwb->is_user)
                {
                    $this->session->set_userdata('author_name', $input['author']);
                    $this->session->set_userdata('author_email', $input['email']);
                    $this->session->set_userdata('author_homepage', $input['homepage']);
                }
                $data = array(
                    'site_id' => $this->data['site']['id'],
                    'user_id' => $this->data['site']['author_id'],
                    'post_id' => $this->data['post']->id,
                    'author_id' => $this->iwb->user_id,
                    'author_name' => $input['author'],
                    'author_email' => $input['email'],
                    'author_homepage' => $input['homepage'],
                    'quote' => '',
                    'text' => nl2br($input['comment_text']),
                    'status' => $status,
                    'admin_read' => 0,
                    'time' => time(),
                    );
                $this->db->insert('blog_comments', $data);
                $id = $this->db->insert_id();

                $query_update = array();
                if ($status == 'published')
                {
                    $users_id = json_encode($subscriber);
                    if (count($subscriber) <= 1)
                    {
                        $auto_delete = 1;
                    }
                    else
                    {
                        $auto_delete = 0;
                    }
                    $query_update[] = "`total_comments` = `total_comments` + 1";
                }
                elseif ($status == 'moderated' || $status == 'spam')
                {
                    $users_id = '["' . $this->data['site']['author_id'] . '"]';
                    $auto_delete = 1;
                }
                $this->notifications_model->insert(array(
                    'users_id' => $users_id,
                    'users_read' => '["' . $this->iwb->user_id . '"]',
                    'type' => 'blog_comments_' . $status,
                    'code' => $this->data['post']->id,
                    'val1' => $input['author'],
                    'val2' => $this->data['post']->title . ' | ' . $this->data['site']['name'],
                    'val3' => mb_substr(strip_tags($input['comment_text']), 0, 150),
                    'auto_delete' => $auto_delete,
                    'link' => ($status == 'spam' ? site_url('account/switch_blog/' . $this->data['site']['id'] .
                        '?redirect_uri=' . urlencode(site_url('panel/comments/spam'))) : $this->data['site']['url'] .
                        '/login.html?redirect_uri=' . urlencode($this->data['site']['url'] . '/' . $this->
                        data['post']->link . '.html?ref=notifications#comment-' . $id)),
                    'time' => time(),
                    ));
                if ($this->iwb->is_user)
                {
                    if ($this->input->post('subscribe') && $this->iwb->user_id != $this->data['site']['author_id'])
                    {
                        $type = $this->input->post('subscribe');
                        if ($type == 1)
                        {
                            $new_subscribe = json_encode(array_merge(array($this->iwb->user_id), $subscriber));
                        }
                        else
                        {
                            $new_subscribe = json_encode(array_values(array_diff($subscriber, array($this->
                                    iwb->user_id))));
                        }
                        $query_update[] = "`comments_subscribe` = '" . $new_subscribe . "'";
                    }
                }
                $query_update[] = "`last_comment` = '" . time() . "'";
                $this->db->query("UPDATE `" . $this->db->dbprefix . "blog_posts` SET " . implode
                    (', ', $query_update) . " WHERE `id` = '" . $this->data['post']->id . "'");

                $this->session->set_flashdata('new_comment_' . ($status == 'published' ?
                    'published' : 'moderated'), $message);
                redirect($this->data['site']['url'] . '/' . $this->data['post']->link .
                    '.html#new-comment');
            }
            else
            {
                $errors = $this->form_validation->error_array();
                if (array_key_exists('author', $errors))
                {
                    $input['author'] = '';
                }
                if (array_key_exists('email', $errors))
                {
                    $input['email'] = '';
                }
                if (array_key_exists('homepage', $errors))
                {
                    $input['homepage'] = '';
                }
                $this->data['form_comment_value'] = $input;
                $this->data['new_comment_errors'] = $errors;
            }
        }
        $this->data['form_comment_open'] = '<form action="' . $this->data['site']['url'] .
            '/' . $this->data['post']->link .
            '.html#new-comment" method="post" accept-charset="utf-8">' .
            '<input type="hidden" name="' . $this->security->get_csrf_token_name() .
            '" value="' . $this->security->get_csrf_hash() .
            '" style="display:none;" /><input type="hidden" name="send_comment" ' .
            'value="true" style="display:none;" />';
        $this->data['form_comment_close'] = '</form>';
    }

    private function get_comments()
    {
        $this->data['total_comments'] = $this->data['post']->total_comments;
        if ($this->data['post']->total_comments > 0)
        {
            $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                "blog_comments` WHERE `post_id` = '" . $this->data['post']->id .
                "' AND (`user_id` = '" . $this->iwb->user_id .
                "' OR `status` = 'published') AND `status` != 'spam' ORDER BY `time` ASC");
            $this->data['comments'] = $query->result();
        }
    }

    private function follow()
    {
        $this->data['page_title'] = 'Follow | ' . $this->data['site']['name'];
        if (!$this->iwb->is_user)
        {
            redirect($this->data['site']['url'] . "/login.html?redirect_uri=" . urlencode($this->
                data['site']['url'] . "/follow.html"));
            return;
        }
        if ($this->iwb->user_id == $this->data['site']['author_id'])
        {
            $this->data['active_page'] = 'error_page';
            $this->data['error_message'] = 'You can not follow your blog.';
            return $this->show_output();
        }
        elseif ($this->data['is_follower'])
        {
            $this->data['message'] = '<strong>You \'ve been following this blog</strong>.<br/>Do you want to unfollow this blog?';
        }
        else
        {
            $this->data['message'] = 'Do you want to follow this blog?';
        }
        if ($this->input->post())
        {
            $updates = array();
            if ($this->data['is_follower'])
            {
                $updates['followers'] = json_encode(array_values(array_diff($this->data['site']['followers'],
                    array($this->iwb->user_id))));
                $updates['followers_total'] = $this->data['site']['followers_total'] - 1;
            }
            else
            {
                $updates['followers'] = json_encode(array_merge(array($this->iwb->user_id), $this->
                    data['site']['followers']));
                $updates['followers_total'] = $this->data['site']['followers_total'] + 1;
            }
            $this->db->where('id', $this->data['site']['id'])->update('blog_sites', $updates);
            $this->notifications_model->insert(array(
                'users_id' => '["' . $this->data['site']['author_id'] . '"]',
                'users_read' => '["0"]',
                'type' => 'blog_follow',
                'code' => $this->data['site']['id'],
                'val1' => $this->iwb->user->name,
                'val2' => $this->data['site']['name'],
                'auto_delete' => 1,
                'link' => site_url('account/switch_blog/' . $this->data['site']['id'] .
                    '?redirect_uri=' . urlencode(site_url('panel/followers'))),
                'time' => time(),
                ));
            redirect($this->data['site']['url'] . '/');
            return;
        }
        $this->load_stats = true;
        $this->data['active_page'] = 'follow_page';
        $this->data['form_follow_open'] = '<form action="' . $this->data['site']['url'] .
            '/follow.html" method="post" accept-charset="utf-8">' .
            '<input type="hidden" name="' . $this->security->get_csrf_token_name() .
            '" value="' . $this->security->get_csrf_hash() .
            '" style="display:none;" /><input type="hidden" name="confirm" ' .
            'value="true" style="display:none;" />';
        $this->data['form_follow_close'] = '</form>';
        return $this->show_output();
    }

    private function show_output()
    {
        $this->load_template();
        try
        {
            if ($this->load_stats == true)
            {
                $this->load->library('blog_stats', $this->data['site']);
                $this->blog_stats->analytics();
            }
            if (file_exists(FCPATH . 'files/blogs/' . $this->data['site']['id'] .
                '/templates/' . $this->theme . '/style.css'))
            {
                $this->data['css_style'] = strip_tags(file_get_contents(FCPATH . 'files/blogs/' .
                    $this->data['site']['id'] . '/templates/' . $this->theme . '/style.css'));
            }
            else
            {
                $this->data['css_style'] = '';
            }
            echo $this->tpl->render('layout.html', $this->data);
        }
        catch (exception $e)
        {
            die($e->getMessage());
        }
        $this->db->close();
        die();
    }

    private function login()
    {
        if ($this->input->get('iwb_auth_token') != null)
        {
            $token_code = $this->input->get('iwb_auth_token', true);
            if (mb_strlen($token_code) != 32)
            {
                return $this->error_page('Invalid token.');
            }

            $query = $this->db->where('token', $token_code)->where('expires >', time())->
                get('tokens');
            if ($query->num_rows() != 1)
            {
                return $this->error_page('Incorrect token.');
            }

            $token = $query->row();
            $user = $this->db->where('id', $token->user_id)->get('users')->row();
            $this->session->set_userdata('client_secret', base64_encode($user->id));
            $this->session->set_userdata('client_key', $user->token);
            $this->db->where('id', $token->id)->delete('tokens');
            if ($this->session->has_userdata('redirect_uri'))
            {
                $url = base64_decode($this->session->userdata('redirect_uri'));
                $this->session->unset_userdata('redirect_uri');
                redirect($url);
            }
            else
            {
                redirect($this->data['site']['url']);
            }
        }
        else
        {
            if ($this->input->get('redirect_uri', true) != null)
            {
                $redirect = esc_html(urldecode($this->input->get('redirect_uri', true)));
                $redireect = stripos($redirect, 'login.html') !== false ? $this->data['site']['url'] :
                    $redirect;
            }
            elseif ($this->input->server('HTTP_REFERER') != null)
            {
                $redirect = esc_html($this->input->server('HTTP_REFERER'));
            }
            else
            {
                $redireect = $this->data['site']['url'];
            }
            if ($this->iwb->is_user)
            {
                redirect($redirect);
            }
            $this->session->set_userdata('redirect_uri', base64_encode($redirect));
            redirect('site/auth/' . $this->config->item('server_name'));
        }
    }

    private function logout()
    {
        if ($this->input->server('HTTP_REFERER') != null)
        {
            $redirect = $this->input->server('HTTP_REFERER');
        }
        else
        {
            $redirect = $this->data['site']['url'];
        }
        $this->session->sess_destroy();
        redirect($redirect);
    }
}

?>