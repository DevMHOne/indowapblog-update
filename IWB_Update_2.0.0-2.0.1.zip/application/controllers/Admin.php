<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends IWB_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->iwb->is_user)
        {
            $this->session->set_userdata('login_redirect', current_url());
            redirect('site/login');
        }
        if ($this->iwb->user->rights != 10)
        {
            show_error(lang('iwb_error_403') . '.');
        }

    }

    public function index()
    {
        $data = array();
        $prefix = $this->db->dbprefix;
        $sql = array();
        $sql[] = "(SELECT COUNT(*) AS `total` FROM `{$prefix}blog_sites`)";
        $sql[] = "(SELECT COUNT(*) FROM `{$prefix}blog_sites` WHERE `mod_reg` =  'yes')";
        $sql[] = "(SELECT COUNT(*) FROM `{$prefix}blog_sites` WHERE `block` =  'yes')";

        $sql_query = implode(" UNION ALL ", $sql);
        $query = $this->db->query($sql_query);
        $data['total'] = $query->result_array();
        $this->breadcrumbs->set('Admin Panel');

        $this->load->view('includes/header');
        $this->load->view('admin/index', $data);
        $this->load->view('includes/footer');
    }

    public function blog($show = 'all')
    {
        $data = array();
        $data['current_page'] = get_current_page();
        if ($show == 'moderated')
        {
            $where = " WHERE `b`.`mod_reg` = 'yes'";
            $data['show'] = 'moderated';
        }
        elseif ($show == 'blocked')
        {
            $where = " WHERE `b`.`block` = 'yes'";
            $data['show'] = 'blocked';
        }
        else
        {
            $where = '';
            $data['show'] = 'all';
        }
        $data['total'] = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->db->
            dbprefix . "blog_sites` AS `b`" . $where)->row()->num;
        if ($data['total'])
        {
            $query = $this->db->query("SELECT `b`.*, `u`.`username` AS `user_username`, `u`.`name` AS `user_name` FROM `" .
                $this->db->dbprefix . "blog_sites` AS `b`" . $where . " LEFT JOIN `" . $this->
                db->dbprefix . "users` AS `u` ON `b`.`user_id` = `u`.`id` ORDER BY `b`.`created` DESC LIMIT " .
                sql_offset($this->iwb->user_set['offset'], $data['current_page']) . ", " . $this->
                iwb->user_set['offset']);
            $data['blogs'] = $query->result();
        }
        $this->breadcrumbs->set('Admin Panel', 'admin');
        $this->breadcrumbs->set('Blog', '', true);
        $this->load->view('includes/header');
        $this->load->view('admin/blog', $data);
        $this->load->view('includes/footer');
    }

    public function iwb_update($page = '')
    {
        $this->breadcrumbs->set('Admin Panel', 'admin');
        $this->breadcrumbs->set('IWB Update');
        if (!$update = @file_get_contents($this->iwb->set['iwb_update_url'] . (strpos($this->
            iwb->set['iwb_update_url'], '?') !== false ? '&' : '?') . 'v=' . $this->iwb->
            set['iwb_version']))
        {
            return $this->display_error('Can not check for update.');
        }
        $iwb = json_decode($update, true);

        switch ($page)
        {
            case 'auto_update':
                return $this->iwb_auto_update($iwb);
                break;
            default:
                break;
        }

        $this->load->view('includes/header');
        $this->load->view('admin/iwb_update/index', array('iwb' => $iwb));
        $this->load->view('includes/footer');
    }

    protected function iwb_auto_update($iwb)
    {
        $step = abs(intval($this->input->get('step', true)));
        $step = $step == 0 ? 1 : $step;
        if (!array_key_exists($this->iwb->set['iwb_version'], $iwb))
        {
            return $this->display_error('Tidak ada pembaruan yang tersedia.');
        }
        $name = url_title($iwb[$this->iwb->set['iwb_version']]['version'], '_', true);
        $filename = 'update-' . $name . '.zip';

        $output = '<!DOCTYPE html><html><head><title>Installasi Pembaruan IWB</title>' .
            '<meta http-equiv="refresh" content="5;URL=' . site_url('admin/iwb_update/auto_update?step=' .
            ($step + 1)) . '" /></head><body>' .
            '<h2 style="margin:15px 10px;text-align:center;">Step ' . $step .
            '</h2><p style="margin:15px 10px;text-align:center;"><img src="' . base_url('images/ajax-loader.gif') .
            '"/><br/>Mohon tunggu, kamu akan dialihkan secara otomatis atau <a href="' .
            site_url('admin/iwb_update/auto_update?step=' . ($step + 1)) .
            '">klik di sini</a> untuk melanjutkan.</p></body></html>';
        switch ($step)
        {
            case 1;
                if (!copy($iwb[$this->iwb->set['iwb_version']]['file'], FCPATH . 'files/tmp/' .
                    $filename))
                {
                    return $this->display_error('Tidak dapat mendownload file.');
                }
                echo $output;
                break;

            case 2:
                $zip = new ZipArchive;
                if ($zip->open(FCPATH . 'files/tmp/' . $filename) === true)
                {
                    $zip->extractTo(FCPATH);
                    $zip->close();
                    unlink(FCPATH . 'files/tmp/' . $filename);
                    echo $output;
                }
                else
                {
                    unlink(FCPATH . 'files/tmp/' . $filename);
                    return $this->display_error('Tidak dapat mengekstrak file.');
                }
                break;

            case 3:
                $this->db->insert('update', array(
                    'version' => $iwb[$this->iwb->set['iwb_version']]['version'],
                    'updated' => $iwb[$this->iwb->set['iwb_version']]['updated'],
                    'file' => $iwb[$this->iwb->set['iwb_version']]['file'],
                    'changelog' => json_encode($iwb[$this->iwb->set['iwb_version']]['changelog']),
                    'message' => $iwb[$this->iwb->set['iwb_version']]['message'],
                    'installed' => date_sql(time()),
                    ));
                $lname = 'Install_Update_' . $name;
                $library = strtolower($lname);
                $this->load->library($library);
                $this->$library->install();
                break;

            default:
                break;
        }
    }

    public function delete_post($id = 0)
    {
        $query = $this->db->where('id', $id)->get('blog_posts');
        if ($query->num_rows() == 0)
        {
            return $this->display_error('Post not found.');
        }
        $post = $query->row();
        if ($this->input->post())
        {
            $this->db->where('id', $id)->delete('blog_posts');
            $this->db->where(array('site_id' => $post->site_id, 'post_id' => $id))->delete('blog_comments');
            $this->db->query("DELETE FROM `" . $this->db->dbprefix . "notifications` 
                WHERE (`type` = 'blog_comments_published' 
                OR `type` = 'blog_comments_moderated' 
                OR `type` = 'blog_comments_spam' 
                OR `type` = 'fl_new_post') 
                AND `code` = '{$id}'");
            if ($post->categories != '[]')
            {
                $this->db->query("UPDATE `" . $this->db->dbprefix .
                    "blog_categories` SET `total_posts` = `total_posts` - 1 WHERE `site_id` = '" . $post->
                    site_id . "' AND `link` IN ('" . implode("','", json_decode($post->categories)) .
                    "')");
            }
            $this->session->set_flashdata('alert-success', 'Post deleted.');
            redirect($this->get_redirect('admin'));
        }
        return $this->confirm(current_url() . '?redirect_uri=' . urlencode($this->
            get_redirect('admin')), 'Are you sure you want to delete this post?', $this->
            get_redirect('admin'));
    }

    public function block_blog($id = 0)
    {
        $query = $this->db->where('id', $id)->get('blog_sites');
        if ($query->num_rows() == 0)
        {
            return $this->display_error('Blog not found.');
        }
        $blog = $query->row();
        if ($blog->block == 'yes')
        {
            return $this->display_error('This blog has been blocked.');
        }
        if ($this->input->post())
        {
            $this->db->where('id', $id)->update('blog_sites', array('block' => 'yes'));
            $this->session->set_flashdata('alert-success', 'Blog successfully blocked.');
            redirect($this->get_redirect('admin'));
        }
        return $this->confirm(current_url() . '?redirect_uri=' . urlencode($this->
            get_redirect('admin')), 'Are you sure you want to block this blog?', $this->
            get_redirect('admin'));
    }

    public function unblock_blog($id = 0)
    {
        $query = $this->db->where('id', $id)->get('blog_sites');
        if ($query->num_rows() == 0)
        {
            return $this->display_error('Blog not found.');
        }
        $blog = $query->row();
        if ($blog->block == 'no')
        {
            return $this->display_error('This blog has not blocked.');
        }
        if ($this->input->post())
        {
            $this->db->where('id', $id)->update('blog_sites', array('block' => 'no'));
            $this->session->set_flashdata('alert-success', 'Blog successfully unblocked.');
            redirect($this->get_redirect('admin'));
        }
        return $this->confirm(current_url() . '?redirect_uri=' . urlencode($this->
            get_redirect('admin')), 'Are you sure you want to unblock this blog?', $this->
            get_redirect('admin'));
    }

    public function delete_blog($id = 0)
    {
        $query = $this->db->where('id', $id)->get('blog_sites');
        if ($query->num_rows() == 0)
        {
            return $this->display_error('Blog not found.');
        }
        $blog = $query->row();
        if ($this->input->post())
        {
            $this->db->where('id', $blog->id)->delete('blog_sites');
            $this->db->where('site_id', $blog->id)->delete('blog_posts');
            $this->db->where('site_id', $blog->id)->delete('blog_comments');
            $this->db->where('site_id', $blog->id)->delete('blog_categories');
            rmdir_recursive(FCPATH . 'files/blogs/' . $blog->id);
            $this->session->set_flashdata('alert-success', 'Blog successfully deleted.');
            redirect($this->get_redirect('admin'));
        }
        return $this->confirm(current_url() . '?redirect_uri=' . urlencode($this->
            get_redirect('admin')), 'Are you sure you want to delete this blog?', $this->
            get_redirect('admin'));
    }

    public function settings($setting = '')
    {
        if (in_array($setting, array('blog', 'general')))
        {
            $set_method = $setting . '_settings';
            return $this->$set_method();
        }
        else
        {
            redirect('admin/settings/general');
        }
    }

    private function blog_settings()
    {
        $data = array();
        $data['set'] = array_merge($this->iwb->set, $this->iwb->get_setting(array(
            'domains',
            'subdomain_disallow',
            'diff_time_blog',
            'mod_new_blog',
            'max_user_blogs',
            'blog_categories',
            'upload_file_types',
            'upload_file_size',
            )));
        if ($this->input->post())
        {
            $this->load->library('form_validation');
            $input = array(
                'domains' => strtolower($this->input->post('domains')),
                'subdomain_disallow' => json_encode(str_tags(strtolower($this->input->post('subdomain_disallow')))),
                'diff_time_blog' => abs(intval($this->input->post('diff_time_blog'))),
                'mod_new_blog' => $this->input->post('mod_new_blog'),
                'max_user_blogs' => abs(intval($this->input->post('max_user_blogs'))),
                'upload_file_types' => json_encode(str_tags(strtolower($this->input->post('upload_file_types')))),
                'blog_categories' => preg_split("/[,]+/", $this->input->post('blog_categories')),
                'upload_file_size' => abs(intval($this->input->post('upload_file_size'))),
                );
            $this->form_validation->set_data($input);
            $this->form_validation->set_rules('domains', 'Domains', array('required', array
                    ('blog_domains', function ()use($data, &$input)
                    {
                        $input['domains'] = preg_split("/[,]+/", $input['domains']); $domains =
                            json_decode($data['set']['domains']); foreach ($domains as $domain)
                        {
                            if (!in_array($domain, $input['domains']))
                            {
                                $this->form_validation->set_message('blog_domains', 'Domain ' . $domain .
                                    ' can not be removed.'); return false; }
                            return true; }
                    }
                    )));
            $this->form_validation->set_rules('mod_new_blog', 'Moderation new blog',
                'in_list[yes,no]');
            if ($this->form_validation->run() != false)
            {
                $input['domains'] = json_encode($input['domains']);
                $rcat = array();
                foreach (json_decode($data['set']['blog_categories']) as $cat)
                {
                    if (!in_array($cat, $input['blog_categories']))
                    {
                        $rcat[] = $cat;
                    }
                }
                if ($rcat)
                {
                    $this->db->where_in('category', $rcat)->update('blog_sites', array('category' =>
                            ''));
                }
                sort($input['blog_categories']);
                $input['blog_categories'] = json_encode($input['blog_categories']);
                foreach ($input as $key => $val)
                {
                    $this->db->where('set_key', $key)->update('settings', array('set_value' => $val));
                }
                $this->session->set_flashdata('alert-success', 'Change saved.');
                redirect('admin');
            }
        }
        $this->breadcrumbs->set('Admin Panel', 'admin');
        $this->breadcrumbs->set('Settings', 'admin/settings', true);
        $this->breadcrumbs->set('Blog');

        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('admin/settings/blog', $data);
        $this->load->view('includes/footer');
    }

    private function general_settings()
    {
        $data = array();
        $data['set'] = array_merge($this->iwb->set, $this->iwb->get_setting(array('site_email', )));
        if ($this->input->post())
        {
            $this->load->library('form_validation');
            $input = array(
                'site_name' => trim($this->input->post('site_name')),
                'site_email' => trim($this->input->post('site_email')),
                'time_zone' => $this->input->post('time_zone'),
                'offset' => $this->input->post('offset'),
                );
            $this->form_validation->set_data($input);
            $this->form_validation->set_rules('site_name', 'Site Name',
                'required|max_length[30]');
            $this->form_validation->set_rules('site_email', 'Site Email',
                'required|valid_email');
            $this->form_validation->set_rules('time_zone', 'Time Zone', 'required|in_list[' .
                implode(',', array_keys(timezones())) . ']');
            $this->form_validation->set_rules('offset', 'List Per Page',
                'required|in_list[5,10,15,20]');
            if ($this->form_validation->run() != false)
            {
                foreach ($input as $t_k => $t_v)
                {
                    $this->db->where('set_key', $t_k)->update('settings', array('set_value' => $t_v));
                }
                $this->session->set_flashdata('alert-success', lang('iwb_change_saved'));
                redirect('admin');
            }
        }
        $this->breadcrumbs->set('Admin Panel', 'admin');
        $this->breadcrumbs->set('Settings', 'admin/settings', true);
        $this->breadcrumbs->set('General');

        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('admin/settings/general', $data);
        $this->load->view('includes/footer');
    }
}
