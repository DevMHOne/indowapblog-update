IndoWapBlog v1.0.0
Rilis: 2011-03-14

IndoWapBlog v2.0.0
Rilis: 2016-06-22
Changelog: Menggunakan CodeIgniter dan Bootstrap Template

IndoWapBlog v2.0.1
Rilis: 2016-06-23
Changelog: Perbaikan bugs