<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */


defined('BASEPATH') or exit('No direct script access allowed');

class Site extends IWB_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->lang->load('site');
    }

    public function index()
    {
        $data = array();
        $query = $this->db->select('n.*,u.name')->from('news as n')->join('users as u',
            'n.user_id = u.id')->where('n.time >', time() - (3600 * 24 * 7))->order_by('n.time',
            'DESC')->limit(3)->get();
        $data['news'] = $query->result();
        $query = $this->db->query("SELECT `id`,`username`,`name` FROM `" . $this->db->
            dbprefix . "users` WHERE `ban` = '0' AND `last_date` != '0' ORDER BY RAND() LIMIT 5");
        $data['random_users'] = $query->result();
        $query = $this->db->query("SELECT `p`.`title`,`p`.`link`,`p`.`time`, `s`.*, `u`.`name` AS `author_name`, `u`.`username` AS `author_username` FROM `" .
            $this->db->dbprefix . "blog_posts` AS `p` LEFT JOIN `" . $this->db->dbprefix .
            "blog_sites` AS `s` ON `p`.`site_id` = `s`.`id` LEFT JOIN `" . $this->db->
            dbprefix . "users` AS `u` ON `p`.`user_id` = `u`.`id` WHERE `p`.`status` = 'publish'  AND `p`.`type` = 'post' ORDER BY `p`.`time` DESC LIMIT " .
            $this->iwb->set['offset']);
        $data['recent_posts'] = $query->result();
        $data['total_users'] = $this->db->count_all('users');
        $data['total_chat'] = $this->db->where('place', 'chat/')->count_all_results('users');
        $data['total_quiz'] = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . $this->
            db->dbprefix . "quiz_ask` WHERE `start_time` < ? AND `end_time` > ? AND `winner` = ?",
            array(
            time(),
            time(),
            '0',
            ))->row()->total;
        $this->load->view('includes/header');
        $this->load->view('site/index', $data);
        $this->load->view('includes/footer');
    }

    public function language()
    {
        $lng = esc_html($this->input->get('lang', true));
        if ($lng)
        {
            if (!in_array($lng, $this->config->item('languages')))
            {
                $lng = $this->config->item('language');
            }
            $this->session->set_userdata('lang', $lng);
            redirect($this->input->server('HTTP_REFERER'));
        }
        $this->breadcrumbs->set('Bahasa', '', true);
        $this->load->view('includes/header');
        $this->load->view('site/language', array('languages' => $this->config->item('languages')));
        $this->load->view('includes/footer');
    }

    public function logout()
    {
        if (!$this->iwb->is_user)
        {
            redirect('site/index');
        }

        $this->load->helper('form');
        if ($this->input->post('submit'))
        {
            $this->db->where('id', $this->iwb->user->id)->update('users', array('token' =>
                    md5(random_str(12))));

            set_cookie('uid', '', time() - 3600);
            set_cookie('upw', '', time() - 3600);
            $this->session->sess_destroy();
            redirect('site/index');
        }
        $this->breadcrumbs->set(lang('iwb_logout'));
        return $this->confirm('site/logout', lang('site_logout_conf'));
    }

    public function forgot_password($act = '')
    {
        $this->db->where('expires <', date_sql(time()))->delete('verifications');
        if ($this->iwb->is_user)
        {
            redirect('site/index');
        }
        elseif ($act == 'confirm')
        {
            $code = $this->input->get('code');
            $query = $this->db->where('code', $code)->get('verifications');
            if ($query->num_rows() == 0)
            {
                $this->session->set_flashdata('alert-danger', 'Kode verifikasi tidak benar!');
                redirect('site/forgot_password');
            }
            $ver = $query->row();
            $new_pass = random_str(6);
            $this->db->where('id', $ver->user_id)->update('users', array('password' => md5(md5
                    ($new_pass))));
            $this->db->where('id', $ver->id)->delete('verifications');
            $us = $this->db->select('email')->where('id', $ver->user_id)->get('users')->row();

            $config['charset'] = 'iso-8859-1';
            $config['wordwrap'] = true;
            $this->load->library('email');
            $this->email->initialize($config);
            $this->email->from($this->iwb->get_setting('site_email'), esc_html($this->iwb->
                set['site_name']));
            $this->email->to($us->email);
            $this->email->subject('Kata Sandi Baru');
            $this->email->message("Kata sandi baru Anda adalah: " . $new_pass . "\r\n" .
                "Silakan masuk ke akun anda melalui link " . site_url('site/login'));
            if ($this->email->send() == true)
            {
                $this->session->set_flashdata('alert-success',
                    'Kata sandi baru telah dikirim ke email Anda.<br/>Silakan periksa kotak masuk email tersebut.');
            }
            else
            {
                $this->session->set_flashdata('alert-success', 'Kata sandi baru Anda adalah: ' .
                    $new_pass);
            }
            redirect('site/login');
        }
        $this->breadcrumbs->set(lang('site_fp'), '', true);
        $this->load->library('form_validation');

        if ($this->input->post())
        {
            $user = null;
            $this->form_validation->set_rules('usermail', lang('site_fp_user'), array(
                'required',
                'min_length[4]',
                array('usermail', function ($usermail)use (&$user)
                    {
                        $query = $this->db->where('username', $usermail)->or_where('email', $usermail)->
                            get('users'); if ($query->num_rows() == 0)
                        {
                            $this->form_validation->set_message('usermail', lang('site_fp_user_404'));
                                return false; }
                        $user = $query->row(); return true; }
                    ),
                ));
            $this->form_validation->set_rules('captcha', lang('iwb_captcha'), 'captcha');
            if ($this->form_validation->run() != false)
            {
                $config['charset'] = 'iso-8859-1';
                $config['wordwrap'] = true;
                $code = random_str(12);
                $this->load->library('email');
                $this->email->initialize($config);
                $this->email->from($this->iwb->get_setting('site_email'), esc_html($this->iwb->
                    set['site_name']));
                $this->email->to($user->email);
                $this->email->subject(lang('site_fp'));
                $this->email->message(strtr(lang('site_fp_email_msg'), array(
                    '{site_name' => esc_html($this->iwb->set['site_name']),
                    '{link}' => site_url('site/forgot_password/confirm/?code=' . $code),
                    )));
                $data_sql = array(
                    'user_id' => $user->id,
                    'site_id' => 0,
                    'type' => 'forgot_pass',
                    'code' => $code,
                    'expires' => date_sql(time() + 3600),
                    );
                if ($this->email->send() == true)
                {
                    $this->db->where(array(
                        'user_id' => $data_sql['user_id'],
                        'type' => $data_sql['type'],
                        ))->update('verifications', $data_sql);
                    if ($this->db->affected_rows() == 0)
                    {
                        $this->db->insert('verifications', $data_sql);
                    }
                    $this->session->set_flashdata('alert-success', lang('site_fp_email_sent'));
                    redirect('site/index');
                }
                else
                {
                    $this->session->set_flashdata('alert-danger', lang('iwb_error_sent_email'));
                    redirect('site/forgot_password');
                }
            }
        }
        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('site/forgot_password');
        $this->load->view('includes/footer');
    }

    public function auth($server_name = '')
    {
        $this->db->where('expires <', time())->delete('tokens');

        $domain = explode('.', strtolower($server_name), 2);
        $query = $this->db->where(array('subdomain' => $domain[0], 'domain' => $domain[1]))->
            get('blog_sites');
        if ($query->num_rows() != 1)
        {
            return $this->display_error(lang('iwb_blog_not_found') . '.');
        }
        $blog = $query->row();
        if ($this->iwb->is_user)
        {
            $blog_url = blog_url($blog);
            if ($this->iwb->user->token_requests % 5)
            {
                $continue = true;
            }
            else
            {
                $continue = false;
            }
            if ($this->input->post() || $continue || $blog->user_id == $this->iwb->user_id)
            {
                $token = md5(random_str(10));
                $this->db->where('user_id', $this->iwb->user_id)->delete('tokens');
                $this->db->insert('tokens', array(
                    'user_id' => $this->iwb->user_id,
                    'token' => $token,
                    'expires' => (time() + 120),
                    ));
                $this->db->query("UPDATE `" . $this->db->dbprefix .
                    "users` SET `token_requests` = `token_requests` + 1 WHERE `id` = '{$this->iwb->user_id}'");
                redirect($blog_url . '/login.html?iwb_auth_token=' . $token);
            }
            $this->load->helper('form');
            $this->load->view('site/auth', array(
                'blog_url' => $blog_url,
                'blog_name' => $blog->name,
                ));
        }
        else
        {
            $this->session->set_userdata('login_redirect', current_url());
            redirect('site/login');
        }
    }

    public function login()
    {
        if ($this->iwb->is_user)
        {
            if ($this->session->has_userdata('login_redirect'))
            {
                $redirect = $this->session->userdata('login_redirect');
                $this->session->unset_userdata('login_redirect');
            }
            else
            {
                $redirect = 'site/index';
            }
            redirect($redirect);
        }
        $this->load->model('user_model');
        $this->load->library('form_validation');
        if ($this->input->post())
        {
            $set_data = array(
                'username' => strtolower($this->input->post('username')),
                'password' => $this->input->post('password'),
                );
            $this->user_model->set_data($set_data);
            $this->form_validation->set_rules($this->user_model->rules('login'));
            if ($this->form_validation->run() != false)
            {
                $user_id = $this->user_model->get_data('id');
                $this->db->where('id', $user_id)->update('users', array('token' => md5(random_str
                        (12))));
                if ($this->input->post('remember_me') != null)
                {
                    set_cookie('uid', $user_id, 1209600);
                    set_cookie('upw', md5($this->user_model->get_data('password')), 1209600);
                }
                else
                {
                    $this->session->set_userdata('uid', $user_id);
                    $this->session->set_userdata('upw', md5($this->user_model->get_data('password')));
                }
                if ($this->session->userdata('login_redirect') != null)
                {
                    $redirect = $this->session->userdata('login_redirect');
                    $this->session->unset_userdata('login_redirect');
                }
                else
                {
                    $redirect = 'account';
                }
                redirect($redirect);
            }
        }
        $this->breadcrumbs->set(lang('iwb_login'), '', true);
        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('site/login');
        $this->load->view('includes/footer');
    }

    public function registration()
    {
        if ($this->iwb->is_user)
        {
            redirect('site/index');
        }
        $this->breadcrumbs->set(lang('iwb_registration'), '', true);
        $this->load->helper('form');
        $this->load->model('user_model');
        if ($this->input->post())
        {
            $this->load->library('form_validation');
            $set_data = array(
                'username' => trim(strtolower($this->input->post('username'))),
                'password' => $this->input->post('password'),
                're_password' => $this->input->post('re_password'),
                'name' => trim($this->input->post('name')),
                'gender' => $this->input->post('gender'),
                'email' => trim(strtolower($this->input->post('email'))),
                'captcha' => $this->input->post('captcha'),
                );
            $this->user_model->set_data($set_data);
            $rules = $this->user_model->rules('registration');
            $this->form_validation->set_data($set_data);
            $this->form_validation->set_message('is_unique', lang('site_reg_exist'));
            $this->form_validation->set_rules($rules);
            if ($this->form_validation->run() != false)
            {
                $this->user_model->registration();
                $gender = array('m' => lang('iwb_male'), 'f' => lang('iwb_female'));
                $account_details = array(
                    'ID' => $this->user_model->get_data('id'),
                    $rules[0]['label'] => $this->user_model->get_data('username'),
                    $rules[1]['label'] => $this->user_model->get_data('password'),
                    $rules[3]['label'] => $this->user_model->get_data('name'),
                    $rules[4]['label'] => $gender[$this->user_model->get_data('gender')],
                    $rules[5]['label'] => $this->user_model->get_data('email'),
                    );
                $this->load->view('includes/header');
                $this->load->view('site/registration_success', array('account_details' => $account_details));
                $this->load->view('includes/footer');
                return;
            }
        }

        $this->load->view('includes/header');
        $this->load->view('site/registration');
        $this->load->view('includes/footer');
    }

    public function captcha()
    {
        $image_width = 128;
        $image_height = 48;
        $characters_on_image = 5;
        $font = FCPATH . 'assets/fonts/monofont.ttf';
        $possible_letters = '23456789bcdfghjkmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ';
        $random_dots = 30;
        $random_lines = 20;
        $captcha_text_color = "0x142864";
        $captcha_noice_color = "0x142864";
        $code = '';
        $i = 0;
        while ($i < $characters_on_image)
        {
            $code .= substr($possible_letters, mt_rand(0, strlen($possible_letters) - 1), 1);
            $i++;
        }

        $font_size = $image_height * .75;
        $image = @imagecreate($image_width, $image_height);
        imagealphablending($image, false);
        $transparency = imagecolorallocatealpha($image, 0, 0, 0, 127);
        imagefill($image, 0, 0, $transparency);
        imagesavealpha($image, true);
        $arr_text_color = $this->hex2rgb($captcha_text_color);
        $text_color = imagecolorallocate($image, $arr_text_color['red'], $arr_text_color['green'],
            $arr_text_color['blue']);
        $arr_noice_color = $this->hex2rgb($captcha_noice_color);
        $image_noise_color = imagecolorallocate($image, $arr_noice_color['red'], $arr_noice_color['green'],
            $arr_noice_color['blue']);
        for ($i = 0; $i < $random_dots; $i++)
        {
            imagefilledellipse($image, mt_rand(0, $image_width), mt_rand(0, $image_height),
                2, 3, $image_noise_color);
        }

        for ($i = 0; $i < $random_lines; $i++)
        {
            imageline($image, mt_rand(0, $image_width), mt_rand(0, $image_height), mt_rand(0,
                $image_width), mt_rand(0, $image_height), $image_noise_color);
        }

        $textbox = imagettfbbox($font_size, 0, $font, $code);
        $x = ($image_width - $textbox[4]) / 2;
        $y = ($image_height - $textbox[5]) / 2;
        imagettftext($image, $font_size, 0, $x, $y, $text_color, $font, $code);
        imagepng($image);
        imagedestroy($image);
        $this->session->set_userdata('iwb_sess', md5(strtolower($code)));
        $this->output->set_content_type('png')->set_output($this->output->get_output());
        return;
    }

    protected function hex2rgb($hexstr)
    {
        $int = hexdec($hexstr);
        return array(
            "red" => 0xff & ($int >> 0x10),
            "green" => 0xff & ($int >> 0x8),
            "blue" => 0xff & $int,
            );
    }

    public function pages($page = '')
    {
        $method = 'page_' . $page;
        if (method_exists($this, $method))
        {
            return $this->$method();
        }
        return $this->display_error(lang('iwb_error_404'));
    }

    protected function page_smileys()
    {
        $this->breadcrumbs->set('Smileys', '', true);
        $this->load->helper('smiley');
        $this->load->library('table');
        $data = array();
        $target = $this->input->get('target', true);
        if (!$target)
        {
            $target = 'smileys';
        }
        $image_array = get_clickable_smileys(base_url('images/smileys/'), $target);
        $col_array = $this->table->make_columns($image_array, $this->agent->is_mobile() ?
            8 : 16);
        $data['smiley_table'] = $this->table->generate($col_array);
        $data['smiley_js'] = smiley_js();
        $data['redirect'] = $this->get_redirect(site_url('site/index'));
        $this->load->view('includes/header');
        $this->load->view('site/pages/smileys', $data);
        $this->load->view('includes/footer');
    }
}
