<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends IWB_Controller
{
    protected $opt = array();

    public function __construct()
    {
        parent::__construct();
        if (!$this->iwb->is_user)
        {
            $this->session->set_userdata('login_redirect', current_url());
            redirect('site/login');
        }
        if ($this->iwb->user->rights != 10)
        {
            show_error(lang('iwb_error_403') . '.');
        }

    }

    public function index()
    {
        $data = array();
        $prefix = $this->db->dbprefix;
        $sql = array();
        $sql[] = "(SELECT COUNT(*) AS `total` FROM `{$prefix}blog_sites`)";
        $sql[] = "(SELECT COUNT(*) FROM `{$prefix}blog_sites` WHERE `mod_reg` =  'yes')";
        $sql[] = "(SELECT COUNT(*) FROM `{$prefix}blog_sites` WHERE `block` =  'yes')";

        $sql_query = implode(" UNION ALL ", $sql);
        $query = $this->db->query($sql_query);
        $data['total'] = $query->result_array();
        $this->breadcrumbs->set('Admin Panel');

        $this->load->view('includes/header');
        $this->load->view('admin/index', $data);
        $this->load->view('includes/footer');
    }

    public function blog($show = 'all')
    {
        $data = array();
        $data['current_page'] = get_current_page();
        if ($show == 'moderated')
        {
            $where = " WHERE `b`.`mod_reg` = 'yes'";
            $data['show'] = 'moderated';
        }
        elseif ($show == 'blocked')
        {
            $where = " WHERE `b`.`block` = 'yes'";
            $data['show'] = 'blocked';
        }
        else
        {
            $where = '';
            $data['show'] = 'all';
        }
        $data['total'] = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->db->
            dbprefix . "blog_sites` AS `b`" . $where)->row()->num;
        if ($data['total'])
        {
            $query = $this->db->query("SELECT `b`.*, `u`.`username` AS `user_username`, `u`.`name` AS `user_name` FROM `" .
                $this->db->dbprefix . "blog_sites` AS `b` LEFT JOIN `" . $this->db->dbprefix .
                "users` AS `u` ON `b`.`user_id` = `u`.`id`" . $where .
                "  ORDER BY `b`.`created` DESC LIMIT " . sql_offset($this->iwb->user_set['offset'],
                $data['current_page']) . ", " . $this->iwb->user_set['offset']);
            $data['blogs'] = $query->result();
        }
        $this->breadcrumbs->set('Admin Panel', 'admin');
        $this->breadcrumbs->set('Blog', '', true);
        $this->load->view('includes/header');
        $this->load->view('admin/blog', $data);
        $this->load->view('includes/footer');
    }

    public function indowapblog($action = '')
    {
        if (in_array($action, array(
            'update',
            'check_for_update',
            'update_settings',
            'update_history',
            'install_update',
            )))
        {
            $method = 'iwb_' . $action;
            return $this->$method();
        }
        $this->breadcrumbs->set('Admin Panel', 'admin');
        $this->breadcrumbs->set('IndoWapBlog', '', true);

        $this->load->view('includes/header');
        $this->load->view('admin/indowapblog/index');
        $this->load->view('includes/footer');
    }

    protected function iwb_check_for_update()
    {
        $this->breadcrumbs->set('Admin Panel', 'admin');
        $this->breadcrumbs->set('IndoWapBlog', 'admin/indowapblog');
        $this->breadcrumbs->set('Periksa Pembaruan', '', true);

        $iwb = $this->iwb_update_get_info();
        if (!$iwb)
        {
            return $this->display_error('Tidak dapat memeriksa pembaruan.');
        }

        $this->load->view('includes/header');
        $this->load->view('admin/indowapblog/check_for_update', array('iwb' => $iwb));
        $this->load->view('includes/footer');
    }

    protected function iwb_update_settings()
    {
        $this->breadcrumbs->set('Admin Panel', 'admin');
        $this->breadcrumbs->set('IndoWapBlog', 'admin/indowapblog');
        $this->breadcrumbs->set('Pengaturan Pembaruan', '', true);
        $update = json_decode($this->iwb->set['iwb_update'], true);
        if ($this->input->post())
        {
            $this->opt['form'] = 1;
            $this->load->library('form_validation');
            $this->form_validation->set_rules('iwb_update_url', 'URL Server Pembaruan',
                'required|valid_url|callback_server_check');
            $this->form_validation->set_rules('auto_update_iwb', 'Pembaruan Otomatis',
                'required|in_list[everytime,daily,weekly,monthly,never]');
            if ($this->form_validation->run() != false)
            {
                $this->db->where('set_key', 'iwb_update_url')->update('settings', array('set_value' =>
                        $this->input->post('iwb_update_url')));
                $update['set'] = $this->input->post('auto_update_iwb');
                $this->db->where('set_key', 'iwb_update')->update('settings', array('set_value' =>
                        json_encode($update)));
                $this->session->set_flashdata('alert-success', lang('iwb_change_saved'));
                redirect('admin/indowapblog');
            }

        }
        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('admin/indowapblog/update_settings', array('update' => $update));
        $this->load->view('includes/footer');
    }

    public function iwb_update_history()
    {
        $this->breadcrumbs->set('Admin Panel', 'admin');
        $this->breadcrumbs->set('IndoWapBlog', 'admin/indowapblog');
        $this->breadcrumbs->set('Riwayat Pembaruan', '', true);

        $data = array();
        $data['current_page'] = get_current_page();
        $data['total'] = $this->db->count_all('update');
        if ($data['total'])
        {
            $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                "update` ORDER BY `id` DESC LIMIT " . sql_offset($this->iwb->user_set['offset'],
                $data['current_page']) . ", " . $this->iwb->user_set['offset']);
            $data['histories'] = $query->result();
        }
        $this->load->view('includes/header');
        $this->load->view('admin/indowapblog/update_history', $data);
        $this->load->view('includes/footer');
    }

    public function iwb_install_update()
    {	
		$this->breadcrumbs->set('Admin Panel', 'admin');
        $this->breadcrumbs->set('IndoWapBlog', 'admin/indowapblog');
        $this->breadcrumbs->set('Install Pembaruan', '', true);
        
		$data = array();
        $data['error'] = '';
        if ($this->input->post())
        {
            $configs = array(
                'upload_path' => FCPATH . 'files/tmp/',
                'allowed_types' => 'zip',
                'file_ext_tolower' => true,
                //'max_size' => $file_set['upload_file_size'], // In Kilobytes
                'file_name' => 'IndoWapBlog-Update.zip',
                'overwrite' => true,
                );
            $this->load->library('upload', $configs);
            if (!$this->upload->do_upload())
            {
                $data['error'] = $this->upload->display_errors('<div class="alert alert-danger">',
                    '</div>');
            }
            else
            {
                $file = FCPATH . 'files/tmp/IndoWapBlog-Update.zip';
                $this->load->library('pclzip');
                $this->pclzip->PclZip($file);
                if ($this->pclzip->extract(PCLZIP_OPT_PATH, FCPATH) == 0)
                {
                    unlink($file);
                    return $this->display_error("Error: " . $archive->errorInfo(true));
                }
				unlink($file);
                $installer = false;
                foreach (glob(APPPATH . "libraries/Install_update_*.php") as $fail)
                {
                    $installer = strtolower(basename($fail, '.php'));
                }
                if ($installer)
                {
                    $this->load->library($installer);
                    $this->$installer->install();
                }
                $this->session->set_flashdata('alert-danger',
                    'Installasi berhasil diselesaikan namun versi IndoWapBlog tidak diperbarui.');
                redirect('admin/indowapblog');
            }
        }
        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('admin/indowapblog/install_update', $data);
        $this->load->view('includes/footer');
    }

    public function server_check($url = '')
    {
        if (!isset($this->opt['form']))
        {
            show_404(lang('iwb_error_404'));
        }
        $header = get_headers($url, 1);
        if (stripos($header[0], '200 OK') === false)
        {
            $this->form_validation->set_message('server_check',
                'URL Server Pembaruan tidak benar.');
            return false;
        }
        return true;
    }

    protected function iwb_update()
    {
        $iwb = $this->iwb_update_get_info();
        if (!$iwb)
        {
            return $this->display_error('Tidak dapat memeriksa pembaruan.');
        }
        if (!array_key_exists($this->iwb->set['iwb_version'], $iwb))
        {
            return $this->display_error('Tidak ada pembaruan IndoWapBlog.');
        }
        $step = abs(intval($this->input->get('step', true)));
        $step = $step == 0 ? 1 : $step;
        if (!array_key_exists($this->iwb->set['iwb_version'], $iwb))
        {
            return $this->display_error('Tidak ada pembaruan yang tersedia.');
        }
        $name = url_title($iwb[$this->iwb->set['iwb_version']]['version'], '_', true);
        $filename = 'update-' . $name . '.zip';

        $output = '<!DOCTYPE html><html><head><title>Installasi Pembaruan IWB</title>' .
            '<meta http-equiv="refresh" content="5;URL=' . site_url('admin/indowapblog/update?step=' .
            ($step + 1)) . '" /></head><body>' .
            '<h2 style="margin:15px 10px;text-align:center;">Step ' . $step .
            '</h2><p style="margin:15px 10px;text-align:center;"><img src="' . base_url('images/ajax-loader.gif') .
            '"/><br/>Mohon tunggu, kamu akan dialihkan secara otomatis atau <a href="' .
            site_url('admin/iwb_update/auto_update?step=' . ($step + 1)) .
            '">klik di sini</a> untuk melanjutkan.</p></body></html>';
        switch ($step)
        {
            case 1;
                if (!copy($iwb[$this->iwb->set['iwb_version']]['file'], FCPATH . 'files/tmp/' .
                    $filename))
                {
                    return $this->display_error('Tidak dapat mendownload file.');
                }
                echo $output;
                break;

            case 2:
                $zip = new ZipArchive;
                if ($zip->open(FCPATH . 'files/tmp/' . $filename) === true)
                {
                    $zip->extractTo(FCPATH);
                    $zip->close();
                    unlink(FCPATH . 'files/tmp/' . $filename);
                    echo $output;
                }
                else
                {
                    unlink(FCPATH . 'files/tmp/' . $filename);
                    return $this->display_error('Tidak dapat mengekstrak file.');
                }
                break;

            case 3:
                $this->db->insert('update', array(
                    'version' => $iwb[$this->iwb->set['iwb_version']]['version'],
                    'updated' => $iwb[$this->iwb->set['iwb_version']]['updated'],
                    'file' => $iwb[$this->iwb->set['iwb_version']]['file'],
                    'changelog' => json_encode($iwb[$this->iwb->set['iwb_version']]['changelog']),
                    'message' => $iwb[$this->iwb->set['iwb_version']]['message'],
                    'installed' => date_sql(time()),
                    ));
                $ver = "";
                $ver .= @file_get_contents(FCPATH . 'VERSION.md');
                $ver .= "\r\n\r\n------------------------------------------------------\r\n\r\n";
                $ver .= "# IndoWapBlog v" . $iwb[$this->iwb->set['iwb_version']]['version'];
                $ver .= "\r\n\r\n";
                $ver .= "Release: " . $iwb[$this->iwb->set['iwb_version']]['updated'] . " UTC";
                $ver .= "\r\n\r\n";
                $ver .= "Changelog:";
                $ver .= "\r\n\r\n";
                foreach ($iwb[$this->iwb->set['iwb_version']]['changelog'] as $ch)
                {
                    $ver .= "* " . $ch . "\r\n";
                }
                @file_put_contents(FCPATH . 'VERSION.md', trim($ver));

                $lname = 'Install_update_' . $name;
                $library = strtolower($lname);
                $this->load->library($library);
                $this->$library->install();
                break;

            default:
                break;
        }
    }

    public function delete_post($id = 0)
    {
        $query = $this->db->where('id', $id)->get('blog_posts');
        if ($query->num_rows() == 0)
        {
            return $this->display_error('Post not found.');
        }
        $post = $query->row();
        if ($this->input->post())
        {
            $this->db->where('id', $id)->delete('blog_posts');
            $this->db->where(array('site_id' => $post->site_id, 'post_id' => $id))->delete('blog_comments');
            $this->db->query("DELETE FROM `" . $this->db->dbprefix . "notifications` 
                WHERE (`type` = 'blog_comments_published' 
                OR `type` = 'blog_comments_moderated' 
                OR `type` = 'blog_comments_spam' 
                OR `type` = 'fl_new_post') 
                AND `code` = '{$id}'");
            if ($post->categories != '[]')
            {
                $this->db->query("UPDATE `" . $this->db->dbprefix .
                    "blog_categories` SET `total_posts` = `total_posts` - 1 WHERE `site_id` = '" . $post->
                    site_id . "' AND `link` IN ('" . implode("','", json_decode($post->categories)) .
                    "')");
            }
            $this->session->set_flashdata('alert-success', 'Post deleted.');
            redirect($this->get_redirect('admin'));
        }
        return $this->confirm(current_url() . '?redirect_uri=' . urlencode($this->
            get_redirect('admin')), 'Are you sure you want to delete this post?', $this->
            get_redirect('admin'));
    }

    public function block_blog($id = 0)
    {
        $query = $this->db->where('id', $id)->get('blog_sites');
        if ($query->num_rows() == 0)
        {
            return $this->display_error('Blog not found.');
        }
        $blog = $query->row();
        if ($blog->block == 'yes')
        {
            return $this->display_error('This blog has been blocked.');
        }
        if ($this->input->post())
        {
            $this->db->where('id', $id)->update('blog_sites', array('block' => 'yes'));
            $this->session->set_flashdata('alert-success', 'Blog successfully blocked.');
            redirect($this->get_redirect('admin'));
        }
        return $this->confirm(current_url() . '?redirect_uri=' . urlencode($this->
            get_redirect('admin')), 'Are you sure you want to block this blog?', $this->
            get_redirect('admin'));
    }

    public function unblock_blog($id = 0)
    {
        $query = $this->db->where('id', $id)->get('blog_sites');
        if ($query->num_rows() == 0)
        {
            return $this->display_error('Blog not found.');
        }
        $blog = $query->row();
        if ($blog->block == 'no')
        {
            return $this->display_error('This blog has not blocked.');
        }
        if ($this->input->post())
        {
            $this->db->where('id', $id)->update('blog_sites', array('block' => 'no'));
            $this->session->set_flashdata('alert-success', 'Blog successfully unblocked.');
            redirect($this->get_redirect('admin'));
        }
        return $this->confirm(current_url() . '?redirect_uri=' . urlencode($this->
            get_redirect('admin')), 'Are you sure you want to unblock this blog?', $this->
            get_redirect('admin'));
    }

    public function delete_blog($id = 0)
    {
        $query = $this->db->where('id', $id)->get('blog_sites');
        if ($query->num_rows() == 0)
        {
            return $this->display_error('Blog not found.');
        }
        $blog = $query->row();
        if ($this->input->post())
        {
            $this->db->where('id', $blog->id)->delete('blog_sites');
            $this->db->where('site_id', $blog->id)->delete('blog_posts');
            $this->db->where('site_id', $blog->id)->delete('blog_comments');
            $this->db->where('site_id', $blog->id)->delete('blog_categories');
            rmdir_recursive(FCPATH . 'files/blogs/' . $blog->id);
            $this->session->set_flashdata('alert-success', 'Blog successfully deleted.');
            redirect($this->get_redirect('admin'));
        }
        return $this->confirm(current_url() . '?redirect_uri=' . urlencode($this->
            get_redirect('admin')), 'Are you sure you want to delete this blog?', $this->
            get_redirect('admin'));
    }

    public function settings($setting = '')
    {
        if (in_array($setting, array(
            'blog',
            'general',
            )))
        {
            $set_method = $setting . '_settings';
            return $this->$set_method();
        }
        else
        {
            redirect('admin/settings/general');
        }
    }

    private function blog_settings()
    {
        $data = array();
        $data['set'] = array_merge($this->iwb->set, $this->iwb->get_setting(array(
            'domains',
            'subdomain_disallow',
            'diff_time_blog',
            'mod_new_blog',
            'max_user_blogs',
            'blog_categories',
            'upload_file_types',
            'upload_file_size',
            )));
        if ($this->input->post())
        {
            $this->load->library('form_validation');
            $input = array(
                'domains' => strtolower($this->input->post('domains')),
                'subdomain_disallow' => json_encode(str_tags(strtolower($this->input->post('subdomain_disallow')))),
                'diff_time_blog' => abs(intval($this->input->post('diff_time_blog'))),
                'mod_new_blog' => $this->input->post('mod_new_blog'),
                'max_user_blogs' => abs(intval($this->input->post('max_user_blogs'))),
                'upload_file_types' => json_encode(str_tags(strtolower($this->input->post('upload_file_types')))),
                'blog_categories' => preg_split("/[,]+/", $this->input->post('blog_categories')),
                'upload_file_size' => abs(intval($this->input->post('upload_file_size'))),
                );
            $this->form_validation->set_data($input);
            $this->form_validation->set_rules('domains', 'Domains', array('required', array
                    ('blog_domains', function ()use($data, &$input)
                    {
                        $input['domains'] = preg_split("/[,]+/", $input['domains']); $domains =
                            json_decode($data['set']['domains']); foreach ($domains as $domain)
                        {
                            if (!in_array($domain, $input['domains']))
                            {
                                $this->form_validation->set_message('blog_domains', 'Domain ' . $domain .
                                    ' can not be removed.'); return false; }
                            return true; }
                    }
                    )));
            $this->form_validation->set_rules('mod_new_blog', 'Moderation new blog',
                'in_list[yes,no]');
            if ($this->form_validation->run() != false)
            {
                $input['domains'] = json_encode($input['domains']);
                $rcat = array();
                foreach (json_decode($data['set']['blog_categories']) as $cat)
                {
                    if (!in_array($cat, $input['blog_categories']))
                    {
                        $rcat[] = $cat;
                    }
                }
                if ($rcat)
                {
                    $this->db->where_in('category', $rcat)->update('blog_sites', array('category' =>
                            ''));
                }
                sort($input['blog_categories']);
                $input['blog_categories'] = json_encode($input['blog_categories']);
                foreach ($input as $key => $val)
                {
                    $this->db->where('set_key', $key)->update('settings', array('set_value' => $val));
                }
                $this->session->set_flashdata('alert-success', 'Change saved.');
                redirect('admin');
            }
        }
        $this->breadcrumbs->set('Admin Panel', 'admin');
        $this->breadcrumbs->set('Settings', 'admin/settings', true);
        $this->breadcrumbs->set('Blog');

        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('admin/settings/blog', $data);
        $this->load->view('includes/footer');
    }

    private function general_settings()
    {
        $data = array();
        $data['set'] = array_merge($this->iwb->set, $this->iwb->get_setting(array('site_email', )));
        if ($this->input->post())
        {
            $this->load->library('form_validation');
            $input = array(
                'site_name' => trim($this->input->post('site_name')),
                'site_email' => trim($this->input->post('site_email')),
                'time_zone' => $this->input->post('time_zone'),
                'offset' => $this->input->post('offset'),
                );
            $this->form_validation->set_data($input);
            $this->form_validation->set_rules('site_name', 'Site Name',
                'required|max_length[30]');
            $this->form_validation->set_rules('site_email', 'Site Email',
                'required|valid_email');
            $this->form_validation->set_rules('time_zone', 'Time Zone', 'required|in_list[' .
                implode(',', array_keys(timezones())) . ']');
            $this->form_validation->set_rules('offset', 'List Per Page',
                'required|in_list[5,10,15,20]');
            if ($this->form_validation->run() != false)
            {
                foreach ($input as $t_k => $t_v)
                {
                    $this->db->where('set_key', $t_k)->update('settings', array('set_value' => $t_v));
                }
                $this->session->set_flashdata('alert-success', lang('iwb_change_saved'));
                redirect('admin');
            }
        }
        $this->breadcrumbs->set('Admin Panel', 'admin');
        $this->breadcrumbs->set('Settings', 'admin/settings', true);
        $this->breadcrumbs->set('General');

        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('admin/settings/general', $data);
        $this->load->view('includes/footer');
    }

    public function credit($action = '')
    {
        $this->breadcrumbs->set('Admin Panel', 'admin');
        if (in_array($action, array('top_up_info')))
        {
            $method = 'credit_' . $action;
            return $this->$method();
        }
        $this->breadcrumbs->set(lang('iwb_credit'), '', true);
        $this->load->view('includes/header');
        $this->load->view('admin/credit/index');
        $this->load->view('includes/footer');
    }

    private function credit_top_up_info()
    {
        $this->breadcrumbs->set(lang('iwb_credit'), 'admin/credit');
        $this->breadcrumbs->set('Informasi isi ulang', '', true);

        if ($this->input->post())
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('credit_top_up_info', 'Informasi isi ulang',
                'required');
            if ($this->form_validation->run() != false)
            {
                $this->db->where('set_key', 'credit_top_up_info')->update('settings', array('set_value' =>
                        trim($this->input->post('credit_top_up_info'))));
                $this->session->set_flashdata('alert-success', lang('iwb_change_saved'));
                redirect('admin/credit');
            }
        }

        $data = array();
        $data['credit_top_up_info'] = $this->iwb->get_setting('credit_top_up_info');
        $head_meta = '<link rel="stylesheet" href="' . base_url('/assets/editor/tinyeditor.css') .
            '" /><script type="text/javascript" src="' . base_url('/assets/editor/tinyeditor.js') .
            '"></script>';
        $this->load->helper('form');
        $this->load->view('includes/header', array('head_meta' => (!$this->agent->
                is_mobile() ? $head_meta : '')));
        $this->load->view('admin/credit/top_up_info', $data);
        $this->load->view('includes/footer');
    }
}
