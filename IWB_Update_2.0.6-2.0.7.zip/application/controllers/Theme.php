<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Theme extends IWB_Controller
{
    private $blog = false;
    private $theme;

    public function __construct()
    {
        parent::__construct();
        $theme = $this->input->post_get('theme');
        $theme = $theme == null ? 'mobile' : $theme;
        if (!in_array($theme, array(
            'mobile',
            'desktop',
            )))
        {
            show_error(lang('iwb_error_400'));
            return;
        }
        $this->theme = $theme;
        if (!$this->iwb->is_user)
        {
            $this->session->set_userdata('login_redirect', current_url());
            redirect('site/login');
        }
        $this->load->model('blog_model');
        if (!$blog = $this->blog_model->authorization())
        {
            $this->session->set_flashdata('alert-info', lang('iwb_blog_not_logged_in'));
            redirect('account/blog?redirect_uri=' . urlencode(current_url() . '?' . $this->
                input->server('QUERY_STRING', true)));
        }
        $this->blog = $blog;
        $this->blog->{'url'} = blog_url($blog);
        $this->breadcrumbs->set(lang('iwb_dashboard'), 'dashboard');
    }

    public function index()
    {
        $this->breadcrumbs->set('Tema', '', true);
        $data = array();
        $data['blog'] = $this->blog;
        $data['theme'] = $this->theme;
        $this->load->view('includes/header');
        $this->load->view('theme/index', $data);
        $this->load->view('includes/footer');
    }

    public function reset()
    {
        if ($this->input->post())
        {
            $zip = new ZipArchive();
            if ($zip->open(APPPATH . 'third_party/templates/' . $this->theme . '.zip') === true)
            {
                $zip->extractTo(FCPATH . 'files/blogs/' . $this->blog->id . '/templates/' . $this->
                    theme . '/');
                $zip->close();
                $this->session->set_flashdata('alert-success', 'Tema berhasil direset.');
            }
            else
            {
                $this->session->set_flashdata('alert-danger', 'Tema gagal direset.');
            }
            redirect('theme?theme=' . $this->theme);
        }
        return $this->confirm(current_url(),
            'Apakah kamu ingin mereset tema ke pengaturan standar?');
    }

    public function template_editor()
    {
        $item = $this->input->get('item');
        if (in_array($item, array(
            'error.html',
            'follow.html',
            'footer.html',
            'header.html',
            'home.html',
            'page.html',
            'post.html',
            )))
        {
            return $this->template_editor_form($item);
        }

        $this->breadcrumbs->set('Tema', 'theme');
        $this->breadcrumbs->set($this->theme, 'theme?theme=' . $this->theme);
        $this->breadcrumbs->set('Template Editor', '', true);

        $data = array();
        $data['blog'] = $this->blog;
        $data['theme'] = $this->theme;

        $this->load->view('includes/header');
        $this->load->view('theme/template_editor/index', $data);
        $this->load->view('includes/footer');
    }

    protected function template_editor_form($item)
    {
        $this->breadcrumbs->set('Tema', 'theme');
        $this->breadcrumbs->set($this->theme, 'theme?theme=' . $this->theme);
        $this->breadcrumbs->set('Template Editor', 'theme/template_editor?theme=' . $this->
            theme);
        $this->breadcrumbs->set($item, '', true);

        $data = array();
        $data['blog'] = $this->blog;
        $data['theme'] = $this->theme;
        $data['item'] = $item;
        if ($this->input->post('code'))
        {
            $code = $this->input->post('code');
            if (file_put_contents(FCPATH . 'files/blogs/' . $this->blog->id . '/templates/' .
                $this->theme . '/' . $item, $code))
            {
                $this->session->set_flashdata('alert-success', 'Perubahan berhasil disimpan.');
            }
            else
            {
                $this->session->set_flashdata('alert-danger', 'Tidak dapat menyimpan perubahan.');
            }
            redirect('theme/template_editor?theme=' . $this->theme . '&item=' . $item);
        }
        $data['template'] = file_get_contents(FCPATH . 'files/blogs/' . $this->blog->id .
            '/templates/' . $this->theme . '/' . $item);
        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('theme/template_editor/form', $data);
        $this->load->view('includes/footer');
    }

    public function css_editor()
    {
        $this->breadcrumbs->set('Tema', 'theme');
        $this->breadcrumbs->set($this->theme, 'theme?theme=' . $this->theme);
        $this->breadcrumbs->set('CSS Editor', '', true);

        $data = array();
        $data['blog'] = $this->blog;
        $data['theme'] = $this->theme;
        if ($this->input->post('css'))
        {
            $css = $this->input->post('css');
            if (file_put_contents(FCPATH . 'files/blogs/' . $this->blog->id . '/templates/' .
                $this->theme . '/style.css', $css))
            {
                $this->session->set_flashdata('alert-success', 'Perubahan berhasil disimpan.');
            }
            else
            {
                $this->session->set_flashdata('alert-danger', 'Tidak dapat menyimpan perubahan.');
            }
            redirect('theme/css_editor?theme=' . $this->theme);
        }
        $data['css'] = file_exists(FCPATH . 'files/blogs/' . $this->blog->id .
            '/templates/' . $this->theme . '/style.css') ? file_get_contents(FCPATH .
            'files/blogs/' . $this->blog->id . '/templates/' . $this->theme . '/style.css') :
            '';
        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('theme/css_editor', $data);
        $this->load->view('includes/footer');
    }
}
