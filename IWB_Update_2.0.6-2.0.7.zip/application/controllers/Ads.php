<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Ads extends IWB_Controller
{
    private $blog = false;
    private $opt = array();

    public function __construct()
    {
        parent::__construct();
        if (!$this->iwb->is_user)
        {
            $this->session->set_userdata('login_redirect', current_url());
            redirect('site/login');
        }
        $this->load->model('blog_model');
        if (!$blog = $this->blog_model->authorization())
        {
            $this->session->set_flashdata('alert-info', lang('iwb_blog_not_logged_in'));
            redirect('account/blog?redirect_uri=' . urlencode(current_url() . '?' . $this->
                input->server('QUERY_STRING', true)));
        }
        $this->blog = $blog;
        $this->blog->{'url'} = blog_url($blog);
        $this->breadcrumbs->set(lang('iwb_dashboard'), 'dashboard');
    }

    public function index()
    {
        $this->breadcrumbs->set('Periklanan', '', true);
        $data = array();
        $query = $this->db->where(array('site_id' => $this->blog->id))->order_by('ads_id',
            'DESC')->get('blog_ads');
        $data['ads'] = $query->result();
        $this->load->view('includes/header');
        $this->load->view('ads/index', $data);
        $this->load->view('includes/footer');
    }

    public function create()
    {
        $this->breadcrumbs->set('Periklanan', 'ads', true);
        $this->breadcrumbs->set('Membuat');
        $data = array();

        if ($this->input->post())
        {
            $this->opt['form'] = 1;
            $this->load->library('form_validation');
            $this->form_validation->set_rules('ads_name', 'Nama',
                'required|min_length[2]|max_length[60]');
            $this->form_validation->set_rules('ads_code', 'Kode HTML',
                'required|max_length[1024]');
            $this->form_validation->set_rules('ads_theme', 'Tema',
                'required|in_list[mobile,desktop]|callback_ads_placement_check');
            $this->form_validation->set_rules('ads_placement', 'Penempatan',
                'required|in_list[top,bottom]');
            if ($this->form_validation->run() != false)
            {
                $this->db->insert('blog_ads', array(
                    'site_id' => $this->blog->id,
                    'user_id' => $this->blog->user_id,
                    'ads_name' => $this->input->post('ads_name'),
                    'ads_code' => $this->input->post('ads_code'),
                    'ads_theme' => $this->input->post('ads_theme'),
                    'ads_placement' => $this->input->post('ads_placement'),
                    ));
                $this->session->set_flashdata('alert-success', 'Iklan berhasil dibuat.');
                redirect('ads');
            }
        }
        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('ads/create', $data);
        $this->load->view('includes/footer');
    }

    public function ads_placement_check($theme = 'mobile')
    {
        if (!isset($this->opt['form']))
        {
            show_error(lang('iwb_error_404'));
        }
        $this->db->where(array('site_id' => $this->blog->id, 'ads_theme' => $theme));
        if ($this->db->count_all_results('blog_ads') >= 4)
        {
            $this->form_validation->set_message('ads_placement_check',
                'Kode periklanan pada tema ' . ucfirst($theme) .
                ' sudah mencapai batas maksimal yaitu 4.');
            return false;
        }
        return true;
    }

    public function edit($id = 0)
    {
        $this->breadcrumbs->set('Periklanan', 'ads', true);
        $this->breadcrumbs->set(lang('iwb_edit'));
        $data = array();
        $query = $this->db->get_where('blog_ads', array(
            'ads_id' => $id,
            'site_id' => $this->blog->id,
            ));
        if ($query->num_rows() == 0)
        {
            show_error('Iklan tidak ditemukan.');
        }
        $data['ads'] = $query->row();

        if ($this->input->post())
        {
            $this->opt['form'] = 1;
            $this->load->library('form_validation');
            $this->form_validation->set_rules('ads_name', 'Nama',
                'required|min_length[2]|max_length[60]');
            $this->form_validation->set_rules('ads_code', 'Kode HTML',
                'required|max_length[1024]');
            $this->form_validation->set_rules('ads_theme', 'Tema',
                'required|in_list[mobile,desktop]|callback_ads_placement_check');
            $this->form_validation->set_rules('ads_placement', 'Penempatan',
                'required|in_list[top,bottom]');
            if ($this->form_validation->run() != false)
            {
                $this->db->where('ads_id', $id)->update('blog_ads', array(
                    'ads_name' => $this->input->post('ads_name'),
                    'ads_code' => $this->input->post('ads_code'),
                    'ads_theme' => $this->input->post('ads_theme'),
                    'ads_placement' => $this->input->post('ads_placement'),
                    ));
                $this->session->set_flashdata('alert-success', lang('iwb_change_saved'));
                redirect('ads');
            }
        }
        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('ads/edit', $data);
        $this->load->view('includes/footer');
    }

    public function delete($id = 0)
    {
        $this->breadcrumbs->set('Periklanan', 'ads', true);
        $this->breadcrumbs->set(lang('iwb_delete'));
        $query = $this->db->get_where('blog_ads', array(
            'ads_id' => $id,
            'site_id' => $this->blog->id,
            ));
        if ($query->num_rows() == 0)
        {
            show_error('Iklan tidak ditemukan.');
        }

        if ($this->input->post())
        {
            $this->db->where('ads_id', $id)->delete('blog_ads');
            $this->session->set_flashdata('alert-success', 'Iklan dihapus.');
            redirect('ads');
        }
        $this->confirm(current_url(), 'Apakah kamu ingin menghapus iklan ini?');
    }
}
