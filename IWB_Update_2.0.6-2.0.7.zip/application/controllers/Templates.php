<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Templates extends IWB_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->iwb->is_user)
        {
            $this->session->set_userdata('login_redirect', current_url());
            redirect('site/login');
            return;
        }
        //$this->lang->load('templates');
    }

    public function index()
    {
        return $this->lists();
    }

    public function mobile($template = null)
    {
        if ($template != null)
        {
            return $this->detail('mobile', $template);
        }
        return $this->lists('mobile');
    }

    public function desktop($template = null)
    {
        if ($template != null)
        {
            return $this->detail('desktop', $template);
        }
        return $this->lists('desktop');
    }

    public function moderated()
    {
        if ($this->iwb->user->rights < 10)
        {
            redirect('templates');
        }
        return $this->lists('moderated');
    }

    protected function lists($theme = '')
    {
        $this->breadcrumbs->set('Templates', '', true);
        $search = $this->input->get('search', true);
        $search = $search == null ? '' : $search;
        $page = abs(intval($this->input->get('page')));
        $page = $page < 1 ? 1 : $page;
        $data = array();
        $data['current_page'] = $page;
        $data['offset'] = $this->agent->is_mobile() ? $this->iwb->user_set['offset'] :
            12;
        $data['theme'] = $theme;
        $data['search_query'] = $search;
        if ($theme == 'mobile')
        {
            if (!empty($search))
            {
                $filter = " WHERE `t`.`theme` = 'mobile' AND `t`.`name` LIKE '%" . $this->db->
                    escape_like_str($search) . "%' AND `t`.`moderation` = 'no'";
            }
            else
            {
                $filter = " WHERE `t`.`theme` = 'mobile' AND `t`.`moderation` = 'no'";
            }
        }
        elseif ($theme == 'desktop')
        {
            if (!empty($search))
            {
                $filter = " WHERE `t`.`theme` = 'desktop' AND `t`.`name` LIKE '%" . $this->db->
                    escape_like_str($search) . "%' AND `t`.`moderation` = 'no'";
            }
            else
            {
                $filter = " WHERE `t`.`theme` = 'desktop' AND `t`.`moderation` = 'no'";
            }
        }
        elseif ($theme == 'moderated')
        {
            $filter = " WHERE `t`.`moderation` = 'yes'";
        }
        else
        {
            if (!empty($search))
            {
                $filter = " WHERE `t`.`name` LIKE '%" . $this->db->escape_like_str($search) .
                    "%' AND `t`.`moderation` = 'no'";
            }
            else
            {
                $filter = "WHERE `t`.`moderation` = 'no'";
            }
        }
        if ($this->iwb->user->rights == 10)
        {
            $data['total_moderated'] = $this->db->query("SELECT COUNT(*) AS `num` FROM `" .
                $this->db->dbprefix . "templates` WHERE `moderation` = 'yes'")->row()->num;
        }
        else
        {
            $data['total_moderated'] = 0;
        }
        $data['total'] = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->db->
            dbprefix . "templates` AS `t`" . $filter)->row()->num;
        if ($data['total'] > 0)
        {
            $query = $this->db->query("SELECT `t`.*, `u`.`username` AS `user_username`, `u`.`name`  AS `user_name` FROM `" .
                $this->db->dbprefix . "templates` AS `t` LEFT JOIN `" . $this->db->dbprefix .
                "users` AS `u` ON `t`.`user_id` = `u`.`id`" . $filter .
                " ORDER BY `t`.`upload_time` DESC LIMIT " . sql_offset($data['offset'], $page) .
                ", " . $data['offset'] . ";");
            $data['templates'] = $query->result();
        }
        $this->load->view('includes/header');
        $this->load->view('templates/index', $data);
        $this->load->view('includes/footer');
    }

    protected function detail($theme, $template)
    {

        $this->breadcrumbs->set('Templates', 'templates');
        $this->db->select('t.*,u.username as user_username,u.name as user_name');
        $this->db->from('templates as t');
        $this->db->where(array(
            't.theme' => $theme,
            't.link' => $template,
            ));
        $this->db->join('users as u', 'u.id = t.user_id');
        $query = $this->db->get();
        if ($query->num_rows() != 1)
        {
            $this->breadcrumbs->set('Template Not Found', '', true);
            return $this->display_error('Template not found.');
        }
        $template = $query->row();
        if ($template->moderation == 'yes')
        {
            if ($this->iwb->user->rights < 10 && $this->iwb->user_id != $template->user_id)
            {
                $this->breadcrumbs->set('Template Not Found', '', true);
                return $this->display_error('Template not found.');
            }
        }
        $this->breadcrumbs->set(esc_html($template->name), '', true);

        $this->load->view('includes/header');
        $this->load->view('templates/detail', array('template' => $template));
        $this->load->view('includes/footer');
    }

    public function set($theme = '', $template = '')
    {
        $this->breadcrumbs->set('Templates', 'templates');
        $this->breadcrumbs->set('Use Template', '', true);
        if (empty($theme) || empty($template))
        {
            return $this->display_error(lang('iwb_error_400'));
        }
        $this->db->from('templates');
        $this->db->where(array(
            'theme' => $theme,
            'link' => $template,
            'moderation' => 'no',
            ));
        $query = $this->db->get();
        if ($query->num_rows() != 1)
        {
            return $this->display_error('Template not found.');
        }
        $template = $query->row();
        $query = $this->db->get_where('blog_sites', array(
            'user_id' => $this->iwb->user_id,
            'mod_reg' => 'no',
            'block' => 'no',
            ));
        $blogs = $query->result();
        $blog = $settings = array();
        if (count($blogs))
        {
            foreach ($blogs as $b)
            {
                $blog[$b->id] = $b->name;
                $settings[$b->id] = $b->settings;
            }
        }
        if ($this->input->post())
        {
            $for_blog = abs(intval($this->input->post('blog')));
            if (!array_key_exists($for_blog, $blog))
            {
                return $this->displsy_error('Invalid selected blog.');
            }
            @unlink(FCPATH . 'files/blogs/' . $for_blog . '/templates/' . $template->theme .
                '/screenshoot.png');
            @unlink(FCPATH . 'files/blogs/' . $for_blog . '/templates/' . $template->theme .
                '/style.css');
            $files = glob(FCPATH . 'files/templates/' . $template->theme . '/' . $template->
                link . '/*.{html,css}', GLOB_BRACE);
            foreach ($files as $file)
            {
                @copy($file, FCPATH . 'files/blogs/' . $for_blog . '/templates/' . $template->
                    theme . '/' . basename($file));
            }
            $set = get_blog_settings($settings[$for_blog]);
            $key = $theme . '_template';
            $set[$key] = $template->link;
            $this->db->where('id', $for_blog)->update('blog_sites', array('settings' =>
                    json_encode($set)));
            $this->session->set_flashdata('alert-success', 'Template changed successfully.');
            redirect('dashboard');
        }
        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('templates/set', array(
            'template' => $template,
            'blog' => $blog,
            ));
        $this->load->view('includes/footer');
    }

    public function confirm_template($theme = '', $template = '')
    {
        if (empty($theme) || empty($template) || $this->iwb->user->rights < 10)
        {
            return $this->display_error(lang('iwb_error_400'));
        }
        $this->db->from('templates');
        $this->db->where(array(
            'theme' => $theme,
            'link' => $template,
            'moderation' => 'yes',
            ));
        $query = $this->db->get();
        if ($query->num_rows() != 1)
        {
            return $this->display_error('Template not found.');
        }
        $template = $query->row();
        if ($this->input->post())
        {
            $this->db->where('id', $template->id)->update('templates', array('moderation' =>
                    'no'));
            $this->notifications_model->insert(array(
                'users_id' => '["' . $template->user_id . '"]',
                'users_read' => '["0"]',
                'type' => 'template_confirm',
                'code' => 'tpl_' . $template->id,
                'val1' => $template->name,
                'val2' => '',
                'val3' => '',
                'auto_delete' => 1,
                'link' => site_url('templates/' . $template->theme . '/' . $template->link),
                'time' => time(),
                ));
            $this->session->set_flashdata('alert-success', 'Template published.');
            redirect('templates/' . $template->theme . '/' . $template->link);

        }
        return $this->confirm(current_url(),
            'Are sure you want to confirm and publish this template?');
    }

    public function reject($theme = '', $template = '')
    {
        if (empty($theme) || empty($template) || $this->iwb->user->rights < 10)
        {
            return $this->display_error(lang('iwb_error_400'));
        }
        $this->db->from('templates');
        $this->db->where(array(
            'theme' => $theme,
            'link' => $template,
            'moderation' => 'yes',
            ));
        $query = $this->db->get();
        if ($query->num_rows() != 1)
        {
            return $this->display_error('Template not found.');
        }
        $template = $query->row();
        if ($this->input->post())
        {
            $this->db->where('id', $template->id)->delete('templates');
            rmdir_recursive(FCPATH . 'files/templates/' . $template->theme . '/' . $template->
                link);
            $this->notifications_model->insert(array(
                'users_id' => '["' . $template->user_id . '"]',
                'users_read' => '["0"]',
                'type' => 'template_reject',
                'code' => 'tpl_' . $template->id,
                'val1' => $template->name,
                'val2' => '',
                'val3' => '',
                'auto_delete' => 1,
                'link' => site_url('templates'),
                'time' => time(),
                ));
            $this->session->set_flashdata('alert-success', 'Template rejected.');
            redirect('templates/moderated');

        }
        return $this->confirm(current_url(),
            'Are sure you want to reject this template?');
    }

    public function delete($theme = '', $template = '')
    {
        if (empty($theme) || empty($template))
        {
            return $this->display_error(lang('iwb_error_400'));
        }
        $this->db->from('templates');
        $this->db->where(array(
            'theme' => $theme,
            'link' => $template,
            'moderation' => 'no',
            ));
        $query = $this->db->get();
        if ($query->num_rows() != 1)
        {
            return $this->display_error('Template not found.');
        }
        $template = $query->row();
        if ($this->iwb->user->rights < 10 && $this->iwb->user_id != $template->user_id)
        {
            return $this->display_error(lang('iwb_error_400'));
        }
        if ($this->input->post())
        {
            $this->db->where('id', $template->id)->delete('templates');
            rmdir_recursive(FCPATH . 'files/templates/' . $template->theme . '/' . $template->
                link);
            if ($this->iwb->user_id != $template->user_id)
            {
                $this->notifications_model->insert(array(
                    'users_id' => '["' . $template->user_id . '"]',
                    'users_read' => '["0"]',
                    'type' => 'template_delete',
                    'code' => 'tpl_' . $template->id,
                    'val1' => $template->name,
                    'val2' => '',
                    'val3' => '',
                    'auto_delete' => 1,
                    'link' => site_url('templates'),
                    'time' => time(),
                    ));
            }
            $this->session->set_flashdata('alert-success', 'Template deleted.');
            redirect('templates');

        }
        return $this->confirm(current_url(),
            'Are sure you want to delete this template?');
    }

    public function preview($theme = '', $template = '')
    {
        $blog_preview = $this->iwb->get_setting('blog_preview_tpl');

        if (empty($theme) || empty($template))
        {
            return $this->display_error(lang('iwb_error_400'));
        }
        $this->db->from('templates');
        $this->db->where(array(
            'theme' => $theme,
            'link' => $template,
            ));
        $query = $this->db->get();
        if ($query->num_rows() != 1)
        {
            return $this->display_error('Template not found.');
        }
        $template = $query->row();
        if ($template->moderation == 'yes' && $this->iwb->user->rights < 10)
        {
            return $this->display_error('Template not found.');
        }
        $query = $this->db->get_where('blog_sites', array('id' => $blog_preview));
        if ($query->num_rows() == 0)
        {
            return $this->display_error('Blog for preview template not found.');
        }
        $blog = $query->row();
        $files = glob(FCPATH . 'files/templates/' . $template->theme . '/' . $template->
            link . '/*');
        foreach ($files as $file)
        {
            @copy($file, FCPATH . 'files/blogs/' . $blog->id . '/templates/' . $template->
                theme . '/' . basename($file));
        }
        $set = get_blog_settings($blog->settings);
        $key = $theme . '_template';
        $set[$key] = $template->link;
        $this->db->where('id', $blog->id)->update('blog_sites', array('settings' =>
                json_encode($set)));
        redirect(blog_url($blog));
    }

    public function upload()
    {
        $this->breadcrumbs->set('Templates', 'templates');
        $this->breadcrumbs->set('Upload', '', true);

        $data = array();

        if ($this->input->post())
        {
            $this->load->library('form_validation');
            $link = str_link($this->input->post('t_name', true));
            $theme = $this->input->post('t_theme');
            $this->form_validation->set_rules('t_name', 'Template Name',
                'required|min_length[3]|max_length[30]|callback_unique_tpl');
            $this->form_validation->set_rules('t_theme', 'Theme',
                'required|in_list[mobile,desktop]');
            $this->form_validation->set_rules('t_desc', 'Description',
                'required|min_length[10]|max_length[1024]');
            if ($this->form_validation->run() != false)
            {
                $this->load->library('upload');

                $config['upload_path'] = FCPATH . 'files/tmp';
                $config['file_name'] = $link . '-' . time();
                $config['overwrite'] = true;
                $config['file_ext_tolower'] = true;
                $config['allowed_types'] = 'zip';
                $config['max_size'] = 500;
                $this->upload->initialize($config);
                if (!$this->upload->do_upload('t_file'))
                {
                    $data['error'] = $this->upload->display_errors('<div class="alert alert-danger">',
                        '</div>');
                }
                else
                {
                    $zip_file = $this->upload->data('full_path');
                    if (!mkdir(FCPATH . 'files/templates/' . $theme . '/' . $link, 0777, true))
                    {
                        unlink($zip_file);
                        return $this->display_error('Can not create folder.');
                    }
                    $files = array(
                        'error.html',
                        'follow.html',
                        'footer.html',
                        'header.html',
                        'home.html',
                        'page.html',
                        'post.html',
                        'screenshoot.png',
                        'style.css',
                        );
                    $zip = new ZipArchive();
                    $zip_error = array();
                    if ($zip->open($zip_file))
                    {


                        foreach ($files as $file)
                        {
                            if (($content = $zip->getFromName($file)) == false)
                            {
                                $zip_error[] = 'File ' . $file . ' not found.';
                            }
                            else
                            {
                                if (!file_put_contents(FCPATH . 'files/templates/' . $theme . '/' . $link . '/' .
                                    $file, $content))
                                {
                                    $zip_error[] = 'Failed to copy file ' . $file . '.';
                                }
                            }
                        }
                        $zip->close();
                    }
                    else
                    {
                        $zip_error[] = 'Failed to read archive.';
                    }
                    unlink($zip_file);
                    if ($zip_error)
                    {
                        rmdir_recursive(FCPATH . 'files/templates/' . $theme . '/' . $link);
                        $data['error'] = '<div class="alert alert-danger">' . implode('<br/>', $zip_error) .
                            '</div>';
                    }
                    else
                    {
                        $zip = new ZipArchive;
                        if ($zip->open(APPPATH . 'third_party/templates/' . $theme . '.zip') === true)
                        {
                            $zip->extractTo(FCPATH . 'files/templates/' . $theme . '/' . $link, array('layout.html'));
                            $zip->close();
                        }
                        else
                        {
                            show_error('Tidak dapat mengekstrak arsip zip.');
                        }
                        $this->db->insert('templates', array(
                            'user_id' => $this->iwb->user_id,
                            'name' => $this->input->post('t_name', true),
                            'description' => $this->input->post('t_desc', true),
                            'link' => $link,
                            'theme' => $theme,
                            'moderation' => $this->iwb->user->rights == 10 ? 'no' : 'yes',
                            'upload_time' => date_sql(time()),
                            ));
                        $tid = $this->db->insert_id();
                        if ($this->iwb->user->rights != 10)
                        {
                            $query = $this->db->select('id')->where('rights', 10)->limit(1)->get('users');
                            $admin = $query->row();
                            $this->notifications_model->insert(array(
                                'users_id' => '["' . $admin->id . '"]',
                                'users_read' => '["0"]',
                                'type' => 'template_upload',
                                'code' => 'tpl_new',
                                'val1' => $this->iwb->user->name,
                                'val2' => '',
                                'val3' => '',
                                'auto_delete' => 1,
                                'link' => site_url('templates/moderated'),
                                'time' => time(),
                                ));

                        }
                        $this->session->set_flashdata('alert-success', 'Template successfully uploaded.');
                        redirect('templates/' . $theme . '/' . $link);
                    }
                }
            }
        }
        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('templates/upload', $data);
        $this->load->view('includes/footer');
    }

    public function unique_tpl($name)
    {
        $query = $this->db->get_where('templates', array(
            'theme' => $this->input->post('t_theme'),
            'link' => str_link($name),
            ));
        if ($query->num_rows() != 0)
        {
            $this->form_validation->set_message('unique_tpl', 'Template already exists.');
            return false;
        }
        return true;
    }
}
