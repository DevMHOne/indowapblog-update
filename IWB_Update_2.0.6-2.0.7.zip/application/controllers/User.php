<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class User extends IWB_Controller
{
    protected $user = false;
    protected $data = array();

    public function __construct()
    {
        parent::__construct();
        if (!$this->iwb->is_user)
        {
            $user = get_user_by_username($this->uri->segment(2), 'name');
            if ($user)
            {
                $this->session->set_flashdata('alert-danger', 'Untuk melihat profile <strong>' .
                    esc_html($user->name) . '</strong> silakan masuk terlebih dahulu.');
            }
            $this->session->set_userdata('login_redirect', current_url());
            redirect('site/login');
        }
        $this->lang->load('user');
    }

    public function _remap($method, $params = array())
    {
        $query = $this->db->select('*')->where('username', $method)->get('users');
        if ($query->num_rows() == 1)
        {
            $this->data['user'] = $this->user = $query->row();
            $this->config->set_item('page_title', esc_html($this->user->name));
        }
        else
        {
            return $this->display_error(lang('user_user_not_found'));
        }

        if (isset($params[0]))
        {
            $pages = array(
                'about',
                'blog',
                'friends',
                'following',
                );
            if (in_array($params[0], $pages) && method_exists($this, $params[0]))
            {
                $this->data['active_page'] = $params[0];
                return $this->$params[0]();
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->data['active_page'] = 'index';
            return $this->index();
        }
    }

    private function about()
    {
        $this->load->view('includes/header');
        $this->load->view('user/about', $this->data);
        $this->load->view('includes/footer');
    }

    private function index()
    {
        $this->db->select('p.site_id,p.title,p.link,p.total_comments,p.time,s.name,s.subdomain,s.domain');
        $this->db->from('blog_posts as p');
        $this->db->join('blog_sites as s', 's.id = p.site_id', 'left');
        $this->db->where('p.user_id', $this->user->id);
        $this->db->where('p.status', 'publish');
        $this->db->where('p.type', 'post');
        $this->db->order_by('p.time', 'DESC');
        $this->db->limit($this->iwb->user_set['offset']);
        $query = $this->db->get();
        $this->data['posts'] = $query->num_rows() == 0 ? null : $query->result();

        $this->load->view('includes/header');
        $this->load->view('user/index', $this->data);
        $this->load->view('includes/footer');
    }

    private function blog()
    {
        $page = abs(intval($this->input->get('page')));
        $this->data['current_page'] = $page = $page < 1 ? 1 : $page;
        $this->data['total'] = $query = $this->db->query("SELECT COUNT(*) AS `num` FROM `" .
            $this->db->dbprefix . "blog_sites` WHERE `user_id` = '" . $this->user->id .
            "' AND `mod_reg` = 'no' AND `block` = 'no'")->row()->num;
        if ($this->data['total'])
        {
            $query = $this->db->query("SELECT `id`,`name`,`subdomain`,`domain`,`followers` FROM `" .
                $this->db->dbprefix . "blog_sites` WHERE `user_id` = '" . $this->user->id .
                "' AND `mod_reg` = 'no' AND `block` = 'no' ORDER BY `created` DESC LIMIT " .
                sql_offset($this->iwb->user_set['offset'], $page) . ", " . $this->iwb->user_set['offset']);
            $this->data['blogs'] = $query->result();
        }
        $this->load->view('includes/header');
        $this->load->view('user/blog', $this->data);
        $this->load->view('includes/footer');
    }

    private function friends()
    {
        $page = abs(intval($this->input->get('page')));
        $this->data['current_page'] = $page = $page < 1 ? 1 : $page;

        $this->load->model('friends_model');
        $user_friends = $this->friends_model->get_friends($this->user->id);
        $this->data['total_friends'] = count($user_friends['friends']);
        $mutual_friends = array_values(array_intersect($user_friends['friends'],
            json_decode($this->iwb->user->friends)));
        $this->data['total_mutual_friends'] = count($mutual_friends);
        if ($this->user->id != $this->iwb->user->id && $this->input->get('show') ==
            'mutual_friends')
        {
            $this->data['show_mutual_friends'] = true;
            $this->data['total'] = $this->data['total_mutual_friends'];
            if ($this->data['total_mutual_friends'])
            {
                $start = sql_offset($this->iwb->user_set['offset'], $page);
                $end = $start + $this->iwb->user_set['offset'];
                if ($end > $this->data['total'])
                {
                    $end = $this->data['total'];
                }
                $this->data['users'] = array();
                for ($i = $start; $i < $end; $i++)
                {
                    $this->data['users'][] = $mutual_friends[$i];
                }
                if (!$this->data['users'])
                {
                    redirect('user/' . $user->username . '/friends?show=mutual_friends');
                }
            }
        }
        else
        {
            $this->data['show_mutual_friends'] = false;
            $this->data['total'] = $this->data['total_friends'];
            if ($user_friends['friends'])
            {
                $start = sql_offset($this->iwb->user_set['offset'], $page);
                $end = $start + $this->iwb->user_set['offset'];
                if ($end > $this->data['total'])
                {
                    $end = $this->data['total'];
                }
                $this->data['users'] = array();
                for ($i = $start; $i < $end; $i++)
                {
                    $this->data['users'][] = $user_friends['friends'][$i];
                }
                if (!$this->data['users'])
                {
                    redirect('user/' . $user->username . '/friends');
                }
            }
        }
        $this->load->view('includes/header');
        $this->load->view('user/friends', $this->data);
        $this->load->view('includes/footer');
    }

    private function following()
    {
        $page = abs(intval($this->input->get('page')));
        $this->data['current_page'] = $page = $page < 1 ? 1 : $page;

        $this->data['total'] = $total = $this->db->query("SELECT COUNT(*) AS `num` FROM `" .
            $this->db->dbprefix . "blog_sites` WHERE `user_id` != '" . $this->user->id .
            "' AND `followers` LIKE '%\"" . $this->user->id . "\"%'")->row()->num;
        if ($total)
        {
            $query = $this->db->query("SELECT `s`.`id`, `s`.`user_id`, `s`.`name`, `s`.`subdomain`, `s`.`domain`, " .
                "`s`.`followers`, `u`.`username` AS `user_username`, `u`.`name` AS `user_name` FROM `" .
                $this->db->dbprefix . "blog_sites` AS `s` LEFT JOIN `" . $this->db->dbprefix .
                "users` AS `u` ON `u`.`id` = `s`.`user_id` WHERE `s`.`user_id` != '" . $this->
                user->id . "' AND `s`.`followers` LIKE '%\"" . $this->user->id . "\"%' AND `s`.`block` = 'no' ORDER BY `s`.`created` DESC LIMIT " .
                sql_offset($this->iwb->user_set['offset'], $page) . ", " . $this->iwb->user_set['offset']);
            $this->data['blogs'] = $query->result();
        }
        $this->load->view('includes/header');
        $this->load->view('user/following', $this->data);
        $this->load->view('includes/footer');
    }
}

?>