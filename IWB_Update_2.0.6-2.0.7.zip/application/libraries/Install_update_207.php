<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Install_update_207
{
    protected $CI;
    protected $version = '2.0.7';

    public function __construct()
    {
        $this->CI = &get_instance();
    }

    public function install($auto = false)
    {
        $this->set_update_history();
        $this->CI->db->where('set_key', 'iwb_version')->update('settings', array('set_value' =>
                $this->version));

        rmdir_recursive(APPPATH . 'templates/');
        $layout = file_get_contents(FCPATH . 'files/tmp/layout.html');
        $dir = FCPATH . 'files/blogs/';
        if ($dh = opendir($dir))
        {
            while (($file = readdir($dh)) !== false)
            {
                if ($file != '.' && $file != '..' && filetype($dir . $file) == 'dir')
                {
                    file_put_contents($dir . $file . '/templates/mobile/layout.html', $layout);
                    file_put_contents($dir . $file . '/templates/desktop/layout.html', $layout);
                }
            }
            closedir($dh);
        }
        unlink(FCPATH . 'files/tmp/layout.html');

        unlink(__file__);
        if (!$auto)
        {
            $this->CI->session->set_flashdata('alert-success',
                'Installasi pembaruan IndoWapBlog v' . $this->version .
                ' berhasil diselesaikan.');
            redirect('admin/indowapblog');
        }
    }

    protected function set_update_history()
    {
        $query = $this->CI->db->query("SELECT * FROM `" . $this->CI->db->dbprefix .
            "update` WHERE `version` = '{$this->version}' LIMIT 1");
        if ($query->num_rows() == 0)
        {
            $this->CI->db->insert('update', array(
                'version' => $this->version,
                'updated' => '0000-00-00 00:00:00',
                'file' => '',
                'changelog' => '',
                'message' => '',
                'installed' => date_sql(time()),
                ));
        }
    }
}
