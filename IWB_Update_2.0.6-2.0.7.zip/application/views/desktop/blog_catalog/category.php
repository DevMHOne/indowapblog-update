<div class="menu-bar">
  <ul>
    <li class="<?=($sort == 'new' ? 'active' : '')?>">
      <a href="<?=site_url(uri_string().'?sort=new')?>"><?=lang('catalog_newer')?></a>
    </li>
    <li class="<?=($sort == 'visits' ? 'active' : '')?>">
      <a href="<?=site_url(uri_string().'?sort=visits')?>"><?=lang('catalog_visits')?></a>
    </li>
  </ul>
</div>
<?php if ($total_blogs==0):?>
<div class="alert alert-warning">
  <?=lang('catalog_no_result')?>
</div>
<?php else:?>
<ul class="list-unstyled">
  <?php foreach ($blogs as $blog):?>
  <?php $blog_url=blog_url($blog);?>
  <li>
    <ul class="list-group">
      <li class="list-group-item list-group-item-default" id="blog-<?=$blog->id?>">
        <h3>
          <a href="<?=$blog_url?>"><?=esc_html($blog->name)?></a>
        </h3>
      </li>
      <li class="list-group-item">
        <?=lang('catalog_author')?>:
        <a href="<?=site_url('user/'.$blog->author_username)?>"><?=esc_html($blog->author_name)?></a>
      </li>
      <?php if ($blog->last_post != 0):?>
      <li class="list-group-item">
        <?=lang('catalog_updated')?>:
        <?=time_ago($blog->last_post)."\r\n"?>
      </li>
      <?php endif?>
      <li class="list-group-item">
        <?=lang('catalog_description')?>:
        <?=esc_html(get_blog_settings($blog->settings['description']))."\r\n"?>
      </li>
      <li class="list-group-item">
        <?=lang('catalog_followers')?>:
        <?=$blog->followers_total."\r\n"?>
      </li>
      <li class="list-group-item">
        <?=lang('catalog_date_reg')?>:
        <?=format_date($blog->created)."\r\n"?>
      </li>
      <?php if ($this->iwb->is_user):?>
      <li class="list-group-item list-group-item-footer">
        <div class="rating pull-left">
          <?=star_rating($blog->rating,$this->iwb->user_id != $blog->user_id ? site_url('pages/blog_rate/'.$blog->id.'?redirect_uri='.urlencode(current_url().'?page='.$current_page.'#blog-'.$blog->id).'&amp;') : '')."\r\n"?>
        </div>
        <span class="pull-right">
        <?php if ($this->iwb->user_id && $this->iwb->user->rights == 10):?>
        <?php if ($blog->block =='no'):?>
        <a class="btn btn-default btn-sm" href="<?=site_url('admin/block_blog/'.$blog->id.'?redirect_uri='.urlencode(current_url()))?>">Block</a>
        <?php else:?>
        <a class="btn btn-default btn-sm" href="<?=site_url('admin/unblock_blog/'.$blog->id.'?redirect_uri='.urlencode(current_url()))?>">Unblock</a>
        <?php endif?>
        <a class="btn btn-default btn-sm" href="<?=site_url('admin/delete_blog/'.$blog->id.'?redirect_uri='.urlencode(current_url()))?>"><?=lang('iwb_delete')?></a>
        <?php endif?>
        <?php if (strpos($blog->followers,'"'.$this->iwb->user_id.'"') === false):?>
        <a class="btn btn-default btn-sm" href="<?=$blog_url?>/login.html?redirect_uri=<?=urlencode($blog_url.'/follow.html')?>"><?=lang('catalog_follow')?></a>
        <?php else:?>
        <a class="btn btn-default btn-sm" href="<?=$blog_url?>/login.html?redirect_uri=<?=urlencode($blog_url.'/follow.html')?>"><?=lang('catalog_unfollow')?></a>
        <?php endif?>
        </span>
        <div class="clear"></div>
      </li>
      <?php endif?>
    </ul>
  </li>
  <?php endforeach?>
</ul>
<?=pagination_link(site_url(uri_string(). '?sort='.$sort. '&amp;page='), sql_offset($this->
  iwb->user_set['offset'], $current_page), $total_blogs, $this->iwb->user_set['offset'])?>
<?php endif?>