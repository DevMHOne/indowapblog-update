<?php if ($total == 0):?>
<div class="alert alert-info">
  Tidak ada riwayat pembaruan.
</div>
<?php else:?>
<?php foreach ($histories as $history):?>
<div class="list-group">
  <div class="list-group-item list-group-item-default">
    IndoWapBlog v<?=$history->version?>
  </div>
  <div class="list-group-item">
    Rilis: <?=$history->updated != '0000-00-00 00:00:00' ? format_date(strtotime($history->updated)) : ''?>
  </div>
  <div class="list-group-item">
    Berkas Pembaruan: <?=auto_link($history->file)?>
  </div>
  <div class="list-group-item">
    Perubahan: <?php if ($history->changelog): $ch = json_decode($history->changelog); ?>
    <ol style="margin-bottom: 0;"><?php foreach($ch as $cl):?><li><?=esc_html($cl)?></li><?php endforeach?></ol>
    <?php endif?>
  </div>
  <div class="list-group-item">
    Pesan: <?=nl2br(esc_html($history->message))?>
  </div>
  <div class="list-group-item">
    Waktu Penginstallan: <?=format_date(strtotime($history->installed))?>
  </div>
</div>
<?php endforeach?>
<?= pagination_link(site_url('admin/indowapblog/update_history') . '?page=', sql_offset($this->iwb->user_set['offset'],
    $current_page), $total, $this->iwb->user_set['offset']) ?>
<?php endif?>