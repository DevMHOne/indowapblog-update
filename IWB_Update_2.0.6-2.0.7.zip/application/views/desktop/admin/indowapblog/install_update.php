<div class="alert alert-warning">
    Situs ini menggunakan <strong>IndoWapBlog v<?=$this->iwb->set['iwb_version']?></strong>.
    <br />
    Pembaruan IndoWapBlog ke versi terbaru harus lebih tinggi satu tingkat dari versi sekarang,
    sebagai contoh v2.0.0 harus diperbarui ke versi v2.0.1 dan tidak boleh langsung ke v2.0.2.<br />
    Salah menginstall pembaruan dapat berakibat FATAL!.
</div>
<?=$error?>
<?=form_open_multipart()?>
  <div class="form-group">
    <label for="userfile">
      Berkas Pembaruan
    </label>
    <input type="file" name="userfile" id="userfile"/>
    <p class="help-block">
      Silakan masuk ke halaman <a href="<?=site_url('admin/indowapblog/check_for_update')?>" target="_blank">Periksa Pembaruan</a> dan download berkas pembaruan selanjutnya upload di sini.
    </p>
  </div>
  <p>
    <input class="btn btn-primary" type="submit" name="upload" value="Upload"/>
  </p>
<?form_close()?>