<?php if (validation_errors() != null):?>
<div class="alert alert-danger">
	<strong>
		<?=lang('iwb_error')?>!
	</strong>
	<ol class="list-unstyled">
		<?=validation_errors( '<li>', '</li>')?>
	</ol>
</div>
<?php endif?>
<?=form_open()?>
  <div class="form-group">
    <label for="iwb_update_url">
      URL Server Pembaruan
    </label>
    <input type="text" class="form-control" name="iwb_update_url" id="iwb_update_url" value="<?=set_value('iwb_update_url',$this->iwb->set['iwb_update_url'])?>"/>
    <p class="help-block">
      Silakan tanyakan kepada
      <a href="http://facebook.com/achunks" target="_blank">Achunk JealousMan</a>
      tentang url server pembaruan.
    </p>
  </div>
  <div class="form-group">
    <label for="auto_update_iwb">
      Pembaruan Otomatis
    </label>
    <select class="form-control" name="auto_update_iwb" id="auto_update_iwb">
      <option value="everytime" <?=set_select('auto_update_iwb', 'everytime', $update['set'] == 'everytime' ? true : false); ?>>
        Setiap waktu
      </option>
      <option value="daily"<?=set_select('auto_update_iwb', 'daily', $update['set'] == 'daily' ? true : false); ?>>
        Sehari sekali
      </option>
      <option value="weekly"<?=set_select('auto_update_iwb', 'weekly', $update['set'] == 'weekly' ? true : false); ?>>
        Seminggu sekali
      </option>
      <option value="monthly"<?=set_select('auto_update_iwb', 'monthly', $update['set'] == 'monthly' ? true : false); ?>>
        Sebulan sekali
      </option>
      <option value="never"<?=set_select('auto_update_iwb', 'never', $update['set'] == 'never' ? true : false); ?>>
        Jangan perbarui otomatis
      </option>
    </select>
    <p class="help-block">
      Jika ingin mendapatkan dukungan penuh dari Achunk JealousMan silakan pilih 'Setiap waktu', karena situs yang menggunakan IndoWapBlog versi terbaru paling disukai dan diutamakan dalam memberi dukungan
      dan bantuan.
    </p>
  </div>
  <p>
    <button class="btn btn-primary" type="submit">
      Simpan
    </button>
  </p>
<?form_close()?>