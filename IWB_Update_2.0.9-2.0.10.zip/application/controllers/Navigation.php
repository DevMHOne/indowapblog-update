<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Navigation extends IWB_Controller
{
    private $blog = false;
    private $nav_theme;

    public function __construct()
    {
        parent::__construct();
        $this->lang->load('panel');
        if (!$this->iwb->is_user)
        {
            $this->session->set_userdata('login_redirect', current_url());
            redirect('site/login');
        }
        $this->load->model('blog_model');
        if (!$blog = $this->blog_model->authorization())
        {
            $this->session->set_flashdata('alert-info', lang('iwb_blog_not_logged_in'));
            redirect('account/blog?redirect_uri=' . urlencode(current_url() . '?' . $this->
                input->server('QUERY_STRING', true)));
        }
        $this->blog = $blog;
        $this->blog->{'url'} = blog_url($blog);
        $this->config->set_item('page_title', lang('panel_navigation'));
        $this->breadcrumbs->set(lang('iwb_dashboard'), 'dashboard');
        $this->nav_theme = in_array($this->input->get('theme'), array(
            'mobile',
            'desktop',
            )) ? $this->input->get('theme') : 'mobile';
    }

    public function index()
    {
        $data = array();
        $data['blog'] = $this->blog;
        $page = abs(intval($this->input->get('page')));
        $data['current_page'] = $page < 1 ? 1 : $page;
        $data['theme'] = $this->nav_theme;

        $data['navigations'] = $this->blog_model->read_navigation($this->blog->id, $data['theme']);
        $data['total_navigations'] = count($data['navigations']);
        if ($this->input->post('code'))
        {
            if ($data['total_navigations'] >= 30)
            {
                $this->session->set_flashdata('alert-danger', lang('panel_nav_terms'));
            }
            else
            {
                $this->load->library('form_validation');
                $input = array('code' => trim($this->input->post('code')));
                $this->form_validation->set_data($input);
                $this->form_validation->set_rules('code', lang('panel_nav_code'),
                    'required|max_length[5000]');
                if ($this->form_validation->run() != false)
                {
                    if ($this->iwb->get_setting('allow_js') == 'no')
                    {
                        $this->load->helper('htmlpurifier');
                        $input['code'] = html_purify($input['code'], 'post');
                    }
                    if (!$this->blog_model->insert_navigation($this->blog->id, $data['theme'], $input['code']))
                    {
                        $this->session->set_flashdata('aler-danger', lang('panel_nav_err_saved'));
                    }
                    redirect('navigation?theme=' . $data['theme'] . '#add-new');
                }
            }
        }

        $this->breadcrumbs->set(lang('panel_navigation'));
        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('navigation/index', $data);
        $this->load->view('includes/footer');
    }

    public function move_up($key = 0)
    {
        $key = abs(intval($key)) - 1;
        $nav = $this->blog_model->read_navigation($this->blog->id, $this->nav_theme);
        if (array_key_exists($key, $nav) && $key > 0)
        {
            $code = array();
            for ($i = 0; $i < count($nav); $i++)
            {
                if ($i == $key)
                    $k = $i - 1;
                elseif ($i == ($key - 1))
                    $k = $key;
                else
                    $k = $i;
                $code[] = $nav[$k];
            }
            if (!$this->blog_model->save_navigation($this->blog->id, $this->nav_theme,
                json_encode($code)))
            {
                $this->session->set_flashdata('alert-danger', lang('panel_nav_err_saved'));
            }
        }
        redirect($this->get_redirect('navigation?theme=' . $this->nav_theme));
    }

    public function move_down($key = 0)
    {
        $key = abs(intval($key)) - 1;
        $nav = $this->blog_model->read_navigation($this->blog->id, $this->nav_theme);
        if (array_key_exists($key, $nav) && $key < (count($nav) - 1))
        {
            $code = array();
            for ($i = 0; $i < count($nav); $i++)
            {
                if ($i == $key)
                    $k = $i + 1;
                elseif ($i == ($key + 1))
                    $k = $key;
                else
                    $k = $i;
                $code[] = $nav[$k];
            }
            if (!$this->blog_model->save_navigation($this->blog->id, $this->nav_theme,
                json_encode($code)))
            {
                $this->session->set_flashdata('alert-danger', lang('panel_nav_err_saved'));
            }
        }
        redirect($this->get_redirect('navigation?theme=' . $this->nav_theme));
    }

    public function delete($key = 0)
    {
        $key = abs(intval($key)) - 1;
        $nav = $this->blog_model->read_navigation($this->blog->id, $this->nav_theme);
        if (array_key_exists($key, $nav))
        {
            $this->get_skip_confirm();

            if ($this->input->post() || $this->session->has_userdata('skip_confirm'))
            {
                unset($nav[$key]);
                if (!$this->blog_model->save_navigation($this->blog->id, $this->nav_theme,
                    json_encode(array_values($nav))))
                {
                    $this->session->set_flashdata('alert-danger', lang('panel_nav_err_saved'));
                }
            }
            else
            {
                return $this->confirm(current_url(), lang('panel_nav_del_conf'), false, $this->
                    set_skip_confirm());
            }
        }
        redirect($this->get_redirect('navigation?theme=' . $this->nav_theme));
    }

    public function edit($key = 0)
    {
        $key = abs(intval($key)) - 1;
        $nav = $this->blog_model->read_navigation($this->blog->id, $this->nav_theme);
        if (!array_key_exists($key, $nav))
        {
            redirect('navigation?theme=' . $this->nav_theme);
        }
        $data = array();
        $data['blog'] = $this->blog;
        $data['navigation'] = $nav[$key];
        $data['theme'] = $this->nav_theme;

        if ($this->input->post('code'))
        {
            $this->load->library('form_validation');
            $input = array('code' => trim($this->input->post('code')));
            $this->form_validation->set_data($input);
            $this->form_validation->set_rules('code', lang('panel_nav_code'),
                'required|max_length[5000]');
            if ($this->form_validation->run() != false)
            {
                if ($this->iwb->get_setting('allow_js') == 'no')
                {
                    $this->load->helper('htmlpurifier');
                    $nav[$key] = html_purify($input['code'], 'post');
                }
                else
                    $nav[$key] = $input['code'];
                if (!$this->blog_model->save_navigation($this->blog->id, $this->nav_theme,
                    json_encode($nav)))
                {
                    $this->session->set_flashdata('alert-danger', lang('panel_nav_err_saved'));
                }
                else
                {
                    $this->session->set_flashdata('alert-success', lang('iwb_change_saved'));
                }
                redirect('navigation?theme=' . $data['theme']);
            }
        }

        $this->breadcrumbs->set(lang('panel_navigation'), 'navigation');
        $this->breadcrumbs->set(lang('iwb_edit'));
        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('navigation/edit', $data);
        $this->load->view('includes/footer');
    }
}
