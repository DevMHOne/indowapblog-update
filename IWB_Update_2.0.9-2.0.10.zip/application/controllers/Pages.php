<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Pages extends IWB_Controller
{
    private $blog = false;

    public function __construct()
    {
        parent::__construct();
        $this->lang->load('panel');
        if (!$this->iwb->is_user)
        {
            $this->session->set_userdata('login_redirect', current_url());
            redirect('site/login');
        }
        $this->load->model('blog_model');
        if (!$blog = $this->blog_model->authorization())
        {
            $this->session->set_flashdata('alert-info', lang('iwb_blog_not_logged_in'));
            redirect('account/blog?redirect_uri=' . urlencode(current_url() . '?' . $this->
                input->server('QUERY_STRING', true)));
        }
        $this->blog = $blog;
        $this->blog->{'url'} = blog_url($blog);
        $this->breadcrumbs->set(lang('iwb_dashboard'), 'dashboard');
    }

    public function index()
    {
        $this->config->set_item('page_title', lang('panel_pages'));
        $page = abs(intval($this->input->get('page')));
        $page = $page < 1 ? 1 : $page;

        $data = array();
        $data['blog'] = $this->blog;
        $data['current_page'] = $page;
        $data['pages'] = null;
        $data['show_search'] = '';
        $visibilities = array(
            'public',
            'friends',
            'followers',
            );
        $status = array('publish', 'draft');
        if (($r_visibility = $this->input->get('visibility', true)) != null)
        {
            if (!in_array($r_visibility, $visibilities))
            {
                $this->session->set_flashdata('alert-danger', lang('iwb_error_400'));
                redirect('pages');
            }
            $this->breadcrumbs->set(lang('panel_pages'), 'pages', true);
            $this->breadcrumbs->set(lang('panel_visibility') . ': ' . lang('panel_post_vsb_' .
                $r_visibility));

            $data['total_pages'] = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->
                db->dbprefix . "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                "' AND `visibility` = ? AND `type` = 'page'", array($r_visibility))->row()->num;
            if ($data['total_pages'] != 0)
            {
                $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                    "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                    "' AND `visibility` = ? AND `type` = 'page' ORDER BY `time` DESC LIMIT " .
                    sql_offset($this->iwb->user_set['offset'], $page) . ", " . $this->iwb->user_set['offset'] .
                    ";", array($r_visibility));
                $data['pages'] = $query->result();
            }
            $data['show_visibility'] = $r_visibility;
        }
        elseif (($r_status = $this->input->get('status', true)) != null)
        {
            if (!in_array($r_status, $status))
            {
                $this->session->set_flashdata('alert-danger', lang('iwb_error_400'));
                redirect('pages');
            }
            $this->breadcrumbs->set(lang('panel_pages'), 'pages');
            $this->breadcrumbs->set(lang('panel_status') . ': ' . lang('panel_post_sts_' . $r_status));

            $data['total_pages'] = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->
                db->dbprefix . "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                "' AND `status` = ? AND `type` = 'page'", array($r_status))->row()->num;
            if ($data['total_pages'] != 0)
            {
                $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                    "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                    "' AND `status` = ? AND `type` = 'page' ORDER BY `time` DESC LIMIT " .
                    sql_offset($this->iwb->user_set['offset'], $page) . ", " . $this->iwb->user_set['offset'] .
                    ";", array($r_status));
                $data['pages'] = $query->result();
            }
            $data['show_status'] = $r_status;
        }
        elseif (($r_search = $this->input->get('search', true)) != null)
        {
            if (mb_strlen($r_search) < 2 || mb_strlen($r_search) > 12)
            {
                $this->session->set_flashdata('alert-danger', lang('panel_search_terms'));
                redirect('pages');
            }
            $this->breadcrumbs->set(lang('panel_pages'), 'pages');
            $this->breadcrumbs->set(lang('iwb_search') . ': ' . esc_html($r_search));

            $data['total_pages'] = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->
                db->dbprefix . "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                "' AND `title` LIKE ? AND `type` = 'page'", array('%' . $r_search . '%'))->row()->
                num;
            if ($data['total_pages'] != 0)
            {
                $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                    "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                    "' AND `title` LIKE ? AND `type` = 'page' ORDER BY `time` DESC LIMIT " .
                    sql_offset($this->iwb->user_set['offset'], $page) . ", " . $this->iwb->user_set['offset'] .
                    ";", array('%' . $r_search . '%'));
                $data['pages'] = $query->result();
            }
            $data['show_search'] = $r_search;
        }
        else
        {
            $this->breadcrumbs->set(lang('panel_pages'));
            $data['total_pages'] = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->
                db->dbprefix . "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                "' AND `type` = 'page'")->row()->num;
            if ($data['total_pages'] != 0)
            {
                $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                    "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                    "' AND `type` = 'page' ORDER BY `time` DESC LIMIT " . sql_offset($this->iwb->
                    user_set['offset'], $page) . ", " . $this->iwb->user_set['offset'] . ";");
                $data['pages'] = $query->result();
            }
        }
        $this->load->view('includes/header');
        $this->load->view('pages/index', $data);
        $this->load->view('includes/footer');
    }

    public function add_new()
    {
        $this->breadcrumbs->set(lang('panel_pages'), 'pages');
        $this->breadcrumbs->set(lang('panel_add_new_page'), '', true);
        $data = array();
        $data['blog'] = $this->blog;
        if ($this->input->post())
        {
            $this->load->library('form_validation');
            $inputs = array(
                'title' => trim($this->input->post('title')),
                'content' => trim($this->input->post('content')),
                'visibility' => $this->input->post('visibility'),
                );
            if ($this->input->post('insert_file') != 'none')
            {
                $file_add = $this->input->post('insert_file', true);
                $exp = @explode('.', $file_add, 2);
                $ext = @$exp[1];
                if (in_array('.' . $ext, image_types()))
                {
                    $inputs['content'] = $inputs['content'] . "\r\n<img src=\"" . $this->blog->url .
                        "/files/" . esc_html($file_add) . "\" />";
                }
                else
                {
                    $inputs['content'] = $inputs['content'] . "\r\n<a href=\"" . $this->blog->url .
                        "/files/" . esc_html($file_add) . "\">" . esc_html($file_add) . "</a>";
                }
            }
            $this->form_validation->set_data($inputs);
            $inputs['categories'] = '[]';
            $inputs['tags'] = '[]';
            $rules = array();
            $rules[] = array(
                'field' => 'title',
                'label' => lang('panel_title'),
                'rules' => 'required|min_length[2]|max_length[100]',
                );
            $rules[] = array(
                'field' => 'content',
                'label' => lang('panel_content'),
                'rules' => 'required|min_length[2]',
                );
            $rules[] = array(
                'field' => 'visibility',
                'label' => lang('panel_visibility'),
                'rules' => 'required|in_list[public,friends,followers]',
                );

            $this->form_validation->set_rules($rules);

            if ($this->form_validation->run() != false)
            {
                if ($this->input->post('insert_file') == 'none')
                {
                    $inputs['site_id'] = $this->blog->id;
                    $inputs['user_id'] = $this->blog->user_id;
                    $inputs['link'] = $this->blog_model->get_permalink($this->blog->id, $inputs['title'],
                        'page');
                    $inputs['type'] = 'page';

                    if ($this->input->post('preview'))
                    {
                        $inputs['status'] = 'draft';
                        $redirect = $this->blog->url . '/login.html?redirect_uri=' . urlencode($this->
                            blog->url . '/pages/' . $inputs['link']) . '.html';
                    }
                    elseif ($this->input->post('draft'))
                    {
                        $inputs['status'] = 'draft';
                        $this->session->set_flashdata('alert-success', lang('panel_add_page_draft'));
                        $redirect = 'pages';
                    }
                    else
                    {
                        $inputs['status'] = 'publish';
                        $this->session->set_flashdata('alert-success', lang('panel_add_page_published'));
                        $redirect = 'pages';
                    }
                    if ($this->iwb->get_setting('allow_js') == 'no')
                    {
                        $this->load->helper('htmlpurifier');
                        $inputs['content'] = html_purify($inputs['content'], 'post');
                    }
                    $this->blog_model->write_post($inputs);
                    redirect($redirect);
                }
            }
        }
        $this->load->helper('form');
        $data['blog_files'] = get_blog_files($this->blog->id);
        $head_meta = '<link rel="stylesheet" href="' . base_url('/assets/editor/tinyeditor.css') .
            '" /><script type="text/javascript" src="' . base_url('/assets/editor/tinyeditor.js') .
            '"></script>';

        $this->load->view('includes/header', array('head_meta' => (!$this->agent->
                is_mobile() ? $head_meta : '')));
        $this->load->view('pages/add_new', $data);
        $this->load->view('includes/footer');
    }

    public function edit($id)
    {
        if (!$id)
        {
            return $this->display_error(lang('iwb_error_400'));
        }
        $query = $this->db->where(array(
            'id' => $id,
            'site_id' => $this->blog->id,
            'type' => 'page',
            ))->get('blog_posts');
        if ($query->num_rows() == 0)
        {
            return $this->display_error(lang('panel_post_not_found'));
            return;
        }

        $data = array();
        $data['blog'] = $this->blog;
        $data['page'] = $query->row();

        if ($this->input->post())
        {
            $this->load->library('form_validation');

            $inputs = array(
                'title' => trim($this->input->post('title')),
                'content' => trim($this->input->post('content')),
                'visibility' => $this->input->post('visibility'),
                );
            if ($this->input->post('insert_file') != 'none')
            {
                $file_add = $this->input->post('insert_file', true);
                $exp = @explode('.', $file_add, 2);
                $ext = @$exp[1];
                if (in_array('.' . $ext, image_types()))
                {
                    $inputs['content'] = $inputs['content'] . "\r\n<img src=\"" . $this->blog->url .
                        "/files/" . esc_html($file_add) . "\" />";
                }
                else
                {
                    $inputs['content'] = $inputs['content'] . "\r\n<a href=\"" . $this->blog->url .
                        "/files/" . esc_html($file_add) . "\">" . esc_html($file_add) . "</a>";
                }
            }
            $this->form_validation->set_data($inputs);
            $rules = array();
            $rules[] = array(
                'field' => 'title',
                'label' => lang('panel_title'),
                'rules' => 'required|min_length[2]|max_length[100]',
                );
            $rules[] = array(
                'field' => 'content',
                'label' => lang('panel_content'),
                'rules' => 'required|min_length[2]',
                );
            $rules[] = array(
                'field' => 'visibility',
                'label' => lang('panel_visibility'),
                'rules' => 'required|in_list[public,friends,followers]',
                );

            $this->form_validation->set_rules($rules);

            if ($this->form_validation->run() != false)
            {
                if ($this->input->post('insert_file') == 'none')
                {
                    if ($this->input->post('draft'))
                    {
                        $this->session->set_flashdata('alert-success', lang('panel_page_upd_draft'));
                        $inputs['status'] = 'draft';
                        $redirect = 'pages';
                    }
                    elseif ($this->input->post('preview'))
                    {
                        $inputs['status'] = 'draft';
                        $redirect = $this->blog->url . '/login.html?redirect_uri=' . urlencode($this->
                            blog->url . '/pages/' . $data['page']->link . '.html');
                    }
                    elseif ($this->input->post('publish'))
                    {
                        $this->session->set_flashdata('alert-success', lang('panel_page_upd_published'));
                        $inputs['status'] = 'publish';
                        $redirect = 'pages';
                    }
                    if ($this->iwb->get_setting('allow_js') == 'no')
                    {
                        $this->load->helper('htmlpurifier');
                        $inputs['content'] = html_purify($inputs['content'], 'post');
                    }
                    $this->db->where('id', $data['page']->id)->update('blog_posts', $inputs);
                    redirect($redirect);
                }
            }
        }
        $this->load->helper('form');
        $head_meta = '<link rel="stylesheet" href="' . base_url('/assets/editor/tinyeditor.css') .
            '" /><script type="text/javascript" src="' . base_url('/assets/editor/tinyeditor.js') .
            '"></script>';

        $this->breadcrumbs->set(lang('panel_pages'), 'pages');
        $this->breadcrumbs->set(lang('iwb_edit'));
        $data['blog_files'] = get_blog_files($this->blog->id);
        $this->load->view('includes/header', array('head_meta' => (!$this->agent->
                is_mobile() ? $head_meta : '')));
        $this->load->view('pages/edit', $data);
        $this->load->view('includes/footer');
    }

    public function delete($id = 0)
    {
        $id = abs(intval($id));
        if (!$id)
        {
            return $this->display_error(lang('iwb_error_400'));
        }
        $query = $this->db->where(array(
            'id' => $id,
            'site_id' => $this->blog->id,
            'type' => 'page',
            ))->get('blog_posts');
        if ($query->num_rows() == 0)
        {
            return $this->display_error(lang('panel_post_not_found'));
        }
        else
        {
            $post = $query->row();
        }
        if ($this->input->post())
        {
            $this->db->where(array('id' => $id, 'site_id' => $this->blog->id))->delete('blog_posts');
            $this->session->set_flashdata('alert-success', lang('panel_page_deleted'));
            redirect('pages');
        }
        $this->breadcrumbs->set(lang('panel_pages'), 'pages', true);
        $this->breadcrumbs->set(lang('iwb_delete'));
        return $this->confirm(current_url(), lang('panel_page_del_conf'));
    }

    public function publish_page($id)
    {
        if (!$id)
        {
            return $this->display_error(lang('iwb_error_400'));
        }
        $query = $this->db->where(array(
            'id' => $id,
            'site_id' => $this->blog->id,
            'type' => 'page',
            ))->get('blog_posts');
        if ($query->num_rows() == 0)
        {
            return $this->display_error(lang('iwb_error_404'));
        }
        $this->db->where('id', $id)->update('blog_posts', array('status' => 'publish'));
        $this->session->set_flashdata('alert-success', lang('panel_page_published'));
        redirect($this->input->get('redirect_uri') != null ? esc_html(urldecode($this->
            input->get('redirect_uri', true))) : 'pages/');
    }
}
