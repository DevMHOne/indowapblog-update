<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Posts extends IWB_Controller
{
    private $blog = false;

    public function __construct()
    {
        parent::__construct();
        $this->lang->load('panel');
        if (!$this->iwb->is_user)
        {
            $this->session->set_userdata('login_redirect', current_url());
            redirect('site/login');
        }
        $this->load->model('blog_model');
        if (!$blog = $this->blog_model->authorization())
        {
            $this->session->set_flashdata('alert-info', lang('iwb_blog_not_logged_in'));
            redirect('account/blog?redirect_uri=' . urlencode(current_url() . '?' . $this->
                input->server('QUERY_STRING', true)));
        }
        $this->blog = $blog;
        $this->blog->{'url'} = blog_url($blog);
        $this->config->set_item('page_title', lang('panel_posts'));
        $this->breadcrumbs->set(lang('iwb_dashboard'), 'dashboard');
    }

    public function index()
    {
        $page = abs(intval($this->input->get('page')));
        $page = $page < 1 ? 1 : $page;

        $this->breadcrumbs->set(lang('panel_posts'));

        $data = array();
        $data['blog'] = $this->blog;
        $data['current_page'] = $page;
        $data['categories'] = array();
        $categories = $this->blog_model->get_category($this->blog->id);
        if ($categories != null)
        {
            foreach ($categories as $category)
            {
                $data['categories'][$category->link] = $category->name;
            }
        }
        $data['posts'] = null;
        $data['show_search'] = '';
        $visibilities = array(
            'public',
            'friends',
            'followers',
            );
        $status = array('publish', 'draft');
        if (($r_category = strtolower($this->input->get('category', true))) != null)
        {
            if (!array_key_exists($r_category, $data['categories']))
            {
                $this->session->set_flashdata('alert-danger', lang('panel_category_not_found'));
                redirect('posts');
            }

            $data['total_posts'] = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->
                db->dbprefix . "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                "' AND `categories` LIKE ? AND `type` = 'post'", array('%"' . $r_category . '"%'))->
                row()->num;
            if ($data['total_posts'] != 0)
            {
                $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                    "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                    "' AND `categories` LIKE ? AND `type` = 'post' ORDER BY `time` DESC LIMIT " .
                    sql_offset($this->iwb->user_set['offset'], $page) . ", " . $this->iwb->user_set['offset'] .
                    ";", array('%"' . $r_category . '"%'));
                $data['posts'] = $query->result();
            }
            $data['show_category'] = $data['categories'][$r_category];
        }
        elseif (($r_visibility = $this->input->get('visibility', true)) != null)
        {
            if (!in_array($r_visibility, $visibilities))
            {
                $this->session->set_flashdata('alert-danger', lang('iwb_error_400'));
                redirect('posts');
            }
            $data['total_posts'] = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->
                db->dbprefix . "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                "' AND `visibility` = ? AND `type` = 'post'", array($r_visibility))->row()->num;
            if ($data['total_posts'] != 0)
            {
                $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                    "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                    "' AND `visibility` = ? AND `type` = 'post' ORDER BY `time` DESC LIMIT " .
                    sql_offset($this->iwb->user_set['offset'], $page) . ", " . $this->iwb->user_set['offset'] .
                    ";", array($r_visibility));
                $data['posts'] = $query->result();
            }
            $data['show_visibility'] = $r_visibility;
        }
        elseif (($r_status = $this->input->get('status', true)) != null)
        {
            if (!in_array($r_status, $status))
            {
                $this->session->set_flashdata('alert-danger', lang('iwb_error_400'));
                redirect('posts');
            }
            $data['total_posts'] = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->
                db->dbprefix . "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                "' AND `status` = ? AND `type` = 'post'", array($r_status))->row()->num;
            if ($data['total_posts'] != 0)
            {
                $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                    "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                    "' AND `status` = ? AND `type` = 'post' ORDER BY `time` DESC LIMIT " .
                    sql_offset($this->iwb->user_set['offset'], $page) . ", " . $this->iwb->user_set['offset'] .
                    ";", array($r_status));
                $data['posts'] = $query->result();
            }
            $data['show_status'] = $r_status;
        }
        elseif (($r_search = $this->input->get('search', true)) != null)
        {
            if (mb_strlen($r_search) < 2 || mb_strlen($r_search) > 12)
            {
                $this->session->set_flashdata('alert-danger', lang('panel_search_terms'));
                redirect('posts');
            }
            $data['total_posts'] = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->
                db->dbprefix . "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                "' AND `title` LIKE ? AND `type` = 'post'", array('%' . $r_search . '%'))->row()->
                num;
            if ($data['total_posts'] != 0)
            {
                $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                    "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                    "' AND `title` LIKE ? AND `type` = 'post' ORDER BY `time` DESC LIMIT " .
                    sql_offset($this->iwb->user_set['offset'], $page) . ", " . $this->iwb->user_set['offset'] .
                    ";", array('%' . $r_search . '%'));
                $data['posts'] = $query->result();
            }
            $data['show_search'] = $r_search;
        }
        elseif (($r_tag = $this->input->get('tag', true)) != null)
        {
            $data['total_posts'] = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->
                db->dbprefix . "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                "' AND `tags` LIKE ? AND `type` = 'post'", array('%' . $r_tag . '%'))->row()->
                num;
            if ($data['total_posts'] != 0)
            {
                $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                    "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                    "' AND `tags` LIKE ? AND `type` = 'post' ORDER BY `time` DESC LIMIT " .
                    sql_offset($this->iwb->user_set['offset'], $page) . ", " . $this->iwb->user_set['offset'] .
                    ";", array('%' . $r_tag . '%'));
                $data['posts'] = $query->result();
            }
            $data['show_tag'] = $tag_name;
        }
        else
        {
            $data['total_posts'] = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->
                db->dbprefix . "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                "' AND `type` = 'post'")->row()->num;
            if ($data['total_posts'] != 0)
            {
                $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                    "blog_posts` WHERE `site_id` = '" . $this->blog->id .
                    "' AND `type` = 'post' ORDER BY `time` DESC LIMIT " . sql_offset($this->iwb->
                    user_set['offset'], $page) . ", " . $this->iwb->user_set['offset'] . ";");
                $data['posts'] = $query->result();
            }
        }
        $this->load->view('includes/header');
        $this->load->view('posts/index', $data);
        $this->load->view('includes/footer');
    }

    public function add_new()
    {
        $this->breadcrumbs->set(lang('panel_posts'), 'posts');
        $this->breadcrumbs->set(lang('panel_add_new_post'), '', true);
        $data = array();
        $data['postdate'] = $this->blog_model->form_postdate();
        $head_meta = '<link rel="stylesheet" href="' . base_url('/assets/editor/tinyeditor.css') .
            '" /><script type="text/javascript" src="' . base_url('/assets/editor/tinyeditor.js') .
            '"></script>';
        $data['blog'] = $this->blog;
        if ($this->input->get('insert_file'))
        {
            $file = @explode('.', $this->input->get('insert_file', true), 2);
            if (in_array('.' . @$file[1], image_types()))
            {
                $data['content'] = '<img src="' . $this->blog->url . '/files/' . esc_html($this->
                    input->get('insert_file', true)) . '"/>';
            }
            else
            {
                $data['content'] = '<a href="' . $this->blog->url . '/files/' . esc_html($this->
                    input->get('insert_file', true)) . '">' . esc_html($this->input->get('insert_file', true)) .
                    '</a>';
            }
        }
        else
        {
            $data['content'] = '';
        }
        $data['categories'] = $categories = $this->blog_model->get_category($this->blog->
            id);
        if ($this->input->post())
        {
            $this->load->library('form_validation');
            $inputs = array(
                'title' => trim($this->input->post('title')),
                'content' => trim($this->input->post('content')),
                'p_categories' => $this->input->post('p_categories'),
                'tags' => trim($this->input->post('tags')),
                'visibility' => $this->input->post('visibility'),
                'time' => $this->blog_model->get_postdate(),
                );
            if ($this->input->post('insert_file') != 'none')
            {
                $file_add = $this->input->post('insert_file', true);
                $exp = @explode('.', $file_add, 2);
                $ext = @$exp[1];
                if (in_array('.' . $ext, image_types()))
                {
                    $inputs['content'] = $inputs['content'] . "\r\n<img src=\"" . $this->blog->url .
                        "/files/" . esc_html($file_add) . "\" />";
                }
                else
                {
                    $inputs['content'] = $inputs['content'] . "\r\n<a href=\"" . $this->blog->url .
                        "/files/" . esc_html($file_add) . "\">" . esc_html($file_add) . "</a>";
                }
            }
            $this->form_validation->set_data($inputs);
            $inputs['categories'] = '[]';
            $rules = array();
            $rules[] = array(
                'field' => 'title',
                'label' => lang('panel_title'),
                'rules' => 'required|min_length[2]|max_length[100]',
                );
            $rules[] = array(
                'field' => 'content',
                'label' => lang('panel_content'),
                'rules' => 'required|min_length[2]',
                );
            $rules[] = array(
                'field' => 'p_categories',
                'label' => lang('panel_category'),
                'rules' => array(array('category_callable', function ($str)use ($categories, &$inputs)
                        {
                            if ($categories != null && $inputs['p_categories'] != null)
                            {
                                $cats = array(); foreach ($categories as $category)
                                {
                                    $cats[] = $category->link; }
                                foreach ($inputs['p_categories'] as $inp_cat)
                                {
                                    if (!in_array($inp_cat, $cats))
                                    {
                                        $this->form_validation->set_message('category_callable', lang('panel_err_category'));
                                            return false; }
                                }
                                $inputs['categories'] = json_encode($inputs['p_categories']); }
                        }
                        )),
                );
            $rules[] = array(
                'field' => 'tags',
                'label' => lang('panel_tags'),
                'rules' => 'min_length[2]|max_length[100]',
                );
            $rules[] = array(
                'field' => 'visibility',
                'label' => lang('panel_visibility'),
                'rules' => 'required|in_list[public,friends,followers]',
                );
            $this->form_validation->set_rules($rules);

            if ($this->form_validation->run() != false)
            {
                if ($this->input->post('insert_file') == 'none')
                {
                    if ($this->iwb->get_setting('allow_js') == 'no')
                    {
                        $this->load->helper('htmlpurifier');
                        $inputs['content'] = html_purify($inputs['content'], 'post');
                    }
                    $inputs['site_id'] = $this->blog->id;
                    $inputs['user_id'] = $this->blog->user_id;
                    $inputs['tags'] = json_encode(str_tags($inputs['tags']));
                    $inputs['link'] = $this->blog_model->get_permalink($this->blog->id, $inputs['title'],
                        'post');
                    unset($inputs['p_categories']);

                    if ($inputs['time'] > time())
                    {
                        $inputs['status'] = 'draft';
                        $redirect = 'posts';
                    }
                    elseif ($this->input->post('preview'))
                    {
                        $inputs['status'] = 'draft';
                        $redirect = $this->blog->url . '/login.html?redirect_uri=' . urlencode($this->
                            blog->url . '/' . $inputs['link']) . '.html';
                    }
                    elseif ($this->input->post('draft'))
                    {
                        $inputs['status'] = 'draft';
                        $this->session->set_flashdata('alert-success', lang('panel_add_post_draft'));
                        $redirect = 'posts';
                    }
                    else
                    {
                        $inputs['status'] = 'publish';
                        $this->session->set_flashdata('alert-success', lang('panel_add_post_published'));
                        $redirect = 'posts';
                    }
                    $inputs['time'] = $this->blog_model->get_postdate();
                    $post_id = $this->blog_model->write_post($inputs);
                    if ($this->blog->followers != '[]' && $inputs['status'] == 'publish')
                    {
                        $this->notifications_model->insert(array(
                            'users_id' => $this->blog->followers,
                            'users_read' => '["0"]',
                            'type' => 'fl_new_post',
                            'code' => $post_id,
                            'val1' => $this->blog->name,
                            'val2' => $inputs['title'],
                            'val3' => $this->blog->url . '/' . $inputs['link'] . '.html',
                            'link' => $this->blog->url . '/login.html?redirect_uri=' . urlencode($this->
                                blog->url . '/' . $inputs['link'] . '.html'),
                            'time' => time(),
                            ));
                    }
                    redirect($redirect);
                }
            }
        }
        $data['blog_files'] = get_blog_files($this->blog->id);
        $this->load->helper('form');
        $this->load->view('includes/header', array('head_meta' => (!$this->agent->
                is_mobile() ? $head_meta : '')));
        $this->load->view('posts/add_new', $data);
        $this->load->view('includes/footer');
    }

    public function publish_post($id)
    {
        if (!$id)
        {
            return $this->display_error(lang('iwb_error_400'));
        }
        $query = $this->db->where(array(
            'id' => $id,
            'site_id' => $this->blog->id,
            'type' => 'post',
            ))->get('blog_posts');
        if ($query->num_rows() == 0)
        {
            return $this->display_error(lang('panel_post_not_found'));
            return;
        }
        $this->db->where('id', $id)->update('blog_posts', array('status' => 'publish'));
        $this->session->set_flashdata('alert-success', lang('panel_post_published'));
        redirect($this->input->get('redirect_uri') != null ? esc_html(urldecode($this->
            input->get('redirect_uri', true))) : 'posts/');
    }

    public function detail($id)
    {
        $this->config->set_item('page_title', lang('panel_post_detail'));
        if (!$id)
        {
            return $this->display_error(lang('iwb_error_400'));
        }
        $query = $this->db->where(array(
            'id' => $id,
            'site_id' => $this->blog->id,
            'type' => 'post',
            ))->get('blog_posts');
        if ($query->num_rows() == 0)
        {
            $post = false;
        }
        else
        {
            $post = $query->row();
        }
        $this->breadcrumbs->set(lang('panel_posts'), 'posts');
        $this->breadcrumbs->set($post != false ? esc_html($post->title) : lang('panel_post_detail'));

        $data = array();
        $data['blog'] = $this->blog;
        $data['post'] = $post;
        $data['categories'] = array();
        $categories = $this->blog_model->get_category($this->blog->id);
        if ($categories != null)
        {
            foreach ($categories as $category)
            {
                $data['categories'][$category->link] = $category->name;
            }
        }
        $this->load->view('includes/header');
        $this->load->view('posts/detail', $data);
        $this->load->view('includes/footer');
    }

    public function edit($id)
    {
        if (!$id)
        {
            return $this->display_error(lang('iwb_error_400'));
        }
        $query = $this->db->where(array(
            'id' => $id,
            'site_id' => $this->blog->id,
            'type' => 'post',
            ))->get('blog_posts');
        if ($query->num_rows() == 0)
        {
            return $this->display_error(lang('panel_post_not_found'));
            return;
        }

        $data = array();
        $data['blog'] = $this->blog;
        $data['post'] = $query->row();
        $data['postdate'] = $this->blog_model->form_postdate($data['post']->time);
        $head_meta = '<link rel="stylesheet" href="' . base_url('/assets/editor/tinyeditor.css') .
            '" /><script type="text/javascript" src="' . base_url('/assets/editor/tinyeditor.js') .
            '"></script>';
        $data['categories'] = array();

        $categories = $this->blog_model->get_category($this->blog->id);
        if ($categories != null)
        {
            foreach ($categories as $category)
            {
                $data['categories'][$category->link] = $category->name;
            }
        }

        if ($this->input->post())
        {
            $this->load->library('form_validation');

            $inputs = array(
                'title' => trim($this->input->post('title')),
                'content' => trim($this->input->post('content')),
                'p_categories' => $this->input->post('p_categories') != null ? $this->input->
                    post('p_categories') : array(),
                'tags' => trim($this->input->post('tags')),
                'visibility' => $this->input->post('visibility'),
                'time' => $this->blog_model->get_postdate($data['post']->time),
                );
            if ($this->input->post('insert_file') != 'none')
            {
                $file_add = $this->input->post('insert_file', true);
                $exp = @explode('.', $file_add, 2);
                $ext = @$exp[1];
                if (in_array('.' . $ext, image_types()))
                {
                    $inputs['content'] = $inputs['content'] . "\r\n<img src=\"" . $this->blog->url .
                        "/files/" . esc_html($file_add) . "\" />";
                }
                else
                {
                    $inputs['content'] = $inputs['content'] . "\r\n<a href=\"" . $this->blog->url .
                        "/files/" . esc_html($file_add) . "\">" . esc_html($file_add) . "</a>";
                }
            }
            $this->form_validation->set_data($inputs);
            $inputs['categories'] = '[]';
            $rules = array();
            $rules[] = array(
                'field' => 'title',
                'label' => lang('panel_title'),
                'rules' => 'required|min_length[2]|max_length[100]',
                );
            $rules[] = array(
                'field' => 'content',
                'label' => lang('panel_content'),
                'rules' => 'required|min_length[2]',
                );
            $rules[] = array(
                'field' => 'p_categories',
                'label' => lang('panel_category'),
                'rules' => array(array('category_callable', function ($str)use ($data, &$inputs)
                        {
                            if (count($data['categories']) > 0 && count($inputs['p_categories']) > 0)
                            {
                                foreach ($inputs['p_categories'] as $inp_cat)
                                {
                                    if (!array_key_exists($inp_cat, $data['categories']))
                                    {
                                        $this->form_validation->set_message('category_callable', lang('panel_err_category'));
                                            return false; }
                                }
                                $inputs['categories'] = json_encode($inputs['p_categories']); }
                        }
                        )),
                );
            $rules[] = array(
                'field' => 'tags',
                'label' => lang('panel_tags'),
                'rules' => 'min_length[2]|max_length[100]',
                );
            $rules[] = array(
                'field' => 'visibility',
                'label' => lang('panel_visibility'),
                'rules' => 'required|in_list[public,friends,followers]',
                );

            $this->form_validation->set_rules($rules);

            if ($this->form_validation->run() != false)
            {
                if ($this->input->post('insert_file') == 'none')
                {
                    $post_categories = json_decode($data['post']->categories);
                    $remove_category = array_diff($post_categories, $inputs['p_categories']);
                    if ($remove_category)
                    {
                        $this->db->query("UPDATE `" . $this->db->dbprefix .
                            "blog_categories` SET `total_posts` = `total_posts` - 1 WHERE `site_id` = '" . $this->
                            blog->id . "' AND `link` IN ('" . implode("','", $remove_category) . "')");
                    }
                    $add_category = array_diff($inputs['p_categories'], $post_categories);
                    if ($add_category)
                    {
                        $this->db->query("UPDATE `" . $this->db->dbprefix .
                            "blog_categories` SET `total_posts` = `total_posts` + 1 WHERE `site_id` = '" . $this->
                            blog->id . "' AND `link` IN ('" . implode("','", $add_category) . "')");
                    }
                    $inputs['tags'] = json_encode(str_tags($inputs['tags']));
                    unset($inputs['p_categories']);
                    if ($inputs['time'] > time())
                    {
                        $this->session->set_flashdata('alert-success', lang('panel_post_upd_draft'));
                        $inputs['status'] = 'draft';
                        $redirect = 'posts';
                    }
                    elseif ($this->input->post('draft'))
                    {
                        $this->session->set_flashdata('alert-success', lang('panel_post_upd_draft'));
                        $inputs['status'] = 'draft';
                        $redirect = 'posts';
                    }
                    elseif ($this->input->post('preview'))
                    {
                        $inputs['status'] = 'draft';
                        $redirect = $this->blog->url . '/login.html?redirect_uri=' . urlencode($this->
                            blog->url . '/' . $data['post']->link . '.html');
                    }
                    elseif ($this->input->post('publish'))
                    {
                        $this->session->set_flashdata('alert-success', lang('panel_post_upd_published'));
                        $inputs['status'] = 'publish';
                        $redirect = 'posts';
                    }
                    if ($this->iwb->get_setting('allow_js') == 'no')
                    {
                        $this->load->helper('htmlpurifier');
                        $inputs['content'] = html_purify($inputs['content'], 'post');
                    }
                    $this->db->where('id', $data['post']->id)->update('blog_posts', $inputs);
                    redirect($redirect);
                }
            }
        }
        $this->load->helper('form');
        $this->breadcrumbs->set(lang('panel_posts'), 'posts');
        $this->breadcrumbs->set(lang('iwb_edit'));
        $data['blog_files'] = get_blog_files($this->blog->id);

        $this->load->view('includes/header', array('head_meta' => (!$this->agent->
                is_mobile() ? $head_meta : '')));
        $this->load->view('posts/edit', $data);
        $this->load->view('includes/footer');
    }

    public function delete($id = 0)
    {
        $id = abs(intval($id));
        if (!$id)
        {
            return $this->display_error(lang('iwb_error_400'));
        }
        $query = $this->db->where(array(
            'id' => $id,
            'site_id' => $this->blog->id,
            'type' => 'post',
            ))->get('blog_posts');
        if ($query->num_rows() == 0)
        {
            return $this->display_error(lang('panel_post_not_found'));
        }
        else
        {
            $post = $query->row();
        }
        if ($this->input->post() || $this->session->has_userdata('skip_confirm'))
        {
            $this->get_skip_confirm();

            $this->db->where(array('id' => $id, 'site_id' => $this->blog->id))->delete('blog_posts');
            $this->db->where(array('site_id' => $this->blog->id, 'post_id' => $id))->delete('blog_comments');
            $this->db->query("DELETE FROM `" . $this->db->dbprefix . "notifications` 
                WHERE (`type` = 'blog_comments_published' 
                OR `type` = 'blog_comments_moderated' 
                OR `type` = 'blog_comments_spam' 
                OR `type` = 'fl_new_post') 
                AND `code` = '{$id}'");
            if ($post->categories != '[]')
            {
                $this->db->query("UPDATE `" . $this->db->dbprefix .
                    "blog_categories` SET `total_posts` = `total_posts` - 1 WHERE `site_id` = '" . $this->
                    blog->id . "' AND `link` IN ('" . implode("','", json_decode($post->categories)) .
                    "')");
            }
            $this->session->set_flashdata('alert-success', lang('panel_post_deleted'));
            redirect('posts');
        }
        $this->breadcrumbs->set(lang('panel_posts'), 'posts', true);
        $this->breadcrumbs->set(lang('iwb_delete'));
        return $this->confirm(current_url(), lang('panel_post_del_conf'), false, $this->
            set_skip_confirm());
    }
}
