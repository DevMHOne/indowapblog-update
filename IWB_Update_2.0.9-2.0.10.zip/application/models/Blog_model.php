<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

class Blog_model extends CI_Model
{
    protected $data = array();

    public function __construct()
    {
        parent::__construct();
    }

    public function authorization()
    {
        $blog_id = abs(intval($this->session->userdata('blog')));
        $query = $this->db->get_where('blog_sites', array(
            'id' => $blog_id,
            'user_id' => $this->iwb->user->id,
            'mod_reg' => 'no',
            'block' => 'no',
            ));
        if ($query->num_rows() == 0)
        {
            $this->session->unset_userdata('blog');
            return false;
        }
        $this->config->set_item('panel_blog_mode', 1);
        return $query->row();
    }

    public function rules($action)
    {
        $rules = array(
            'create' => array(
                array(
                    'field' => 'subdomain',
                    'label' => lang('iwb_subdomain'),
                    'rules' => array(
                        'required',
                        'min_length[4]',
                        'max_length[16]',
                        'alpha_dash',
                        array(
                            'subdomain',
                            array($this->blog_model, 'check_subdomain'),
                            ),
                        ),
                    ),
                array(
                    'field' => 'domain',
                    'label' => lang('iwb_domain'),
                    'rules' => 'required|in_list[' . implode(',', $this->data['domains']) . ']',
                    ),
                ),
            'edit' => array(),
            );

        if ($action != false && isset($rules[$action]))
        {
            return $rules[$action];
        }
        else
        {
            return $rules;
        }
    }

    public function validate_category($input, $categories)
    {
        foreach ($input as $inp_cat)
        {
            if (!array_key_exists($inp_cat, $categories))
            {
                return false;
            }
        }
        return true;
    }

    public function write_post($data)
    {
        $default = array(
            'title' => '',
            'content' => '',
            'categories' => '[]',
            'tags' => '[]',
            'link' => '',
            'visibility' => 'public',
            'friend_views' => '[]',
            'comments_subscribe' => '["' . $data['user_id'] . '"]',
            'status' => 'publish',
            'type' => 'post',
            'time' => time(),
            );
        $insert_data = array_merge($default, $data);
        if ($insert_data['categories'] != '[]')
        {
            $this->db->query("UPDATE `" . $this->db->dbprefix .
                "blog_categories` SET `total_posts` = `total_posts` + 1 WHERE `site_id` = '" . $insert_data['site_id'] .
                "' AND `link` IN ('" . implode("','", json_decode($insert_data['categories'])) .
                "')");
        }
        if ($insert_data['type'] == 'post')
        {
            $this->db->where('id', $insert_data['site_id'])->update('blog_sites', array('last_post' =>
                    time()));
        }
        $this->db->insert('blog_posts', $insert_data);
        return $this->db->insert_id();
    }
    public function read_navigation($site_id, $theme)
    {
        if (file_exists(FCPATH . 'files/blogs/' . $site_id . '/data/' . $theme .
            '-navigation.dat'))
        {
            return json_decode(gzinflate(file_get_contents(FCPATH . 'files/blogs/' . $site_id .
                '/data/' . $theme . '-navigation.dat')));
        }
        return array();
    }

    public function insert_navigation($site_id, $theme, $nav)
    {
        $data = $this->read_navigation($site_id, $theme);
        array_push($data, $nav);
        if (file_put_contents(FCPATH . 'files/blogs/' . $site_id . '/data/' . $theme .
            '-navigation.dat', gzdeflate(json_encode($data), 9)))
        {
            return true;
        }
        return false;
    }
    public function save_navigation($blog_id, $theme, $code)
    {
        if (file_put_contents(FCPATH . 'files/blogs/' . $blog_id . '/data/' . $theme .
            '-navigation.dat', gzdeflate($code, 9)))
        {
            return true;
        }
        return false;
    }

    public function get_permalink($site_id, $str, $type)
    {
        $link = str_link($str);
        $total_link = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->db->
            dbprefix . "blog_posts` WHERE `site_id` = ? AND `link` = ? AND `type` = ?",
            array(
            $site_id,
            $link,
            $type,
            ))->row()->num;
        if ($total_link > 0)
        {
            $link = $link . '-' . time();
        }
        return $link;
    }

    public function get_category($site_id, $cat_id = false)
    {
        if ($cat_id != false)
        {
            $this->db->where('id', $cat_id);
        }
        $this->db->where('site_id', $site_id);
        $query = $this->db->get('blog_categories');
        if ($query->num_rows() == 0)
            return null;
        return $query->result();
    }

    public function check_subdomain($subdomain)
    {
        $this->data['subdomain'] = $subdomain;
        if (in_array($subdomain, json_decode($this->iwb->get_setting('subdomain_disallow'))) ||
            substr($subdomain, 0, 1) == '-' || substr($subdomain, 0, 1) == '_' || substr($subdomain,
            -1) == '-' || substr($subdomain, -1) == '_')
        {
            $this->form_validation->set_message('subdomain', lang('account_cb_sd_not_allow'));
            return false;
        }
        $query = $this->db->get_where('blog_sites', array('subdomain' => $subdomain,
                'domain' => $this->data['domain']));
        if ($query->num_rows() != 0)
        {
            $this->form_validation->set_message('subdomain', lang('account_cb_sd_already_reg'));
            return false;
        }
        return true;
    }

    public function create_blog($data)
    {
        $default = array(
            // 'id' => '',
            'user_id' => '',
            'name' => 'No Name',
            'subdomain' => '',
            'domain' => '',
            'settings' => '[]',
            'followers' => '[]',
            'followers_total' => 0,
            'category' => '',
            'hits_today' => 0,
            'hits_today_date' => '',
            'hits_total' => 0,
            'modules' => '[]',
            'mod_reg' => 'no',
            'block' => 'no',
            'editor_choice' => 0,
            'last_post' => 0,
            'rating' => 0,
            'ratings' => 0,
            'votes' => '[]',
            'created' => time(),
            );
        $data_insert = array_merge($default, $data);
        $this->db->insert('blog_sites', $data_insert);
    }

    public function set_data($key, $value = '')
    {
        if (is_array($key))
        {
            $this->data = array_merge($this->data, $key);
        }
        elseif (is_object($key))
        {
            $this->data = array_merge($this->data, (array )$key);
        }
        else
        {
            $this->data[$key] = $value;
        }
    }

    public function get_data($key = false)
    {
        if ($key == false)
        {
            return $this->data;
        }
        elseif (array_key_exists($key, $this->data))
        {
            return $this->data[$key];
        }
        return false;
    }

    public function validate_postdate($str)
    {
        $date = strtotime($str);
        return $date;
    }

    public function form_postdate($default = 0)
    {
        $this->lang->load('calendar');
        $timestamp = $default == 0 ? time() : $default;
        $time = $timestamp + (3600 * timezones($this->iwb->user_set['time_zone']));
        $out = '';
        $out .= '<input type="hidden" name="current_date" value="' . $time .
            '" style="display:none"/>';
        $out .= '<div class="select-group">';
        $out .= '<select class="form-control auto-width" name="dd">';
        for ($i = 1; $i <= 31; $i++)
        {
            $dd = (strlen($i) == 1 ? '0' . $i : $i);
            $out .= '<option value="' . $dd . '"' . $this->postdate_select('dd', $dd, date('d',
                $time)) . '>' . $dd . '</option>';
        }
        $out .= '</select>';
        $out .= '<select class="form-control auto-width" name="mm">';
        $months = array(
            lang('cal_jan'),
            lang('cal_feb'),
            lang('cal_mar'),
            lang('cal_apr'),
            lang('cal_may'),
            lang('cal_jun'),
            lang('cal_jul'),
            lang('cal_aug'),
            lang('cal_sep'),
            lang('cal_oct'),
            lang('cal_nov'),
            lang('cal_dec'),
            );
        foreach ($months as $month)
        {
            $out .= '<option value="' . $month . '" ' . $this->postdate_select('mm', $month,
                date('M', $time)) . '>' . $month . '</option>';
        }
        $out .= '</select>';
        $out .= '<select class="form-control auto-width" name="yy">';
        $year = date('Y', time());
        $default_year = $default == 0 ? $year : date('Y', $time);
        for ($i = 1; $i <= 2; $i++)
        {
            $out .= '<option value="' . (($year + $i) - 1) . '" ' . $this->postdate_select('yy',
                (($year + $i) - 1), $default_year) . '>' . (($year + $i) - 1) . '</option>';
        }
        $out .= '</select>';
        $out .= '<select class="form-control auto-width" name="hh">';
        for ($i = 0; $i <= 23; $i++)
        {
            $hh = (strlen($i) == 1 ? '0' . $i : $i);
            $out .= '<option value="' . $hh . '" ' . $this->postdate_select('hh', $hh, date
                ('H', $time)) . '>' . $hh . '</option>';
        }
        $out .= '</select>';
        $out .= '<select class="form-control auto-width" name="ii">';
        for ($i = 0; $i <= 59; $i++)
        {
            $ii = (strlen($i) == 1 ? '0' . $i : $i);
            $out .= '<option value="' . $ii . '" ' . $this->postdate_select('ii', $ii, date
                ('i', $time)) . '>' . $ii . '</option>';
        }
        $out .= '</select>';
        $out .= '<input type="hidden" name="ss" value="00" style="display:none"/>';
        $out .= '</div>';
        return $out;
    }

    private function postdate_select($field, $value, $default)
    {
        if ($this->input->post($field) == null)
        {
            if ($value == $default)
            {
                return ' selected="selected"';
            }
        }
        if ($this->input->post($field) == $value)
        {
            return ' selected="selected"';
        }
        return '';
    }

    public function get_postdate($default = 0)
    {
        $timestamp = $default == 0 ? time() : $default;
        $str = $this->input->post('dd', true) . '-' . $this->input->post('mm', true) .
            '-' . $this->input->post('yy', true) . ' ' . $this->input->post('hh', true) .
            ':' . $this->input->post('ii', true) . ':' . $this->input->post('ss', true);
        $time = strtotime($str);
        if ($time === false)
        {
            return $timestamp;
        }
        $time -= 3600 * timezones($this->iwb->user_set['time_zone']);
        if ($time < time())
        {
            return time();
        }
        return $time;
    }
}
