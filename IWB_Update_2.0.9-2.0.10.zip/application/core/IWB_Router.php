<?php

class IWB_Router extends CI_Router
{
    public function __construct()
    {
        parent::__construct();
        $this->proccess_request();
    }

    private function proccess_request()
    {
        $parse_domain = parse_url(strtolower($this->config->item('base_url')));
        $main_domain = 'www.' . preg_replace('#^www\.(.+\.)#i', '$1', $parse_domain['host']);
        $this->config->set_item('base_url', $parse_domain['scheme'] . '://' . $main_domain .
            @$parse_domain['path']);
        $this->config->set_item('domain', $main_domain);

        $server_name = strtolower($_SERVER['SERVER_NAME']);
        $this->config->set_item('server_name', $server_name);
        if (substr($main_domain, 4) == $server_name)
        {
            header("HTTP/1.1 301 Moved Permanently");
            header('Location: ' . $this->config->item('base_url'));
            exit();
        }
        elseif ($server_name != $main_domain && substr($server_name, 0, 4) == 'www.')
        {
            header("HTTP/1.1 301 Moved Permanently");
            header('Location: http://' . substr($server_name, 4) . htmlentities($_SERVER['REQUEST_URI']));
            exit();
        }
        elseif ($server_name != $main_domain && $this->fetch_class() != 'captcha')
        {
            $this->set_class('blog');
        }
    }
}
