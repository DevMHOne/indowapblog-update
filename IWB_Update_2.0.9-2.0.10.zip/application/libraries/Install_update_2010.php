<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Install_update_2010
{
    protected $CI;
    protected $version = '2.0.10';

    public function __construct()
    {
        $this->CI = &get_instance();
    }

    public function install($auto = false)
    {
        $this->set_update_history();
        $this->CI->db->where('set_key', 'iwb_version')->update('settings', array('set_value' =>
                $this->version));

        @$this->CI->db->query("ALTER TABLE `" . $this->CI->db->dbprefix .
            "users` ADD `password_hash` VARCHAR(64) NOT NULL DEFAULT '' AFTER `password`");
        @$this->CI->db->query("INSERT INTO `" . $this->CI->db->dbprefix .
            "settings` (`id`, `set_key`, `set_value`, `autoload`) VALUES " .
            "(NULL, 'iwb_ads', '{\"top\":\"\",\"bottom\":\"\"}', 'no'), " .
            "(NULL, 'allow_js', 'no', 'no'), (NULL, 'credit_withdraw_methods', '{\"Pulsa\":{\"status\":\"inactive\",\"vouchers\":{\"6000\":\"5K\",\"11000\":\"10K\",\"50000\":\"50K\",\"99000\":\"100K\"},\"info\":\"Kesalahan memasukan nomor handphone bukan tanggung jawab Kami.\"},\"Bank Transfer\":{\"status\":\"inactive\",\"min\":50000,\"max\":1000000,\"info\":\"\"},\"Paypal\":{\"status\":\"inactive\",\"min\":50000,\"max\":1000000,\"rate\":12000,\"info\":\"\"}}', 'no');");
        $this->CI->db->query("CREATE TABLE IF NOT EXISTS `" . $this->CI->db->dbprefix .
            "credit_withdraw` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `trx_id` varchar(16) NOT NULL DEFAULT '',
  `type` varchar(32) NOT NULL,
  `credit` int(10) NOT NULL,
  `payment` varchar(32) NOT NULL,
  `detail` text NOT NULL,
  `status` enum('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
  `reason` TEXT NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");
        @unlink(APPPATH . 'views/desktop/admin/credit/top_up_info.php');
        @unlink(APPPATH . 'views/mobile/admin/credit/top_up_info.php');
        @unlink(APPPATH . 'views/desktop/account/credit/withdraw.php');
        @unlink(APPPATH . 'views/mobile/account/credit/withdraw.php');

        unlink(__file__);
        if (!$auto)
        {
            $this->CI->session->set_flashdata('alert-success',
                'Installasi pembaruan IndoWapBlog v' . $this->version .
                ' berhasil diselesaikan.');
            redirect('admin/indowapblog');
        }
    }

    protected function set_update_history()
    {
        $query = $this->CI->db->query("SELECT * FROM `" . $this->CI->db->dbprefix .
            "update` WHERE `version` = '{$this->version}' LIMIT 1");
        if ($query->num_rows() == 0)
        {
            $this->CI->db->insert('update', array(
                'version' => $this->version,
                'updated' => '0000-00-00 00:00:00',
                'file' => '',
                'changelog' => '',
                'message' => '',
                'installed' => date_sql(time()),
                ));
        }
    }
}
