<div class="well well-sm">
Terima kasih sudah menggunakan IndoWapBlog. Saat ini kamu sedang menggunakan IndoWapBlog v<?=$this->iwb->set['iwb_version']?>. 
<a href="<?=site_url('admin/indowapblog/check_for_update')?>">Periksa pembaruan &raquo;&raquo;</a>
</div>
<div class="list-group">
  <div class="list-group-item list-group-item-default">
    <h3>
      Blog
    </h3>
  </div>
  <a class="list-group-item" href="<?=site_url('admin/blog/all')?>">All <span class="badge">(<?=$total[0]['total']?>)</span></a>
  <a class="list-group-item" href="<?=site_url('admin/blog/moderated')?>">Moderated <span class="badge">(<?=$total[1]['total']?>)</span></a>
  <a class="list-group-item" href="<?=site_url('admin/blog/blocked')?>">Blocked <span class="badge">(<?=$total[2]['total']?>)</span></a>
</div>
<div class="list-group">
  <div class="list-group-item list-group-item-default">
    <h3>
      Settings
    </h3>
  </div>
  <a class="list-group-item" href="<?=site_url('admin/settings/general')?>">General</a>
  <a class="list-group-item" href="<?=site_url('admin/settings/blog')?>">Blog</a>
  <a class="list-group-item" href="<?=site_url('admin/settings/ads')?>">Periklanan</a>
</div>
<div class="list-group">
  <div class="list-group-item list-group-item-default">
    <h3>
      Modules
    </h3>
  </div>
  <a class="list-group-item" href="<?=site_url('admin/credit')?>"><?=lang('iwb_credit')?></a>
</div>
<div class="list-group">
  <div class="list-group-item list-group-item-default">
    <h3>
      IndoWapBlog
    </h3>
  </div>
  <a class="list-group-item" href="<?=site_url('admin/indowapblog/update_settings')?>">Pengaturan Pembaruan</a>
  <a class="list-group-item" href="<?=site_url('admin/indowapblog/check_for_update')?>">Periksa Pembaruan</a>
  <a class="list-group-item" href="<?=site_url('admin/indowapblog/install_update')?>">Install Pembaruan</a>
  <a class="list-group-item" href="<?=site_url('admin/indowapblog/update_history')?>">Riwayat Pembaruan</a>
</div>