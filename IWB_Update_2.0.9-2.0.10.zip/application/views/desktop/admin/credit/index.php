<div class="row">
<div class="<?=($histories ? 'col-sm-4' : 'col-sm-12')?>">
<div class="list-group">
  <div class="list-group-item list-group-item-default">
    <h3>
      Menu
    </h3>
  </div>
  <a class="list-group-item" href="<?=site_url('admin/credit/top_up')?>">Isi Ulang / Kirim Kredit</a>
  <a class="list-group-item" href="<?=site_url('admin/credit/withdraw')?>">Riwayat Penarikan</a>
</div>
<div class="list-group">
  <div class="list-group-item list-group-item-default">
    <h3>
      Pengaturan Kredit
    </h3>
  </div>
  <a class="list-group-item" href="<?=site_url('admin/credit/settings/top_up')?>">Isi Ulang</a>
  <a class="list-group-item" href="<?=site_url('admin/credit/settings/withdraw')?>">Penarikan</a>
</div>
</div>
<div class="col-sm-8">
<?php if ($histories):?>
<div class="list-group">
  <div class="list-group-item list-group-item-default">
    <h3>Penarikan Menunggu Konfirmasi</h3>
  </div>
  <?php foreach ($histories as $wd):?>
  <div class="list-group-item"><?=$wd->type?> <?=$wd->payment?> (<?=format_date(strtotime($wd->date))?>) <span class="pull-right"><?=strtr($wd->status,array('pending'=>'Menunggu','accepted'=>'Dikonfirmasi','rejected'=>'Ditolak'))?></span></div>
  <?php endforeach?>
  <div class="list-group-item list-group-item-footer text-right"><a href="<?=site_url('admin/credit/withdraw')?>">Lihat semua &raquo;</a></div>
</div>
<?php endif?>
</div>
</div>