<?php if (validation_errors() != null): ?>
<div class="alert alert-danger">
  <strong>
    <?= lang('iwb_error') ?>
    !
  </strong>
  <ol class="list-unstyled">
    <?= validation_errors('<li>', '</li>') ?>
  </ol>
</div>
<?php endif ?>
<?= form_open(current_url()) ?>
  <div class="form-group">
    <label for="username">
      <?=lang('iwb_username')?>
    </label>
    <input class="form-control" type="text" name="username" id="username" maxlength="16" value="<?=set_value('username') ?>" required="required"/>
  </div>
  <div class="form-group">
    <label for="credit">
      <?=lang('iwb_credit')?>
    </label>
    <input class="form-control" type="number" name="credit" id="credit" maxlength="10" value="<?=set_value('credit') ?>" required="required"/>
  </div>
  <div class="form-group">
    <label for="message">
      Pesan
    </label>
    <textarea class="form-control" name="message" id="message" rows="4" maxlength="160"><?=set_value('message') ?></textarea>
    <p class="help-block">Opsional, maksimal 160 karakter.</p>
  </div>
  <p>
    <button class="btn btn-primary" type="submit">
      Submit
    </button>
  </p>
<?=form_close()?>