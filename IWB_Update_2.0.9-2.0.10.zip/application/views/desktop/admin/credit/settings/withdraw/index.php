<?= form_open(current_url()) ?>
  <div class="form-group">
    <label>Metode Penarikan</label>
    <div class="checkbox">
        <label>
            <input type="checkbox" name="pulsa" value="1"<?=($wd_methods['Pulsa']['status'] == 'active' ? ' checked="checked"' : '')?>/>
            <span>Pulsa</span>
        </label>
        <span class="margin-left">
            <a href="<?=site_url('admin/credit/settings/withdraw?method=Pulsa')?>"><i class="fa fa-pencil"></i></a>
        </span>
    </div>
    <div class="checkbox">
        <label>
            <input type="checkbox" name="bank_transfer" value="1"<?=($wd_methods['Bank Transfer']['status'] == 'active' ? ' checked="checked"' : '')?>/>
            <span>Bank Transfer</span>
        </label>
        <span class="margin-left">
            <a href="<?=site_url('admin/credit/settings/withdraw?method=Bank+Transfer')?>"><i class="fa fa-pencil"></i></a>
        </span>
    </div>
    <div class="checkbox">
        <label>
            <input type="checkbox" name="paypal" value="1"<?=($wd_methods['Paypal']['status'] == 'active' ? ' checked="checked"' : '')?>/>
            <span>Paypal</span>
        </label>
        <span class="margin-left">
            <a href="<?=site_url('admin/credit/settings/withdraw?method=Paypal')?>"><i class="fa fa-pencil"></i></a>
        </span>
    </div>
  </div>
  <p>
    <button class="btn btn-primary" type="submit" name="save" value="1">
      <?=lang('iwb_save')?>
    </button>
  </p>
</form>
