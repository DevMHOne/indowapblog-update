<?php if (validation_errors() != null): ?>
<div class="alert alert-danger">
  <strong>
    <?= lang('iwb_error') ?>
    !
  </strong>
  <ol class="list-unstyled">
    <?= validation_errors('<li>', '</li>') ?>
  </ol>
</div>
<?php endif ?>
<?= form_open('admin/credit/settings/withdraw?method=Bank+Transfer') ?>
    <div class="form-group">
        <label for="min-credit">Minimal Penarikan</label>
        <input type="number" class="form-control" name="min_credit" id="min-credit" value="<?=set_value('min_credit',$wd_bank['min'])?>" maxlength="7"/>
    </div>
    <div class="form-group">
        <label for="max-credit">Maksimal Penarikan</label>
        <input type="number" class="form-control" name="max_credit" id="max-credit" value="<?=set_value('max_credit',$wd_bank['max'])?>" maxlength="7"/>
    </div>
    <div class="form-group">
        <label for="msg-info">Pesan Informasi</label>
        <textarea class="form-control" name="msg_info" id="msg-info" maxlength="160" rows="4"><?=set_value('msg_info',$wd_bank['info'])?></textarea>
        <p class="help-block">Maksimal 160 karakter.</p>
    </div>
    <p>
        <button class="btn btn-primary" type="submit"><?=lang('iwb_save')?></button>
    </p>
<?=form_close()?>