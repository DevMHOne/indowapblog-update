<div class="list-group">
  <div class="list-group-item list-group-item-default">
    <strong>
      Pengaturan Kredit
    </strong>
  </div>
  <a class="list-group-item" href="<?=site_url('admin/credit/settings/top_up')?>">Isi Ulang</a>
  <a class="list-group-item" href="<?=site_url('admin/credit/settings/withdraw')?>">Penarikan</a>
</div>