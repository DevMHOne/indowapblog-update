<div class="menu-bar">
  <ul>
    <li class="<?=($status == 'pending' ? 'active' : '')?>">
      <a href="<?=site_url('admin/credit/withdraw?status=pending')?>">Menunggu</a>
    </li>
    <li class="<?=($status == 'accepted' ? 'active' : '')?>">
      <a href="<?=site_url('admin/credit/withdraw?status=accepted')?>">Dikonfirmasi</a>
    </li>
    <li class="<?=($status == 'rejected' ? 'active' : '')?>">
      <a href="<?=site_url('admin/credit/withdraw?status=rejected')?>">Ditolak</a>
    </li>
  </ul>
</div>
<?php if ($total == 0):?>
<div class="alert alert-info">
  Tidak ada data penarikan kredit
</div>
<?php else:?>
<ul class="list-unstyled">
  <?php foreach ($histories as $wd):?>
  <li>
    <ul class="list-group">
      <li class="list-group-item list-group-item-default">
        <a href="<?=site_url('user/'.$wd->username)?>">
        <h3>
        <i class="fa fa-user"></i> <?=esc_html($wd->name)?>
        </h3>
        </a>
      </li>
      <li class="list-group-item">
        ID penarikan : <?=$wd->id?>
      </li>
      <li class="list-group-item">
        Metode penarikan : <?=$wd->type?>
      </li>
      <li class="list-group-item">
        Kredit yang ditarik : Rp. <?=number_format($wd->credit,2,',','.')?>
      </li>
      <li class="list-group-item">
        Jumlah pembayaran : <?=$wd->payment?>
      </li>
      <li class="list-group-item">
        Status : <?=strtr($wd->status,array('pending'=>'Menunggu','accepted'=>'Dikonfirmasi','rejected'=>'Ditolak'))?>
      </li>
      <?php if ($wd->status == 'rejected'):?>
      <li class="list-group-item">
        Alasan penolakan : <?=esc_html($wd->reason)?>
      </li>
      <?php endif?>
      <li class="list-group-item">
        Rincian : <?php
        $detail = json_decode($wd->detail, true);
        if ($wd->type == 'Pulsa') {
            echo '<ul><li>Operator: '.$detail['operator'].'</li>' .
            '<li>Nomor HP: '.esc_html($detail['nomor_hp']).'</li></ul>';
        }elseif ($wd->type == 'Bank Transfer') {
            echo '<ul><li>Nama Bank: '.esc_html($detail['bank_name']).'</li>' .
            '<li>Nama Pada Rekening: '.esc_html($detail['account_name']).'</li>' .
            '<li>Nomor Rekening: '.esc_html($detail['account_number']).'</li></ul>';
        }
        elseif ($wd->type == 'Paypal') {
            echo '<ul><li>Email: '.esc_html($detail['email']).'</li></ul>';
        }
        ?>
      </li>
      <li class="list-group-item">
        Tanggal penarikan : <?=format_date(strtotime($wd->date))?>
      </li>
      <?php if ($wd->status == 'pending'):?>
      <li class="list-group-item list-group-item-footer text-right">
        <a class="btn btn-default btn-sm" href="<?=site_url('admin/credit/withdraw?confirm='.$wd->id)?>"  data-toggle="modal" data-target="#iwb-modal">Konfirmasi</a>
        <a class="btn btn-danger btn-sm" href="<?=site_url('admin/credit/withdraw?reject='.$wd->id)?>" data-toggle="modal" data-target="#iwb-modal">Tolak</a>
        <div class="clear">
        </div>
      </li>
      <?php endif?>
    </ul>
  </li>
  <?php endforeach?>
</ul>
<?= pagination_link(site_url('admin/credit/withdraw') . '?page=',
sql_offset($this->iwb->user_set['offset'], $current_page), $total, $this->iwb->user_set['offset']) ?>
<?php endif?>