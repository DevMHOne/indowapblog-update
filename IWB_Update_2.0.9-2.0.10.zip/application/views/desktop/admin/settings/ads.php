<div class="alert alert-info">
    Iklan akan tampil di semua blog.
</div>
<?php if (validation_errors() != null):?>
<div class="alert alert-danger">
	<strong>
		<?=lang('iwb_error')?>!
	</strong>
	<ol class="list-unstyled">
		<?=validation_errors( '<li>', '</li>')?>
	</ol>
</div>
<?php endif?>
<?=form_open()?>
  <div class="form-group">
    <label for="top_ads">
      Top Ads
    </label>
    <textarea class="form-control" name="top_ads" id="top_ads" rows="4"><?=set_value('top_ads',$ads['top'])?></textarea>
  </div>
  <div class="form-group">
    <label for="bottom_ads">
      Bottom Ads
    </label>
    <textarea class="form-control" name="bottom_ads" id="bottom_ads" rows="4"><?=set_value('bottom_ads',$ads['bottom'])?></textarea>
  </div>
  <p>
  <button class="btn btn-primary" type="submit" name="submit">Save</button>
  </p>
<?=form_close()?>