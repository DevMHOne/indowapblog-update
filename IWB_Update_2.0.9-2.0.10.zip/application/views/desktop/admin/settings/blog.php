<?php if (validation_errors() != null):?>
<div class="alert alert-danger">
	<strong>
		<?=lang('iwb_error')?>!
	</strong>
	<ol class="list-unstyled">
		<?=validation_errors( '<li>', '</li>')?>
	</ol>
</div>
<?php endif?>
<?=form_open()?>
  <div class="form-group">
    <label for="domains">
      Domains
    </label>
    <input type="text" class="form-control" name="domains" id="domains" value="<?=set_value('domains',implode(',',json_decode($set['domains'])))?>"/>
    <p class="help-block">
      Without www and separated by commas. Eg: domain1.com,domain2.com
    </p>
  </div>
  <div class="form-group">
    <label for="max_user_blogs">
      Maximum number of blogs per user
    </label>
    <input type="number" class="form-control" name="max_user_blogs" id="max_user_blogs" value="<?=set_value('max_user_blogs',$set['max_user_blogs'])?>"/>
  </div>
  <div class="form-group">
    <label for="diff_time_blog">
      Different time to create new blog
    </label>
    <input type="number" class="form-control auto-width" name="diff_time_blog" id="diff_time_blog" value="<?=set_value('diff_time_blog',$set['diff_time_blog'])?>"/>
    <p class="help-block">
      In hour.
    </p>
  </div>
  <div class="form-group">
    <label for="mod_new_blog">
      Moderation new blog
    </label>
    <?=form_dropdown('mod_new_blog',array('yes'=>lang('iwb_yes'),'no'=>lang('iwb_no')),$set['mod_new_blog'],'class="form-control" id="mod_new_blog"')?>
  </div>
  <div class="form-group">
    <label for="subdomain_disallow">
      Subdomains Disallow
    </label>
    <input type="text" class="form-control" name="subdomain_disallow" id="subdomain_disallow" value="<?=set_value('subdomain_disallow',implode(',',json_decode($set['subdomain_disallow'])))?>"/>
    <p class="help-block">
      Separated by commas. Eg: google,facebook
    </p>
  </div>
  <div class="form-group">
    <label for="blog_categories">
      Blog Categories
    </label>
    <input type="text" class="form-control" name="blog_categories" id="blog_categories" value="<?=set_value('blog_categories',implode(',',json_decode($set['blog_categories'])))?>"/>
    <p class="help-block">
      Separated by commas.
    </p>
  </div>
  <div class="form-group">
    <label for="allow_js">
      Allow to use Javascript
    </label>
    <?=form_dropdown('allow_js',array('yes'=>lang('iwb_yes'),'no'=>lang('iwb_no')),$set['allow_js'],'class="form-control" id="allow_js"')?>
    <p class="help-block">
      This permit does not apply for existing posts.
    </p>
  </div>
  <div class="form-group">
    <label for="upload_file_types">
      Upload Filetypes
    </label>
    <input type="text" class="form-control" name="upload_file_types" id="upload_file_types" value="<?=set_value('upload_file_types',implode(',',json_decode($set['upload_file_types'])))?>"/>
    <p class="help-block">
      Separated by commas.
    </p>
  </div>
  <div class="form-group">
    <label for="upload_file_size">
      Upload Filesize
    </label>
    <input type="number" class="form-control auto-width" name="upload_file_size" id="upload_file_size" value="<?=set_value('upload_file_size',$set['upload_file_size'])?>"/>
    <p class="help-block">
      In KB.
    </p>
  </div>
  <p>
  <button class="btn btn-primary" type="submit" name="submit">Save</button>
  </p>
<?=form_close()?>