<div class="well well-sm">
    Jumlah kredit kamu saat ini adalah Rp. <?=number_format($this->iwb->user->credit,2,',','.')?>.
    <?=($methods['Bank Transfer']['info']) ? '<br/>Info: '.nl2br(esc_html($methods['Bank Transfer']['info'])) : ''?>
</div>
<?php if (validation_errors() != null): ?>
<div class="alert alert-danger">
  <strong>
    <?= lang('iwb_error') ?>
    !
  </strong>
  <ol class="list-unstyled">
    <?= validation_errors('<li>', '</li>') ?>
  </ol>
</div>
<?php endif ?>
<?= form_open('account/credit/withdraw?method=Bank+Transfer') ?>
    <div class="form-group">
        <label for="credit">Kredit</label>
        <input class="form-control" type="number" name="credit" id="credit" value="<?=set_value('credit')?>" maxlength="<?=strlen($methods['Bank Transfer']['max'])?>"/>
        <p class="help-block">Minimal <?=$methods['Bank Transfer']['min']?>, maksimal <?=$methods['Bank Transfer']['max']?>.</p>
    </div>
    <div class="form-group">
        <label for="bank_name">Nama Bank</label>
        <input class="form-control" type="text" name="bank_name" id="bank_name" value="<?=set_value('bank_name')?>"/>
        <p class="help-block">Contoh: Mandiri</p>
    </div>
    <div class="form-group">
        <label for="account_name">Nama Pada Rekening</label>
        <input class="form-control" type="text" name="account_name" id="account_name" maxlength="32" value="<?=set_value('account_name')?>"/>
    </div>
    <div class="form-group">
        <label for="account_number">Nomor Rekening</label>
        <input class="form-control" type="number" name="account_number" id="account_number" maxlength="32" value="<?=set_value('account_number')?>"/>
    </div>
    <p>
        <button class="btn btn-primary" type="submit">Submit</button>
    </p>
<?=form_close()?>