<div class="row">
<div class="<?=($history ? 'col-sm-4' : 'col-sm-12')?>">
<div class="list-group">
  <div class="list-group-item list-group-item-default">
    <h3>Metode Penarikan</h3>
  </div>
  <?php foreach($methods as $wd_type=>$wd_value):?>
  <?php if ($wd_value['status'] == 'active'):?>
  <a class="list-group-item" href="<?=site_url('account/credit/withdraw?method='.urlencode($wd_type))?>"><?=esc_html($wd_type)?></a>
  <?php else:?>
  <div class="list-group-item"><?=esc_html($wd_type)?></div>
  <?php endif?>
  <?php endforeach?>
</div>
</div>
<div class="col-sm-8">
<?php if ($history):?>
<div class="list-group">
  <div class="list-group-item list-group-item-default">
    <h3>Riwayat Penarikan</h3>
  </div>
  <?php foreach ($history as $wd):?>
  <div class="list-group-item"><?=$wd->type?> <?=$wd->payment?> (<?=format_date(strtotime($wd->date))?>) <span class="pull-right"><?=strtr($wd->status,array('pending'=>'Menunggu','accepted'=>'Dikonfirmasi','rejected'=>'Ditolak'))?></span></div>
  <?php endforeach?>
  <div class="list-group-item list-group-item-footer text-right"><a href="<?=site_url('account/credit/withdraw/history')?>">Lihat semua &raquo;</a></div>
</div>
<?php endif?>
</div>
</div>