<div class="well well-sm">
    Jumlah kredit kamu saat ini adalah Rp. <?=number_format($this->iwb->user->credit,2,',','.')?>.
    Info: <?=($methods['Paypal']['info']) ? nl2br(esc_html($methods['Paypal']['info'])).'<br/>' : ''?>
    Kredit <?=$methods['Paypal']['rate']?> = $1 USD
</div>
<?php if (validation_errors() != null): ?>
<div class="alert alert-danger">
  <strong>
    <?= lang('iwb_error') ?>
    !
  </strong>
  <ol class="list-unstyled">
    <?= validation_errors('<li>', '</li>') ?>
  </ol>
</div>
<?php endif ?>
<?= form_open('account/credit/withdraw?method=Paypal') ?>
    <div class="form-group">
        <label for="credit">Kredit</label>
        <input class="form-control" type="number" name="credit" id="credit" value="<?=set_value('credit')?>" maxlength="<?=strlen($methods['Paypal']['max'])?>"/>
        <p class="help-block">Minimal <?=$methods['Paypal']['min']?>, maksimal <?=$methods['Paypal']['max']?>.</p>
    </div>
    <div class="form-group">
        <label for="email">Email Paypal</label>
        <input class="form-control" type="email" name="email" id="email" value="<?=set_value('email')?>"/>
    </div>
    <p>
        <button class="btn btn-primary" type="submit">Submit</button>
    </p>
<?=form_close()?>