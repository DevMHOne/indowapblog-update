<div class="well well-sm">
    Jumlah kredit kamu saat ini adalah Rp. <?=number_format($this->iwb->user->credit,2,',','.')?>.
    <?=($methods['Pulsa']['info']) ? '<br/>Info: '.nl2br(esc_html($methods['Pulsa']['info'])) : ''?>
</div>
<?php if (validation_errors() != null): ?>
<div class="alert alert-danger">
  <strong>
    <?= lang('iwb_error') ?>
    !
  </strong>
  <ol class="list-unstyled">
    <?= validation_errors('<li>', '</li>') ?>
  </ol>
</div>
<?php endif ?>
<?= form_open('account/credit/withdraw?method=Pulsa') ?>
    <div class="form-group">
        <label>Pilihan Jumlah</label>
        <?php foreach($methods['Pulsa']['vouchers'] as $v_credit=>$v_pulsa):?>
        <div class="radio">
            <label>
                <input type="radio" name="voucher" value="<?=$v_credit?>"/> <span><?=lang('iwb_credit')?> Rp. <?=number_format($v_credit,2,',','.')?> = Pulsa <?=esc_html($v_pulsa)?></span>
            </label>
        </div>
        <?php endforeach?>
    </div>
    <div class="form-group">
        <label for="operator">Operator</label>
        <?=form_dropdown('operator',$operator,false,'class="form-control" id="operator"')?>
    </div>
    <div class="form-group">
        <label for="nomor_hp">Nomor Handphone</label>
        <input class="form-control" type="text" name="nomor_hp" id="nomor_hp" maxlength="16" value="<?=set_value('nomor_hp')?>"/>
    </div>
    <p>
        <button class="btn btn-primary" type="submit">Submit</button>
    </p>
<?=form_close()?>