<?php if ($total == 0):?>
<div class="alert alert-info">
  Tidak ada data penarikan kredit.
</div>
<?php else:?>
<ul class="list-unstyled">
  <?php foreach ($histories as $wd):?>
  <li>
    <ul class="list-group">
      <li class="list-group-item list-group-item-default">
        <h3>
        <?=format_date(strtotime($wd->date))?>
        </h3>
      </li>
      <li class="list-group-item">
        ID penarikan : <?=$wd->id?>
      </li>
      <li class="list-group-item">
        Metode penarikan : <?=$wd->type?>
      </li>
      <li class="list-group-item">
        Kredit yang ditarik : Rp. <?=number_format($wd->credit,2,',','.')?>
      </li>
      <li class="list-group-item">
        Jumlah pembayaran : <?=$wd->payment?>
      </li>
      <li class="list-group-item">
        Status : <?=strtr($wd->status,array('pending'=>'Menunggu','accepted'=>'Dikonfirmasi','rejected'=>'Ditolak'))?>
      </li>
      <?php if ($wd->status == 'rejected'):?>
      <li class="list-group-item">
        Alasan penolakan : <?=esc_html($wd->reason)?>
      </li>
      <?php endif?>
      <li class="list-group-item">
        Rincian : <?php
        $detail = json_decode($wd->detail, true);
        if ($wd->type == 'Pulsa') {
            echo '<ul><li>Operator: '.$detail['operator'].'</li>' .
            '<li>Nomor HP: '.esc_html($detail['nomor_hp']).'</li></ul>';
        }
        elseif ($wd->type == 'Bank Transfer') {
            echo '<ul><li>Nama Bank: '.esc_html($detail['bank_name']).'</li>' .
            '<li>Nama Pada Rekening: '.esc_html($detail['account_name']).'</li>' .
            '<li>Nomor Rekening: '.esc_html($detail['account_number']).'</li></ul>';
        }
        elseif ($wd->type == 'Paypal') {
            echo '<ul><li>Email: '.esc_html($detail['email']).'</li></ul>';
        }
        ?>
      </li>
    </ul>
  </li>
  <?php endforeach?>
</ul>
<?= pagination_link(site_url('account/credit/withdraw/history') . '?page=',
sql_offset($this->iwb->user_set['offset'], $current_page), $total, $this->iwb->user_set['offset']) ?>
<?php endif?>