<?php if (validation_errors() != null): ?>
<div class="alert alert-danger">
  <strong>
    <?= lang('iwb_error') ?>
    !
  </strong>
  <ol class="list-unstyled">
    <?= validation_errors('<li>', '</li>') ?>
  </ol>
</div>
<?php endif ?>
<?= form_open(current_url()) ?>
  <div class="form-group">
    <label for="credit_top_up_info">
      Informasi isi ulang
    </label>
    <textarea class="form-control" name="credit_top_up_info" id="credit_top_up_info" rows="16"><?=trim(set_value('credit_top_up_info',$credit_top_up_info)) ?></textarea>
  </div>
  <p>
    <button class="btn btn-primary" type="submit">
      <?=lang('iwb_save')?>
    </button>
  </p>
</form>