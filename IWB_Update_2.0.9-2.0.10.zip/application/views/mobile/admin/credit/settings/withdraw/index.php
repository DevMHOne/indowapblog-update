<?= form_open(current_url()) ?>
  <div class="form-group">
    <label>Metode Penarikan</label>
    <div class="checkbox">
        <label>
            <input type="checkbox" name="pulsa" value="1"<?=($wd_methods['Pulsa']['status'] == 'active' ? ' checked="checked"' : '')?>/>
            <span>Pulsa</span>
			<span class="margin-left">
            <a href="<?=site_url('admin/credit/settings/withdraw?method=Pulsa')?>">Edit</a>
			</span>
        </label>
    </div>
    <div class="checkbox">
        <label>
            <input type="checkbox" name="bank_transfer" value="1"<?=($wd_methods['Bank Transfer']['status'] == 'active' ? ' checked="checked"' : '')?>/>
            <span>Bank Transfer</span>
			<span class="margin-left">
            <a href="<?=site_url('admin/credit/settings/withdraw?method=Bank+Transfer')?>">Edit</a>
			</span>
        </label>
    </div>
    <div class="checkbox">
        <label>
            <input type="checkbox" name="paypal" value="1"<?=($wd_methods['Paypal']['status'] == 'active' ? ' checked="checked"' : '')?>/>
            <span>Paypal</span>
			<span class="margin-left">
            <a href="<?=site_url('admin/credit/settings/withdraw?method=Paypal')?>">Edit</a>
			</span>
        </label>
    </div>
  </div>
  <p>
    <button class="btn btn-primary" type="submit" name="save" value="1">
      <?=lang('iwb_save')?>
    </button>
  </p>
</form>
