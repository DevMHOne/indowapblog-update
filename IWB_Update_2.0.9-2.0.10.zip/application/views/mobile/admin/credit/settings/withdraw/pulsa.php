<?php if (validation_errors() != null): ?>
<div class="alert alert-danger">
  <strong>
    <?= lang('iwb_error') ?>
    !
  </strong>
  <ol class="list-unstyled">
    <?= validation_errors('<li>', '</li>') ?>
  </ol>
</div>
<?php endif ?>
<?= form_open('admin/credit/settings/withdraw?method=Pulsa') ?>
  <table class="table table-bordered">
    <thead>
      <tr><th>Kredit</th><th>Pulsa</th><th style="width: 80px;" class="text-center">&nbsp;</th></tr>
    </thead>
    <tbody>
      <?php foreach($vouchers as $v_credit=>$v_nominal):?>
      <tr>
        <td><?=$v_credit?></td>
        <td><?=$v_nominal?></td>
        <td class="text-center">
            <a href="<?=site_url('admin/credit/settings/withdraw?method=Pulsa&amp;delete='.$v_credit)?>">Hapus</a>
        </td>
      </tr>
      <?php endforeach?>
      <tr>
        <td><input class="form-control" name="new[Credit]" id="new-credit" value="<?=set_value('new[Credit]')?>"/></td>
        <td><input class="form-control" name="new[Pulsa]" id="new-pulsa" value="<?=set_value('new[Pulsa]')?>"/></td>
        <td><button class="btn btn-primary btn-block" type="submit" name="save_new_credit" value="1"><?=lang('iwb_save')?></button></td>
      </tr>
    </tbody>
  </table>
</form>
<?=form_close()?>
<div class="alert alert-info">
<?= form_open('admin/credit/settings/withdraw?method=Pulsa') ?>
    <div class="form-group">
        <label for="msg_info">Pesan Informasi</label>
        <textarea class="form-control" name="msg_info" id="msg_info" rows="4" maxlength="160"><?=set_value('msg_info',$msg_info)?></textarea>
        <p class="help-block">Maksimal 160 karakter.</p>
    </div>
    <p>
        <button class="btn btn-primary" type="submit" name="save_msg_info" value="1"><?=lang('iwb_save')?></button>
    </p>
<?=form_close()?>
</div>