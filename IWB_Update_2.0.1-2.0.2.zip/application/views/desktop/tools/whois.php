<div class="margin-bottom">
  <form method="get" action="<?=site_url('tools/whois')?>">
    <div class="input-group">
      <input class="form-control" name="blog" placeholder="example.domain.com" value="<?=esc_html($domain)?>"/>
      <span class="input-group-btn">
        <button class="btn btn-primary" type="submit">
          WHOIS
        </button>
      </span>
    </div>
  </form>
</div>
<?php if ($result == true):?>
<?php if ($blog == null):?>
<div class="alert alert-warning">
  No result found.
</div>
<?php else:?>
<div class="alert alert-info">
  WHOIS for <strong><?=esc_html($domain)?></strong>.
</div>
<ul class="list-unstyled">
  <?php $blog_url = blog_url($blog);?>
  <li>
    <ul class="list-group">
      <li class="list-group-item list-group-item-default">
        <h3>
          <a href="<?=$blog_url?>"><?=esc_html($blog->name)?></a>
        </h3>
      </li>
      <li class="list-group-item">
        Author:
        <a href="<?=site_url('user/'.$blog->author_username)?>"><?=esc_html($blog->author_name)?></a>
      </li>
      <?php if ($blog->last_post != 0):?>
      <li class="list-group-item">
        Updated: <?=time_ago($blog->last_post)."\r\n"?>
      </li>
      <?php endif?>
      <li class="list-group-item">
        Description: <?=esc_html(get_blog_settings($blog->settings['description']))."\r\n"?>
      </li>
      <li class="list-group-item">
        Followers: <?=$blog->followers_total."\r\n"?>
      </li>
      <li class="list-group-item">
        Date of Registration: <?=format_date($blog->created)."\r\n"?>
      </li>
      <?php if ($this->iwb->is_user):?>
      <?php $followers = json_decode($blog->followers);?>
      <li class="list-group-item list-group-item-footer">
        <?php if ($this->iwb->user_id && $this->iwb->user->rights == 10):?>
        <span class="pull-left">
        <?php if ($blog->block =='no'):?>
        <a class="btn btn-default btn-sm" href="<?=site_url('admin/block_blog/'.$blog->id.'?redirect_uri='.urlencode(current_url().'?blog='.esc_html($domain)))?>">Block</a>
        <?php else:?>
        <a class="btn btn-default btn-sm" href="<?=site_url('admin/unblock_blog/'.$blog->id.'?redirect_uri='.urlencode(current_url().'?blog='.esc_html($domain)))?>">Unblock</a>
        <?php endif?>
        <a class="btn btn-default btn-sm" href="<?=site_url('admin/delete_blog/'.$blog->id.'?redirect_uri='.urlencode(current_url().'?blog='.esc_html($domain)))?>"><?=lang('iwb_delete')?></a>
        </span>
        <?php endif?>
        <?php if (strpos($blog->followers,'"'.$this->iwb->user_id.'"') !== false):?>
        <a class="btn btn-default btn-sm pull-right" href="<?=$blog_url?>/login.html?redirect_uri=<?=urlencode($blog_url.'/follow.html')?>">Follow</a>
        <?php else:?>
        <a class="btn btn-default btn-sm pull-right" href="<?=$blog_url?>/login.html?redirect_uri=<?=urlencode($blog_url.'/follow.html')?>">Unfollow</a>
        <?php endif?>
        <div class="clear"></div>
      </li>
      <?php endif?>
    </ul>
  </li>
</ul>
<?php endif?>
<?php endif?>