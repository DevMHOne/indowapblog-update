<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class IWB_Controller extends CI_Controller
{
    /**
     * IWB_Controller::__construct()
     * 
     * @return
     */
    public function __construct()
    {
        parent::__construct();
        $default_language = $this->config->item('language');
        if ($this->session->has_userdata('lang'))
        {
            $lng = $this->session->userdata('lang');
        }
        else
        {
            $lng = $default_language;
        }
        if ($default_language != $lng && in_array($lng, $this->config->item('languages')))
        {
            $this->config->set_item('language', $lng);
        }
        $this->iwb_update_check();

        $this->load->library('breadcrumbs');
        $this->load->model('notifications_model');
        $this->lang->load('iwb');
        if ($this->iwb->is_user)
        {
            $this->user_notifications();
        }
    }

    /**
     * IWB_Controller::user_notifications()
     * 
     * @return
     */
    private function user_notifications()
    {
        $pr = $this->db->dbprefix;
        $id = $this->iwb->user->id;
        $query = $this->db->query("
            (SELECT COUNT(*) AS `total` FROM `{$pr}msg_reply` WHERE `user_unread` LIKE '%\"{$id}\"%')
            ");
        $result = $query->result_array();
        $this->iwb->user->alert['new_messages'] = $result[0]['total'];
        $this->iwb->user->alert['notifications'] = $this->notifications_model->
            get_total_notifications();
    }

    /**
     * IWB_Controller::get_redirect()
     * 
     * @param mixed $default
     * @return
     */
    protected function get_redirect($default)
    {
        if ($this->input->get('redirect_uri') != null)
        {
            $redirect = urldecode($this->input->get('redirect_uri', true));
            return $redirect;
        }
        return $default;
    }

    /**
     * IWB_Controller::get_skip_confirm()
     * 
     * @return
     */
    protected function get_skip_confirm()
    {
        if ($this->input->post('skip_confirm'))
        {
            $this->session->set_userdata('skip_confirm', 1);
        }
    }

    /**
     * IWB_Controller::reset_skip_confirm()
     * 
     * @return
     */
    protected function reset_skip_confirm()
    {
        if ($this->session->has_userdata('skip_confirm'))
        {
            $this->session->unset_userdata('skip_confirm');
        }
    }
    /**
     * IWB_Controller::set_skip_confirm()
     * 
     * @return
     */
    protected function set_skip_confirm()
    {
        $out = '<div class="checkbox"><label><input type="checkbox" name="skip_confirm" value="1"/>' .
            ' <span>' . lang('iwb_dont_ask_again') . '</span></label></div>';
        return $out;
    }

    /**
     * IWB_Controller::confirm()
     * 
     * @param mixed $post_url
     * @param mixed $notice
     * @param bool $cancel_url
     * @param string $addon
     * @return
     */
    protected function confirm($post_url, $notice, $cancel_url = false, $addon = '')
    {
        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('includes/confirm', array(
            'post_url' => $post_url,
            'notice' => $notice,
            'addon' => $addon,
            'cancel_url' => $cancel_url,
            ));
        $this->load->view('includes/footer');
    }

    /**
     * IWB_Controller::display_error()
     * 
     * @param string $message
     * @return
     */
    protected function display_error($message = 'Error!')
    {
        $this->load->view('includes/header');
        $this->load->view('includes/display_error', array('message' => $message));
        $this->load->view('includes/footer');
        return;
    }

    protected function iwb_update_check()
    {
        $update = json_decode($this->iwb->set['iwb_update'], true);
        if (($update['set'] == 'everytime' && ((time() - 3600) > (int)$update['last_check'])) ||
            ($update['set'] == 'daily' && ((time() - 3600 * 24) > (int)$update['last_check'])) ||
            ($update['set'] == 'weekly' && ((time() - 3600 * 24 * 7) > (int)$update['last_check'])) ||
            ($update['set'] == 'monthly' && ((time() - 3600 * 24 * 30) > (int)$update['last_check'])))
        {
            $this->iwb_update_run();
            $update['last_check'] = time();
            $this->db->where('set_key', 'iwb_update')->update('settings', array('set_value' =>
                    json_encode($update)));
        }
    }

    protected function iwb_update_run()
    {
        if ($update = @file_get_contents($this->iwb->set['iwb_update_url'] . (strpos($this->
            iwb->set['iwb_update_url'], '?') !== false ? '&' : '?') . 'site=' . strtolower($_SERVER['SERVER_NAME']) .
            '&license=' . $this->config->item('iwb_license') . '&v=' . $this->iwb->set['iwb_version']))
        {
            $iwb = json_decode($update, true);
            if (array_key_exists($this->iwb->set['iwb_version'], $iwb))
            {
                $name = url_title($iwb[$this->iwb->set['iwb_version']]['version'], '_', true);
                $filename = 'update-' . $name . '.zip';
                if (copy($iwb[$this->iwb->set['iwb_version']]['file'], FCPATH . 'files/tmp/' . $filename))
                {
                    $zip = new ZipArchive;
                    if ($zip->open(FCPATH . 'files/tmp/' . $filename) === true)
                    {
                        $zip->extractTo(FCPATH);
                        $zip->close();
                        unlink(FCPATH . 'files/tmp/' . $filename);
                        $lname = 'Install_update_' . $name;
                        $library = strtolower($lname);

                        $this->db->insert('update', array(
                            'version' => $iwb[$this->iwb->set['iwb_version']]['version'],
                            'updated' => $iwb[$this->iwb->set['iwb_version']]['updated'],
                            'file' => $iwb[$this->iwb->set['iwb_version']]['file'],
                            'changelog' => json_encode($iwb[$this->iwb->set['iwb_version']]['changelog']),
                            'message' => $iwb[$this->iwb->set['iwb_version']]['message'],
                            'installed' => date_sql(time()),
                            ));
                        $ver = "";
                        $ver .= @file_get_contents(FCPATH . 'VERSION.md');
                        $ver .= "\r\n\r\n------------------------------------------------------\r\n\r\n";
                        $ver .= "# IndoWapBlog v" . $iwb[$this->iwb->set['iwb_version']]['version'];
                        $ver .= "\r\n\r\n";
                        $ver .= "Release: " . $iwb[$this->iwb->set['iwb_version']]['updated'] . " UTC";
                        $ver .= "\r\n\r\n";
                        $ver .= "Changelog:";
                        $ver .= "\r\n\r\n";
                        foreach ($iwb[$this->iwb->set['iwb_version']]['changelog'] as $ch)
                        {
                            $ver .= "* " . $ch . "\r\n";
                        }
                        @file_put_contents(FCPATH . 'VERSION.md', trim($ver));

                        $this->load->library($library);
                        $this->$library->install(true);
                    }
                }

            }
        }
    }
}
