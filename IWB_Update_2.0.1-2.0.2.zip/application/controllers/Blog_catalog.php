<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Blog_catalog extends IWB_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->lang->load('catalog');
    }

    public function index()
    {
        $data = array();
        $blog_categories = array_merge(json_decode($this->iwb->get_setting('blog_categories')),
            array('Uncategorized'));
        $q = $params = array();
        foreach ($blog_categories as $c)
        {
            $q[] = "(SELECT COUNT(*) AS `total` FROM `" . $this->db->dbprefix .
                "blog_sites` WHERE " . ($c == 'Uncategorized' ?
                '(`category` = ? OR `category` = \'\')' : '`category` = ?') . ")";
            $params[] = $c;
        }
        $query = $this->db->query(implode(' UNION ALL ', $q), $params);

        $categories = array_combine($blog_categories, $query->result_array());
        $data['blog_categories'] = array();
        foreach ($categories as $ckey => $cval)
        {
            $data['blog_categories'][$ckey] = $cval['total'];
        }
        arsort($data['blog_categories']);

        $this->breadcrumbs->set(lang('catalog_blog_catalog'), '', true);
        $this->load->view('includes/header');
        $this->load->view('blog_catalog/index', $data);
        $this->load->view('includes/footer');
    }

    public function posts($option = 'recent')
    {
        if (!in_array($option, array(
            'recent',
            'top_comments',
            'last_commented',
            )))
        {
            redirect('blog_catalog/posts');
        }
        $data = array();
        $data['option'] = $option;
        $search = $this->input->get('search', true);
        if ($search == null || strlen($search) > 12 || strlen($search) < 4)
        {
            $data['search'] = false;
        }
        else
        {
            $data['search'] = $search;
        }
        $filter = $order = "";
        $this->breadcrumbs->set(lang('catalog_blog_catalog'), 'blog_catalog');
        if ($option == 'top_comments')
        {
            $filter = " AND `p`.`total_comments` != 0";
            $order = "`p`.`total_comments` DESC";
        }
        elseif ($option == 'last_commented')
        {
            $filter = " AND `p`.`last_comment` != 0";
            $order = "`p`.`last_comment` DESC";
        }
        else
        {
            if ($data['search'])
            {
                $filter = " AND `p`.`title` LIKE '%" . $this->db->escape_like_str($data['search']) .
                    "%'";
            }
            $order = "`p`.`time` DESC";
        }
        $this->breadcrumbs->set(lang('catalog_recent_posts'), '', true);
        $page = abs(intval($this->input->get('page')));
        $data['current_page'] = $page < 1 ? 1 : $page;

        $data['total'] = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . $this->
            db->dbprefix . "blog_posts` AS `p` WHERE `p`.`status` = 'publish' AND `p`.`type` = 'post'" .
            $filter)->row()->total;
        if ($data['total'])
        {
            $query = $this->db->query("SELECT `p`.*,`p`.`id` AS `post_id`, `s`.*, `u`.`name` AS `author_name`, `u`.`username` AS `author_username` FROM `" .
                $this->db->dbprefix . "blog_posts` AS `p` LEFT JOIN `" . $this->db->dbprefix .
                "blog_sites` AS `s` ON `p`.`site_id` = `s`.`id` LEFT JOIN `" . $this->db->
                dbprefix . "users` AS `u` ON `p`.`user_id` = `u`.`id` WHERE `p`.`status` = 'publish'  AND `p`.`type` = 'post'" .
                $filter . " ORDER BY " . $order . " LIMIT " . sql_offset($this->iwb->user_set['offset'],
                $data['current_page']) . ", " . $this->iwb->user_set['offset']);
            $data['posts'] = $query->result();
        }
        $this->load->view('includes/header');
        $this->load->view('blog_catalog/posts', $data);
        $this->load->view('includes/footer');
    }

    public function category($name = null)
    {
        if ($name == null)
        {
            return $this->display_error(lang('iwb_error_400'));
        }
        $data = array();
        $data['sort'] = $sort = $this->input->get('sort');
        $page = abs(intval($this->input->get('page')));
        $data['current_page'] = $page < 1 ? 1 : $page;
        $data['blog_categories'] = array_merge(json_decode($this->iwb->get_setting('blog_categories')),
            array('Uncategorized'));
        $categories = array();
        foreach ($data['blog_categories'] as $category)
        {
            $categories[str_link($category)] = $category;
        }
        if (!array_key_exists($name, $categories))
        {
            return $this->display_error(lang('catalog_cat_not_found'));
        }
        if ($name == 'uncategorized')
        {
            $where = "(`b`.`category` = ? OR `b`.`category` = '')";
        }
        else
        {
            $where = "`b`.`category` = ?";
        }
        if ($sort == 'visits')
        {
            $order = "`b`.`hits_today`";
        }
        else
        {
            $data['sort'] = 'new';
            $order = "`b`.`created`";
        }
        $data['total_blogs'] = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . $this->
            db->dbprefix . "blog_sites` AS `b` WHERE " . $where .
            " AND `b`.`mod_reg` = 'no' AND `b`.`block` = 'no'", array($categories[$name]))->
            row()->total;
        if ($data['total_blogs'])
        {
            $query = $this->db->query("SELECT `b`.*, `u`.`name` AS `author_name`, `u`.`username` AS " .
                "`author_username` FROM `" . $this->db->dbprefix .
                "blog_sites` AS `b` LEFT JOIN `" . $this->db->dbprefix .
                "users` AS `u` ON `u`.`id` = `b`.`user_id` WHERE " . $where .
                " AND `b`.`mod_reg` = 'no' AND `b`.`block` = 'no' ORDER BY " . $order .
                " DESC LIMIT " . sql_offset($this->iwb->user_set['offset'], $data['current_page']) .
                ", " . $this->iwb->user_set['offset'], array($categories[$name]));
            $data['blogs'] = $query->result();
        }
        $this->breadcrumbs->set(lang('catalog_blog_catalog'), 'blog_catalog', true);
        $this->breadcrumbs->set(lang('catalog_category') . ': ' . esc_html($categories[$name]));

        $this->load->view('includes/header');
        $this->load->view('blog_catalog/category', $data);
        $this->load->view('includes/footer');
    }

    public function quick_browse($sort = null)
    {
        $conditions = array(
            "editor_choice" => array(
                "AND `b`.`editor_choice` = '1'",
                "`b`.`editor_choice`",
                ),
            "recently_updated" => array(
                "AND `b`.`last_post` != '0'",
                "`b`.`last_post`",
                ),
            "top_followers" => array(
                "AND `b`.`followers_total` != '0'",
                "`b`.`followers_total`",
                ),
            "top_rated" => array(
                "AND `b`.`rating` != '0'",
                "`b`.`rating`",
                ),
            "random_pick" => array(
                "",
                "RAND()",
                ),
            );
        if (!in_array($sort, array_keys($conditions)))
        {
            return $this->display_error(lang('iwb_error_400'));
        }
        $data = array();
        $page = abs(intval($this->input->get('page')));
        $data['current_page'] = $page < 1 ? 1 : $page;

        $data['total_blogs'] = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . $this->
            db->dbprefix . "blog_sites` AS `b` WHERE `b`.`mod_reg` = 'no' AND `b`.`block` = 'no' " .
            $conditions[$sort][0])->row()->total;
        if ($data['total_blogs'])
        {
            $query = $this->db->query("SELECT `b`.*, `u`.`name` AS `author_name`, `u`.`username` AS " .
                "`author_username` FROM `" . $this->db->dbprefix .
                "blog_sites` AS `b` LEFT JOIN `" . $this->db->dbprefix .
                "users` AS `u` ON `u`.`id` = `b`.`user_id` WHERE `b`.`mod_reg` = 'no' " .
                "AND `b`.`block` = 'no' " . $conditions[$sort][0] . " ORDER BY " . $conditions[$sort][1] .
                " DESC LIMIT " . sql_offset($this->iwb->user_set['offset'], $data['current_page']) .
                ", " . $this->iwb->user_set['offset']);
            $data['blogs'] = $query->result();
        }
        $this->breadcrumbs->set(lang('catalog_blog_catalog'), 'blog_catalog', true);
        $this->breadcrumbs->set(lang('catalog_quick_browse') . ': ' . lang('catalog_' .
            $sort));

        $this->load->view('includes/header');
        $this->load->view('blog_catalog/quick_browse', $data);
        $this->load->view('includes/footer');
    }

    public function whois()
    {
        $data = array();
        $data['result'] = false;
        $domain = strtolower($this->input->get('blog'));
        $data['domain'] = $domain;
        $exp = explode('.', $domain, 2);
        if (count($exp) == 2)
        {
            $data['result'] = true;
            $this->db->select('b.*,u.username as author_username,u.name as author_name');
            $this->db->from('blog_sites AS b');
            $this->db->join('users as u', 'u.id = b.user_id');
            $this->db->where(array('b.subdomain' => $exp[0], 'b.domain' => $exp[1]));
            $this->db->limit(1);
            $data['blog'] = $this->db->get()->row();
        }
        $this->breadcrumbs->set(lang('catalog_blog_catalog'), 'blog_catalog');
        $this->breadcrumbs->set(lang('catalog_whois'), '', true);

        $this->load->view('includes/header');
        $this->load->view('blog_catalog/whois', $data);
        $this->load->view('includes/footer');
    }
}
