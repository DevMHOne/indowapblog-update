# IndoWapBlog v1.0.0

Release: 2011-03-14 00:00:00 UTC

-----------------------------------------------------

# IndoWapBlog v2.0.0

Release: 2016-06-22 00:00:00 UTC

Changelog:

* Menggunakan CodeIgniter dan Bootstrap Template

-----------------------------------------------------

# IndoWapBlog v2.0.1

Release: 2015-06-23 16:55:58 UTC

Changelog:

* Perbaikan bugs

-----------------------------------------------------

# IndoWapBlog v2.0.2

Release: 2015-06-23 19:25:30 UTC

Changelog:

* Perbaikan bugs