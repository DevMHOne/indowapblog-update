<div class="list-group">
  <div class="list-group-item list-group-item-default">
    <strong>
      <?=lang('iwb_credit')?>
    </strong>
  </div>
  <a class="list-group-item" href="<?=site_url('admin/credit/top_up_info')?>">Informasi isi ulang</a>
</div>