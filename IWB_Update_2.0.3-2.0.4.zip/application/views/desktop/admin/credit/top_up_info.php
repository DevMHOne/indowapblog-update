<?php if (validation_errors() != null): ?>
<div class="alert alert-danger">
  <strong>
    <?= lang('iwb_error') ?>
    !
  </strong>
  <ol class="list-unstyled">
    <?= validation_errors('<li>', '</li>') ?>
  </ol>
</div>
<?php endif ?>
<?= form_open(current_url(), 'onsubmit="tinyeditor.post()"') ?>
  <div class="form-group">
    <label for="credit_top_up_info">
      Informasi isi ulang
    </label>
    <textarea class="form-control" name="credit_top_up_info" id="credit_top_up_info" rows="16"><?=trim(set_value('credit_top_up_info',$credit_top_up_info)) ?></textarea>
  </div>
  <p>
    <button class="btn btn-primary" type="submit">
      <?=lang('iwb_save')?>
    </button>
  </p>
</form>
<script type="text/javascript">
  tinyeditor = new TINY.editor.edit('editor', {
    id: 'credit_top_up_info',
    width: '100%',
    height: 275,
    cssclass: 'te',
    controlclass: 'tecontrol',
    rowclass: 'teheader',
    dividerclass: 'tedivider',
    controls: ['bold', 'italic', 'underline', 'strikethrough', '|', 'subscript', 'superscript', '|', 'orderedlist', 'unorderedlist', '|', 'outdent', 'indent', '|', 'leftalign', 'centeralign', 'rightalign', 'blockjustify', '|', 'unformat', '|', 'undo', 'redo', 'n', 'font', 'size', 'style', '|', 'hr', '|', 'image', 'link', 'unlink', ],
    footer: true,
    fonts: ['Times New Roman', 'Verdana', 'Arial', 'Georgia', 'Courier New', 'Trebuchet MS', 'Comic Sans MS'],
    xhtml: true,
    bodyid: 'editor',
    footerclass: 'tefooter',
    toggle: {
      text: 'Code',
      activetext: 'Preview',
      cssclass: 'toggle'
    },
    resize: {
      cssclass: 'resize'
    }
  });
</script>