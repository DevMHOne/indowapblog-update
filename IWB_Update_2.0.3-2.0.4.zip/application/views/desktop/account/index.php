<div class="row margin-bottom">
  <div class="col-sm-4">
    <a href="<?= site_url('account/create_blog') ?>" class="btn btn-primary" data-toggle="modal" data-target="#iwb-modal"><?=lang('account_create_blog')?></a>
  </div>
  <div class="col-sm-8">
    <!--<?= form_open('account') . "\r\n" ?>
    <div class="input-group">
      <input class="form-control" type="text" name="status" placeholder="<?=lang('account_status_placeholder')?>" value="<?= esc_html($this->iwb->user->status) ?>" maxlength="60"/>
      <span class="input-group-btn">
        <button class="btn btn-primary" type="submit">
          <?=lang('account_upd_status_btn')?>
        </button>
      </span>
    </div>
    <?= form_close() . "\r\n" ?>-->
  </div>
</div>
<?php if ($total_blogs == 0): ?>
<div class="alert alert-warning">
  <?=lang('account_blog_empty')?>
</div>
<?php else: ?>
<ul class="list-group">
  <li class="list-group-item list-group-item-default">
    <strong>
      <a href="<?= site_url('account/blog') ?>"><?=lang('iwb_blog')?> <span class="pull-right">(<?=$total_blogs?>)</span></a>
    </strong>
  </li>
  <?php foreach ($blogs as $blog): ?>
  <li class="list-group-item">
    <?php if ($blog->mod_reg == 'yes' || $blog->block == 'yes'):?>
    <strong><?= esc_html($blog->name) ?></strong> <?= ($blog->mod_reg == 'yes' ? ' ('.lang('account_in_mod').')' : ' ('.lang('account_suspended').')') ?>
    <?php else:?>
    <a href="<?= blog_url($blog) ?>" target="_blank"><strong><?= esc_html($blog->name) ?></strong></a>
    <a class="pull-right" href="<?= site_url('account/switch_blog/' . $blog->id) ?>"><?=lang('account_switch_blog')?></a>
    <?php endif?>
  </li>
  <?php endforeach ?>
  <?php if ($total_blogs > $this->iwb->user_set['offset']): ?>
  <li class="list-group-item">
    <a href="<?= site_url('account/blog') ?>"><?=lang('account_more_blog')?></a>
  </li>
  <?php endif ?>
</ul>
<?php endif ?>
<div class="list-group">
  <div class="list-group-item list-group-item-default">
    <strong>
      <?=lang('account_friends')?>
    </strong>
  </div>
  <a href="<?= site_url('friends') ?>" class="list-group-item"><?=lang('account_friends')?> <span class="badge pull-right">(<?= count(json_decode
    ($this->iwb->user->friends)) ?>)</span></a>
  <a href="<?= site_url('friends/requests') ?>" class="list-group-item"><?=lang('account_friend_requests')?> <span class="badge pull-right">(<?= count(json_decode
        ($this->iwb->user->friend_requests)) ?>)</span></a>
  <a href="<?= site_url('friends/sent_requests') ?>" class="list-group-item"><?=lang('account_friend_sent_requests')?> <span class="badge pull-right">(<?= count(json_decode
        ($this->iwb->user->friend_sent_requests)) ?>)</span></a>
</div>
<div class="list-group">
  <div class="list-group-item list-group-item-default">
    <strong>
      <?=lang('account_data_account')?>
    </strong>
  </div>
  <a href="<?= site_url('user/' . $this->iwb->user->username) ?>" class="list-group-item"><?=lang('iwb_profile')?></a>
  <a href="<?= site_url('account/credit') ?>" class="list-group-item"><?=lang('iwb_credit')?></a>
  <a href="<?= site_url('account/edit') ?>" class="list-group-item"><?=lang('account_edit_account')?></a>
  <a href="<?= site_url('account/settings') ?>" class="list-group-item"><?=lang('iwb_settings')?></a>
  <a href="<?= site_url('account/edit/password') ?>" class="list-group-item"><?=lang('account_ch_password')?></a>
</div>
<div class="margin-top">
  <?php if ($this->iwb->user->rights == 10): ?>
  <a class="btn btn-default pull-left" href="<?= site_url('admin') ?>">
  <?=lang('account_adm_panel')?>
  </a>
  <?php endif ?>
  <a class="btn btn-warning pull-right" href="<?= site_url('site/logout') ?>" data-toggle="modal" data-target="#iwb-modal">
  <?=lang('iwb_logout')?>
  </a>
  <div class="clear">
  </div>
</div>