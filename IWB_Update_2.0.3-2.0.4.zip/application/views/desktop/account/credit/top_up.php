<div class="panel">
  <div class="panel-body">
    <?=$credit_top_up_info?>
  </div>
</div>