<div class="menu-bar">
<ul>
  <li class="<?=($show == 'all' ? 'active' : '')?>">
    <a href="<?=site_url('account/credit/history?show=')?>"><?=lang('account_crd_all')?></a>
  </li>
  <li class="<?=($show == 'in' ? 'active' : '')?>">
    <a href="<?=site_url('account/credit/history?show=in')?>"><?=lang('account_crd_in')?></a>
  </li>
  <li class="<?=($show == 'out' ? 'active' : '')?>">
    <a href="<?=site_url('account/credit/history?show=out')?>"><?=lang('account_crd_out')?></a>
  </li>
</ul>
</div>
<?php if ($total == 0):?>
<div class="alert alert-info">
  <?=lang('account_crd_no_history')?>
</div>
<?php else:?>
<div class="panel">
  <div class="table-responsive">
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>
            <?=lang('account_crd_date')?>
          </th>
          <th>
            <?=lang('account_crd_h_info')?>
          </th>
          <th>
            <?=lang('account_crd_in')?>
          </th>
          <th>
            <?=lang('account_crd_out')?>
          </th>
          <th>
            <?=lang('account_crd_msg')?>
          </th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($histories as $history):?>
        <tr>
          <td>
            <?=format_date(strtotime($history->date))?>
          </td>
          <td>
            <?=esc_html($history->info)?>
          </td>
          <td>
            <?=$history->credit_in != 0 ? number_format($history->credit_in,2,',','.') : 0 ?>
          </td>
          <td>
            <?=$history->credit_out != 0 ? number_format($history->credit_out,2,',','.') : 0 ?>
          </td>
          <td>
            <?=esc_html($history->message)?>
          </td>
        </tr>
        <?php endforeach?>
      </tbody>
    </table>
  </div>
</div>
<?= pagination_link(site_url('account/credit/history') . '?show='.$show.'&amp;page=',
sql_offset($this->iwb->user_set['offset'], $current_page), $total, $this->iwb->user_set['offset']) ?>
<?php endif?>