<div class="well well-sm">
  <?=strtr(lang('account_crd_info'),array('{CREDIT}'=>'Rp. '.number_format($this->iwb->user->credit,2,',','.')))?>
</div>
<div class="list-group">
  <a class="list-group-item" href="<?=site_url('account/credit/top_up')?>"><?=lang('account_crd_top_up')?></a>
  <a class="list-group-item" href="<?=site_url('account/credit/send')?>"><?=lang('account_crd_send')?></a>
  <a class="list-group-item" href="<?=site_url('account/credit/history')?>"><?=lang('account_crd_history')?></a>
  <a class="list-group-item" href="<?=site_url('account/credit/withdraw')?>"><?=lang('account_crd_withdraw')?></a>
</div>