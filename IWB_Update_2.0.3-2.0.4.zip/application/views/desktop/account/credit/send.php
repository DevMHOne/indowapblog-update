<?php if (validation_errors() != null): ?>
<div class="alert alert-danger">
  <strong>
    <?= lang('iwb_error') ?>
    !
  </strong>
  <ol class="list-unstyled">
    <?= validation_errors('<li>', '</li>') ?>
  </ol>
</div>
<?php endif ?>
<?= form_open(current_url()) ?>
  <div class="form-group">
    <label for="username">
      <?=lang('iwb_username')?>
    </label>
    <input class="form-control" type="text" name="username" id="username" maxlength="16" value="<?=set_value('username') ?>" required="required"/>
  </div>
  <div class="form-group">
    <label for="credit">
      <?=lang('iwb_credit')?>
    </label>
    <input class="form-control" type="number" name="credit" id="credit" maxlength="<?=strlen($this->iwb->user->credit)?>" value="<?=set_value('credit') ?>" required="required"/>
    <p class="help-block"><?=strtr(lang('account_crd_chlp'),array('{CREDIT}'=>'5000'))?></p>
  </div>
  <div class="form-group">
    <label for="message">
      <?=lang('account_crd_msg')?>
    </label>
    <textarea class="form-control" name="message" id="message" rows="4" maxlength="160"><?=set_value('message') ?></textarea>
    <p class="help-block"><?=lang('account_crd_mhlp')?></p>
  </div>
  <p>
    <button class="btn btn-primary" type="submit">
      <?=lang('account_crd_send_btn')?>
    </button>
  </p>
</form>