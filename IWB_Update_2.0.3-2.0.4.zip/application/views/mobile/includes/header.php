<?php $controller = strtolower($this->router->fetch_class());
$action = strtolower($this->router->fetch_method());
$default_data = render_data();
$head_title = $this->config->item('page_title') != null ? esc_html($this->config->item
    ('page_title')) . ' | ' . esc_html($this->iwb->set['site_name']) : $default_data['head_title'];
$head_description = isset($head_description) ? trim($head_description) : $default_data['head_description'];
$head_keywords = isset($head_keywords) ? trim($head_keywords) : $default_data['head_keywords'];
$head_meta = isset($head_meta) ? trim($head_meta) : $default_data['head_meta']; ?>
<?= '<?xml version="1.0" encoding="utf-8"?>' . "\r\n" ?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
  
  <head>
    <meta http-equiv="content-type" content="application/xhtml+xml; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css" />
    <meta name="Generator" content="IndoWapblog, http://your.my.id" />
    <meta name="keywords" content="<?= $head_keywords ?>" />
    <meta name="description" content="<?= $head_description ?>" />
    <link rel="stylesheet" href="<?= base_url('assets/css/mobile.css') ?>" type="text/css" />
    <?= $head_meta . "\r\n" ?>
    <title>
      <?= $head_title . "\r\n" ?>
    </title>
    <link rel="icon" href="<?= base_url('/favicon.ico') ?>" type="image/x-icon" />
    <link rel="shortcut icon" href="<?= base_url('/favicon.ico') ?>" type="image/x-icon" />
  </head>
  
  <body>
    <div class="container">
      <div id="header" class="header">
        <div class="container2">
        <div class="row">
          <div class="col-sm-12">
            <a class="brand" href="<?= site_url('site/index') ?>">
              <img src="<?= base_url('assets/images/logo.png') ?>"/>
            </a>
          </div>
        </div>
        </div>
      </div>
      </div>
      <div id="nav" class="navigation">
        <ul>
          <li class="<?= $controller . '/' . $action == 'site/index' ? 'active' : '' ?>">
            <a href="<?= site_url('site/index') ?>" title="<?= lang('iwb_home') ?>"><?= lang('iwb_home') ?></a>
          </li>
          <?php if ($this->iwb->is_user): ?>
          <li class="<?= $controller == 'messages' ? 'active' : '' ?>">
            <a href="<?= site_url('messages') ?>" title="<?= lang('iwb_messages') ?>"><?= lang('iwb_messages') ?> <?= $this->iwb->user->alert['new_messages'] !=
            0 ? '(' . ($this->iwb->user->alert['new_messages'] > 99 ? '99+' : $this->iwb->user->alert['new_messages']) .
            ')' : '' ?></a>
          </li>
          <li class="<?= $controller == 'dashboard' ? 'active' : '' ?>">
            <a href="<?= site_url('dashboard') ?>" title="<?= lang('iwb_dashboard') ?>"><?= lang('iwb_dashboard') ?></a>
          </li>
          <?php if ($this->iwb->user->alert['notifications'] != 0): ?>
          <li class="<?= $controller == 'notifications' ? 'active' : '' ?>">
            <a href="<?= site_url('notifications') ?>" title="<?= lang('iwb_notifications') ?>"><?= lang('iwb_notifications') ?> <?= $this->iwb->user->alert['notifications'] !=
            0 ? '(' . ($this->iwb->user->alert['notifications'] > 99 ? '99+' : $this->iwb->user->alert['notifications']) .
            ')' : '' ?></a>
          </li>
          <?php endif ?>
          <li class="<?= $controller == 'account' ? 'active' : '' ?> pull-right">
            <a href="<?= site_url('account') ?>" title="<?= esc_html($this->iwb->user->name) ?>"><?= lang('iwb_account') ?></a>
          </li>
          <?php else: ?>
          <li class="<?= $controller . '/' . $action == 'site/login' ? 'active' : '' ?>">
            <a href="<?= site_url('site/login') ?>" title="<?= lang('iwb_login') ?>"><?= lang('iwb_login') ?></a>
          </li>
          <li class="<?= $controller . '/' . $action == 'site/registration' ?
          'active' : '' ?>">
            <a href="<?= site_url('site/registration') ?>" title="<?= lang('iwb_registration') ?>"><?= lang('iwb_registration') ?></a>
          </li>
          <?php endif ?>
        </ul>
      </div>
      <div id="main" class="content">
        <?= $this->breadcrumbs->show() . "\r\n" ?>
        <?php $flashdata = $this->session->flashdata() ?>
        <?php if ($flashdata != null): ?>
        <?php foreach ($flashdata as $flash_key => $flash_val): ?>
        <div class="alert <?= $flash_key ?>">
          <?= $flash_val ?>
        </div>
        <?php endforeach ?>
        <?php endif ?>