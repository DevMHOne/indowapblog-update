<div class="menu-bar">
<ul>
  <li class="<?=($show == 'all' ? 'active' : '')?>">
    <a href="<?=site_url('account/credit/history?show=')?>"><?=lang('account_crd_all')?></a>
  </li>
  <li class="<?=($show == 'in' ? 'active' : '')?>">
    <a href="<?=site_url('account/credit/history?show=in')?>"><?=lang('account_crd_in')?></a>
  </li>
  <li class="<?=($show == 'out' ? 'active' : '')?>">
    <a href="<?=site_url('account/credit/history?show=out')?>"><?=lang('account_crd_out')?></a>
  </li>
</ul>
</div>
<?php if ($total == 0):?>
<div class="alert alert-info">
  <?=lang('account_crd_no_history')?>
</div>
<?php else:?>
<ul class="list-group list-striped">
  <?php foreach ($histories as $history):?>
  <li class="list-group-item">
    <table>
        <tbody>
            <tr>
                <td style="width: 80px;"><?=lang('account_crd_date')?></td><td>: <?=format_date(strtotime($history->date))?></td>
            </tr>
            <tr>
                <td><?=lang('account_crd_h_info')?></td><td>: <?=esc_html($history->info)?></td>
            </tr>
            <tr>
                <td><?=lang('account_crd_in')?></td><td>: <?=$history->credit_in != 0 ? number_format($history->credit_in,2,',','.') : 0 ?></td>
            </tr>
            <tr>
                <td><?=lang('account_crd_out')?></td><td>: <?=$history->credit_out != 0 ? number_format($history->credit_out,2,',','.') : 0 ?></td>
            </tr>
            <tr>
                <td><?=lang('account_crd_msg')?></td><td>: <?=esc_html($history->message)?></td>
            </tr>
        </tbody>
    </table>
  </li>
  <?php endforeach?>
</ul>
<?= pagination_link(site_url('account/credit/history') . '?show='.$show.'&amp;page=',
sql_offset($this->iwb->user_set['offset'], $current_page), $total, $this->iwb->user_set['offset']) ?>
<?php endif?>