<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

class Notifications_model extends CI_Model
{
    protected $data = array();
    private $total = array();
    public $notifications = array();

    public function __construct()
    {
        parent::__construct();
    }

    protected function notice_where()
    {
        $where = "(`users_id` LIKE '%\"" . $this->iwb->user_id . "\"%') AND `users_read` NOT LIKE '%\"" .
            $this->iwb->user_id . "\"%'";
        return $where;
    }

    public function get_total_notifications()
    {
        $total = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . $this->db->
            dbprefix . "notifications` WHERE " . $this->notice_where())->row()->total;
        return $total;
    }

    public function get_notifications($page)
    {
        $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
            "notifications` WHERE " . $this->notice_where() . " ORDER BY `time` DESC LIMIT " .
            sql_offset($this->iwb->user_set['offset'], $page) . ", " . $this->iwb->user_set['offset']);
        return $query->result();
    }

    public function get_message($notice)
    {
        if (method_exists(__class__, 'msg_' . $notice->type))
        {
            $this->total = json_decode($notice->users_id, true);
            return $this->{'msg_' . $notice->type}($notice);
        }
        else
        {
            show_error('Method: ' . __class__ . '::msg_' . $notice->type .
                ' does not exists.');
        }
    }

    private function msg_crd_tc_in($notice)
    {
        $result = '<strong>' . esc_html($notice->val2) .
            '</strong> telah mengirim kredit sebesar <strong>Rp. ' . number_format($notice->
            val1, 2, ',', '.') . '</strong>.';
        return $result;
    }

    private function msg_quiz_answer($notice)
    {
        $result = '<strong>' . esc_html($notice->val1) .
            '</strong> telah menjawab pertanyaan kuis &quot;<strong>' . $notice->val2 .
            '</strong>&quot; dengan benar.';
        return $result;
    }

    private function msg_fr_req($notice)
    {
        $result = '<strong>' . esc_html($notice->val1) . '</strong>';
        if ($this->total["{$this->iwb->user_id}"] > 1)
            $result .= ' and <strong>' . ($this->total["{$this->iwb->user_id}"] - 1) .
                '</strong> other people';
        $result .= ' sending friend requests.';
        return $result;
    }

    private function msg_cb_mod($notice)
    {
        if ($this->total["{$this->iwb->user_id}"] > 1)
        {
            $result = '<strong>' . ($this->total["{$this->iwb->user_id}"]) .
                '</strong> blogs waiting moderation.';
        }
        else
        {
            $result = '<strong>' . ($this->total["{$this->iwb->user_id}"]) .
                '</strong> blog waiting moderation.';
        }
        return $result;
    }

    private function msg_fr_confirm_req($notice)
    {
        $message = '<strong>' . esc_html($notice->val1) .
            '</strong> have confirmed your friend request.';
        return $message;
    }

    private function msg_blog_comments_published($notice)
    {
        $result = '<strong>' . esc_html($notice->val1) . '</strong>';
        if ($this->total["{$this->iwb->user_id}"] > 1)
            $result .= ' and <strong>' . ($this->total["{$this->iwb->user_id}"] - 1) .
                '</strong> other people';
        $result .= ' commented on post <strong>' . esc_html($notice->val2) .
            '</strong><div>' . esc_html($notice->val3) . '</div>';
        return $result;
    }

    private function msg_blog_comments_moderated($notice)
    {
        $result = 'You have <strong>' . $this->total["{$this->iwb->user_id}"] .
            '</strong>';
        $result .= ' comments awaiting moderation on post <strong>' . esc_html($notice->
            val2) . '</strong>';
        return $result;
    }

    private function msg_template_upload($notice)
    {
        $result = '<strong>' . ($this->total["{$this->iwb->user_id}"]) .
            '</strong> template(s) waiting moderation.';
        return $result;
    }

    private function msg_template_reject($notice)
    {
        $result = 'Your template <strong>' . esc_html($notice->val1) .
            '</strong> rejected by Administrator.';
        return $result;
    }

    private function msg_template_delete($notice)
    {
        $result = 'Your template <strong>' . esc_html($notice->val1) .
            '</strong> deleted by Administrator.';
        return $result;
    }

    private function msg_template_confirm($notice)
    {
        $result = 'Your template <strong>' . esc_html($notice->val1) .
            '</strong> has been accepted by Administrator.';
        return $result;
    }

    private function msg_blog_follow($notice)
    {
        $result = '<strong>' . esc_html($notice->val1) . '</strong>';
        if ($this->total["{$this->iwb->user_id}"] > 1)
            $result .= ' and <strong>' . ($this->total["{$this->iwb->user_id}"] - 1) .
                '</strong> other people';
        $result .= ' follow your blog <strong>' . esc_html($notice->val2) . '</strong>.';
        return $result;
    }

    private function msg_fl_new_post($notice)
    {
        $result = '<strong>' . esc_html($notice->val1) .
            '</strong> add a new post <strong>' . esc_html($notice->val2) . '</strong><div>' .
            esc_html($notice->val3) . '</div>';
        return $result;
    }

    private function msg_blog_comments_spam($notice)
    {
        $result = 'You have <strong>' . $this->total["{$this->iwb->user_id}"] .
            '</strong>';
        $result .= ' spam comments on post <strong>' . esc_html($notice->val2) .
            '</strong>';
        return $result;
    }

    public function read($notice)
    {
        $key = $notice->type . $notice->code;
        $users_id = $this->user_read(json_decode($notice->users_id, true));

        if (strpos($notice->users_id, '"' . $this->iwb->user_id . '"') !== false &&
            strpos($notice->users_read, '"' . $this->iwb->user_id . '"') === false)
        {
            if ($notice->auto_delete == 1)
            {
                return $this->db->where('id', $notice->id)->delete('notifications');
            }

            $unread = 0;
            foreach (json_decode($users_id, true) as $uid => $count)
            {
                $unread += $count;
            }
            if ($unread <= 0)
            {
                return $this->db->where('id', $notice->id)->delete('notifications');
            }
            $this->db->where('id', $notice->id)->update('notifications', array('users_id' =>
                    $users_id, 'users_read' => json_encode(array_merge(array($this->iwb->user_id),
                    json_decode($notice->users_read)))));
        }
        $this->notifications[$key] = $notice;
    }

    public function insert($data)
    {
        $key = $data['type'] . $data['code'];
        if (array_key_exists($key, $this->notifications))
        {
            if (!$this->notifications[$key])
            {
                $data['users_id'] = $this->insert_users(json_decode($data['users_id']));
                return $this->db->insert('notifications', $data);
            }
            $notice = $this->notifications[$key];
            $data['users_id'] = $this->merge_users(json_decode($notice->users_id, true),
                json_decode($data['users_id'], true));
            $data['users_read'] = '["' . $this->iwb->user_id . '"]';
            return $this->db->where('id', $notice->id)->update('notifications', $data);
        }

        $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
            "notifications` WHERE `type` = '" . $data['type'] . "' AND `code` = '" . $data['code'] .
            "' LIMIT 1");
        if ($query->num_rows() == 0)
        {
            $this->notifications[$key] = false;
            $data['users_id'] = $this->insert_users(json_decode($data['users_id']));
            return $this->db->insert('notifications', $data);
        }

        $notice = $query->row();
        $this->notifications[$key] = $notice;
        $data['users_id'] = $this->merge_users(json_decode($notice->users_id, true),
            json_decode($data['users_id'], true));
        $data['users_read'] = '["' . $this->iwb->user_id . '"]';
        return $this->db->where('id', $notice->id)->update('notifications', $data);
    }

    private function merge_users($old_users, $new_users)
    {
        $new_users = array_map(function ($val)
        {
            return 1; }
        , array_combine($new_users, $new_users));

        $users = array();
        foreach ($new_users as $user_k => $user_v)
        {
            if (array_key_exists($user_k, $old_users))
            {
                if ($user_k == $this->iwb->user_id)
                {

                    $users["{$user_k}"] = 0;
                }
                else
                {
                    $users["{$user_k}"] = $old_users["{$user_k}"] + 1;
                }
            }
            else
            {
                $users["{$user_k}"] = $user_v;
            }
        }
        return json_encode($users);
    }

    private function insert_users($new_users)
    {
        $users = array_map(function ($val)
        {
            return 1; }
        , array_combine($new_users, $new_users));
        return json_encode($users);
    }

    private function user_read($users)
    {
        if (array_key_exists("-", $users))
        {
            $users["-"] = 0;
        }
        if (array_key_exists(" - ", $users))
        {
            $users[" - "] = 0;
        }
        if (array_key_exists($this->iwb->user_id, $users))
        {
            $users["{$this->iwb->user_id}"] = 0;
        }
        return json_encode($users);
    }
}
