<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Install_update_204
{
    protected $CI;
    protected $version = '2.0.4';

    public function __construct()
    {
        $this->CI = &get_instance();
    }

    public function install($auto = false)
    {
        $this->CI->db->where('set_key', 'iwb_version')->update('settings', array('set_value' =>
                $this->version));
        $this->CI->db->where('set_key', 'iwb_update_url')->update('settings', array('set_value' =>
                'https://raw.githubusercontent.com/achunk17/IndoWapBlog-Update/master/update.json'));
        $this->CI->db->query("CREATE TABLE IF NOT EXISTS `" . $this->db->dbprefix .
            "credit_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `info` text NOT NULL,
  `credit_in` int(10) unsigned NOT NULL DEFAULT '0',
  `credit_out` int(10) unsigned NOT NULL DEFAULT '0',
  `message` varchar(160) NOT NULL DEFAULT '',
  `code` varchar(100) NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;");
        if ($this->CI->iwb->get_setting('credit_top_up_info') == false)
        {
            $this->CI->db->insert('settings', array(
                'set_key' => 'credit_top_up_info',
                'set_value' => 'Silakan hubungi Administrator situs.',
                'autoload' => 'no',
                ));
        }
        unlink(__file__);
        if (!$auto)
        {
            $this->CI->session->set_flashdata('alert-success',
                'Installasi pembaruan IndoWapBlog v' . $this->version .
                ' berhasil diselesaikan.');
            redirect('admin/iwb_update');
        }
    }
}
