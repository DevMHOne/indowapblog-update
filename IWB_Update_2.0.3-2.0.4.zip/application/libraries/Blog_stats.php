<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Blog_stats
{
    protected $CI, $blog;
    protected $data = array();

    public function __construct($blog)
    {
        $this->CI = &get_instance();
        $this->blog = (array )$blog;
    }

    public function analytics()
    {
        $data = array();
        $data['user_id'] = isset($this->blog['author_id']) ? $this->blog['author_id'] :
            $this->blog['user_id'];
        $data['site_id'] = $this->blog['id'];
        $data['remote_ip'] = $this->CI->input->ip_address();
        $data['resource'] = '/' . uri_string();

        $data['platform'] = $this->CI->agent->platform();
        $data['browser'] = $this->CI->agent->browser();
        $data['version'] = $this->CI->agent->version();

        $tz = new DateTimeZone($this->blog['settings']['time_zone']);
        $datetime = new DateTime('now', $tz);
        $data['date'] = $date = $datetime->format('Y-m-d');
        $time = $datetime->format('H:i:s');
        $data['user_agent'] = $this->CI->agent->agent_string();
        $resource = $time . ' ' . $data['resource'];

        $this->CI->db->query("UPDATE `" . $this->CI->db->dbprefix .
            "blog_sites` SET `hits_today` = `hits_today` + 1, `hits_total` = `hits_total` + 1 " .
            "WHERE `id` = '{$data['site_id']}' AND `hits_today_date` = '{$data['date']}'");
        if ($this->CI->db->affected_rows() == 0)
        {
            $this->CI->db->query("UPDATE `" . $this->CI->db->dbprefix .
                "blog_sites` SET `hits_today` = '1', `hits_today_date` = '{$data['date']}', " .
                "`hits_total` = `hits_total` + 1 WHERE `id` = '{$data['site_id']}'");
        }

        $this->CI->db->query("UPDATE `" . $this->CI->db->dbprefix .
            "blog_stats` SET `hits` = `hits` + 1, `resource` = CONCAT(resource, ?, '\\n' ),
            `end_time` = ? WHERE `site_id` = ? AND `date` = ? AND `remote_ip` = ? AND 
            `user_agent` = ? AND TIMEDIFF(?, `start_time`) < '00:30:00' LIMIT 1",
            array(
            $resource,
            $time,
            $data['site_id'],
            $date,
            $data['remote_ip'],
            $data['user_agent'],
            $time,
            ));
        $rows = $this->CI->db->affected_rows();
        if ($rows == 0)
        {
            $data['country'] = $this->determine_country($data['remote_ip']);
            $agn_lng = $this->CI->agent->languages();
            $data['language'] = $agn_lng[0];
            $data['referrer'] = $this->CI->agent->is_referral() ? $this->CI->agent->
                referrer() : '';
            $url = parse_url($data['referrer']);
            $data['referrer'] = $data['referrer'];
            $data['domain'] = isset($url['host']) ? preg_replace('/^www\./', '', $url['host']) :
                '';
            $data['search_terms'] = $this->determine_search_terms($url);
            $data['offset'] = $datetime->getOffset() / 60;

            $query = "INSERT INTO `" . $this->CI->db->dbprefix . "blog_stats` ( ";
            foreach (array_keys($data) as $key)
            {
                if ($key == 'resource')
                    continue;
                $query .= "$key, ";
            }

            $query .= 'hits, resource, start_time, end_time ) VALUES ( ';
            $values = array();
            foreach ($data as $key => $value)
            {
                if ($key == 'resource')
                    continue;
                $query .= "?, ";
                $values[] = $value;
            }
            $query .= "'1', CONCAT(?, '\\n'), ?, ?)";
            $values[] = $resource;
            $values[] = $time;
            $values[] = $time;

            $this->CI->db->query($query, $values);
        }
    }

    private function determine_search_terms($_url)
    {
        if (empty($_url['host']) || empty($_url['query']))
            return '';

        $sniffs = array( // host string, query portion containing search terms, parameterised url to decode
            array(
                'images.google',
                'q',
                'prev'),
            array('yahoo.', 'p'),
            array('yandex.', 'text'),
            array('rambler.', 'words'),
            // generic
            array('.', 'q'),
            array('.', 'query'));

        $search_terms = '';

        foreach ($sniffs as $sniff)
        {
            if (strpos(strtolower($_url['host']), $sniff[0]) !== false)
            {
                parse_str($_url['query'], $q);

                if (isset($sniff[2]) && isset($q[$sniff[2]]))
                {
                    $decoded_url = parse_url($q[$sniff[2]]);
                    if (isset($decoded_url['query']))
                        parse_str($decoded_url['query'], $q);
                }

                if (isset($q[$sniff[1]]))
                {
                    $search_terms = trim(stripslashes($q[$sniff[1]]));
                    break;
                }
            }
        }
        return strtolower($search_terms);
    }

    private function determine_country($_ip)
    {
        if (!function_exists('geoip_open') && !class_exists('GeoIP'))
        {
            include_once (APPPATH . 'third_party/geoip/geoip.php');
        }
        $gi = geoip_open(APPPATH . 'third_party/geoip/GeoIP.dat', GEOIP_STANDARD);
        $result = geoip_country_code_by_addr($gi, $_ip);
        geoip_close($gi);
        if (empty($result))
        {
            $result = 'Unknown';
        }
        return $result;
    }

    public function statistics($month = false, $year = false)
    {
        $this->data['time'] = $time = gmt_to_local(time(), $this->blog['settings']['time_zone']);

        $month = $month ? $month : date('m', $time);
        $year = $year ? $year : date('Y', $time);
        $this->data['days'] = $days = get_days_in_month($month, $year);

        $start_date = $days[0];
        $last = count($days) - 1;
        $end_date = $days[$last];
        $query = $this->CI->db->query("SELECT * FROM `" . $this->CI->db->dbprefix .
            "blog_stats` WHERE `site_id` = ? AND `date` >= ? AND `date` <= ?", array(
            $this->blog['id'],
            $start_date,
            $end_date,
            ));
        $this->data['results'] = $query->result_array();
        return $this->parse_data();
    }

    private function parse_data()
    {
        $pages = $ip_address = $browsers = $platforms = $languages = $countries = $search_terms =
            $domains = $referrers = array();
        $hits = 0;
        $visit_source = array(
            'direct' => 0,
            'referrer' => 0,
            'search_terms' => 0,
            );
        $rows = $this->data['results'];
        foreach ($rows as $row)
        {
            $resources = explode("\n", $row['resource']);
            $hits += $row['hits'];
            if (array_key_exists($row['remote_ip'], $ip_address))
            {
                $ip_address[$row['remote_ip']] = array(
                    'total' => $ip_address[$row['remote_ip']]['total'] + 1,
                    'hits' => $ip_address[$row['remote_ip']]['hits'] + $row['hits'],
                    );
            }
            else
            {
                $ip_address[$row['remote_ip']] = array(
                    'total' => 1,
                    'hits' => $row['hits'],
                    );
            }
            if (array_key_exists($row['browser'], $browsers))
            {
                $browsers[$row['browser']] = array(
                    'total' => $browsers[$row['browser']]['total'] + 1,
                    'hits' => $browsers[$row['browser']]['hits'] + $row['hits'],
                    );
            }
            else
            {
                $browsers[$row['browser']] = array(
                    'total' => 1,
                    'hits' => $row['hits'],
                    );
            }
            if (array_key_exists($row['platform'], $platforms))
            {
                $platforms[$row['platform']] = array(
                    'total' => $platforms[$row['platform']]['total'] + 1,
                    'hits' => $platforms[$row['platform']]['hits'] + $row['hits'],
                    );
            }
            else
            {
                $platforms[$row['platform']] = array(
                    'total' => 1,
                    'hits' => $row['hits'],
                    );
            }
            if (array_key_exists($row['language'], $languages))
            {
                $languages[$row['language']] = array(
                    'total' => $languages[$row['language']]['total'] + 1,
                    'hits' => $languages[$row['language']]['hits'] + $row['hits'],
                    );
            }
            else
            {
                $languages[$row['language']] = array(
                    'total' => 1,
                    'hits' => $row['hits'],
                    );
            }
            if (array_key_exists($row['country'], $countries))
            {
                $countries[$row['country']] = array(
                    'total' => $countries[$row['country']]['total'] + 1,
                    'hits' => $countries[$row['country']]['hits'] + $row['hits'],
                    );
            }
            else
            {
                $countries[$row['country']] = array(
                    'total' => 1,
                    'hits' => $row['hits'],
                    );
            }
            if (!empty($row['search_terms']))
            {
                if (array_key_exists($row['search_terms'], $search_terms))
                {
                    $search_terms[$row['search_terms']] += 1;
                }
                else
                {
                    $search_terms[$row['search_terms']] = 1;
                }
            }
            if (!empty($row['domain']))
            {
                if (array_key_exists($row['domain'], $domains))
                {
                    $domains[$row['domain']] += 1;
                }
                else
                {
                    $domains[$row['domain']] = 1;
                }
            }

            if (!empty($row['referrer']))
            {
                if (array_key_exists($row['referrer'], $referrers))
                {
                    $referrers[$row['referrer']] += 1;
                }
                else
                {
                    $referrers[$row['referrer']] = 1;
                }
            }
            if (isset($row['search_terms']) && isset($row['referrer']))
            {
                if (!empty($row['search_terms']))
                    $visit_source['search_terms']++;
                elseif (!empty($row['referrer']))
                    $visit_source['referrer']++;
                else
                    $visit_source['direct']++;
            }
            foreach ($resources as $r)
            {
                if (empty($r))
                    continue;

                list($time, $resource) = explode(' ', $r, 2);
                $resource = trim($resource);

                if (isset($pages[$resource]))
                    $pages[$resource]++;
                else
                    $pages[$resource] = 1;
            }

        }
        arsort($pages);
        arsort($domains);
        arsort($search_terms);
        arsort($referrers);
        return array(
            'hits' => $hits,
            'visits' => count($pages),
            'unique_ip' => count($ip_address),
            'page_visits' => $pages,
            'ip_address' => $ip_address,
            'browsers' => $browsers,
            'platforms' => $platforms,
            'languages' => $languages,
            'countries' => $countries,
            'search_terms' => $search_terms,
            'domains' => $domains,
            'referrers' => $referrers,
            'visit_source' => $visit_source,
            );
    }
}
