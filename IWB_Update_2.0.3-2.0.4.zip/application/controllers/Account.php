<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Account extends IWB_Controller
{
    protected $account;
    protected $data = array();

    public function __construct()
    {
        parent::__construct();
        if (!$this->iwb->is_user)
        {
            $this->session->set_userdata('login_redirect', current_url());
            redirect('site/login');
            return;
        }
        $this->lang->load('account');
        $this->account = $this->iwb->user;
    }

    public function index()
    {
        $total = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->db->
            dbprefix . "blog_sites` WHERE `user_id` = '" . $this->iwb->user->id . "'")->row()->
            num;

        $data = array();
        $data['total_blogs'] = $total;
        if ($total)
        {
            $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                "blog_sites` WHERE `user_id` = '" . $this->iwb->user->id .
                "' ORDER BY `created` DESC LIMIT " . $this->iwb->user_set['offset'] . ";");
            $data['blogs'] = $query->result();
        }
        else
        {
            $data['blogs'] = null;
        }
        $this->load->library('form_validation');
        if ($this->input->post())
        {
            $this->form_validation->set_rules('status', 'status', 'max_length[60]');
            if ($this->form_validation->run() != false)
            {
                $this->db->where('id', $this->account->id)->update('users', array('status' => $this->
                        input->post('status')));
                $this->session->set_flashdata('alert-success', lang('account_status_updated'));
                redirect('account');
            }
        }
        $this->load->helper('form');
        $this->breadcrumbs->set(lang('iwb_account', '', true));
        $this->load->view('includes/header');
        $this->load->view('account/index', $data);
        $this->load->view('includes/footer');
    }

    public function blog()
    {
        $page = get_current_page();
        $total = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->db->
            dbprefix . "blog_sites` WHERE `user_id` = '" . $this->iwb->user->id . "'")->row()->
            num;

        $data = array();
        $data['total_blogs'] = $total;
        $data['current_page'] = $page;
        if ($total)
        {
            $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                "blog_sites` WHERE `user_id` = '" . $this->iwb->user->id .
                "' ORDER BY `created` DESC LIMIT " . sql_offset($this->iwb->user_set['offset'],
                $page) . ", " . $this->iwb->user_set['offset'] . ";");
            $data['blogs'] = $query->result();
        }
        else
        {
            $data['blogs'] = null;
        }
        $data['redirect_uri'] = $this->get_redirect('dashboard');
        $this->breadcrumbs->set(lang('iwb_account'), 'account');
        $this->breadcrumbs->set(lang('iwb_blog'), '', true);
        $this->load->view('includes/header');
        $this->load->view('account/blog', $data);
        $this->load->view('includes/footer');
    }

    public function switch_blog($id = false)
    {
        if ($id == false || !ctype_digit($id))
        {
            redirect('account/');
        }
        $redirect = $this->input->get('redirect_uri') != null ? esc_html(urldecode($this->
            input->get('redirect_uri'))) : 'dashboard';
        $query = $this->db->get_where('blog_sites', array(
            'id' => $id,
            'user_id' => $this->iwb->user->id,
            ));
        if ($query->num_rows() == 0)
        {
            return $this->display_error(lang('iwb_blog_not_found') . '.');
        }
        $blog = $query->row();
        if ($blog->block == 'yes')
        {
            $this->breadcrumbs->set(lang('iwb_account'), 'account');
            $this->breadcrumbs->set(lang('iwb_blog'), 'account/blog', true);
            $this->breadcrumbs->set(blog_url($blog));
            return $this->display_error(lang('account_blog_blocked'));
        }
        elseif ($blog->mod_reg == 'yes')
        {
            $this->breadcrumbs->set(lang('iwb_account'), 'account');
            $this->breadcrumbs->set(lang('iwb_blog'), 'account/blog', true);
            $this->breadcrumbs->set(blog_url($blog));
            return $this->display_error(lang('account_blog_moderated'));
        }
        $this->session->set_userdata('blog', $id);
        redirect($redirect);
    }

    public function create_blog()
    {
        $this->breadcrumbs->set(lang('iwb_account'), 'account');
        $this->breadcrumbs->set(lang('iwb_blog'), 'account/blog');
        $this->breadcrumbs->set(lang('account_create_blog'), '', true);

        $blog_set = $this->iwb->get_setting(array(
            'domains',
            'diff_time_blog',
            'max_user_blogs',
            'mod_new_blog',
            ));
        $blog_set['mod_new_blog'] = $this->iwb->user->rights == 10 ? 'no' : $blog_set['mod_new_blog'];
        $total = $this->db->where(array('user_id' => $this->iwb->user_id, 'mod_reg' =>
                'yes'))->from('blog_sites')->count_all_results();
        if ($total)
        {
            return $this->display_error(lang('account_blog_mod_prev'));
        }
        if ($this->iwb->user->rights < 10)
        {
            $total = $this->db->where('user_id', $this->iwb->user_id)->from('blog_sites')->
                count_all_results();
            if ($total >= $blog_set['max_user_blogs'])
            {
                return $this->display_error(lang('account_blog_exceed'));
            }
        }
        $this->iwb->set['domains'] = $blog_set['domains'];
        $diff_time = $blog_set['diff_time_blog'];
        $time = time() - (3600 * $diff_time);
        if ($this->iwb->user->rights < 10)
        {
            $last_bl = $this->db->query("SELECT COUNT(*) AS `last` FROM `" . $this->db->
                dbprefix . "blog_sites` WHERE `user_id` = ? AND `created` > ?", array($this->
                    iwb->user->id, $time))->row();
            if ($last_bl->last > 0)
            {
                return $this->display_error(strtr(lang('account_cb_diff_info'), array('{time}' =>
                        $diff_time)));
            }
        }

        $domains = json_decode($this->iwb->set['domains']);
        $this->load->model('blog_model');
        $this->load->library('form_validation');
        if ($this->input->post())
        {
            $data = array(
                'domains' => $domains,
                'subdomain' => url_title(trim($this->input->post('subdomain', true)), 'dash', true),
                'domain' => $this->input->post('domain', true),
                );
            $this->blog_model->set_data($data);
            $rules = $this->blog_model->rules('create');
            $this->form_validation->set_rules($rules);

            if ($this->form_validation->run() != false)
            {
                $subdomain = $this->blog_model->get_data('subdomain');
                $domain = $this->blog_model->get_data('domain');
                $insert_data = array(
                    'user_id' => $this->iwb->user->id,
                    'name' => $subdomain . '.' . $domain,
                    'subdomain' => $subdomain,
                    'domain' => $domain,
                    'mod_reg' => $blog_set['mod_new_blog'],
                    );
                $this->blog_model->create_blog($insert_data);
                $blog_id = $this->db->insert_id();

                if ($blog_set['mod_new_blog'] == 'yes')
                {
                    $query = $this->db->select('id')->where('rights', 10)->limit(1)->get('users');
                    $admin = $query->row();
                    $this->notifications_model->insert(array(
                        'users_id' => '["' . $admin->id . '"]',
                        'users_read' => '["0"]',
                        'type' => 'cb_mod',
                        'code' => 'all',
                        'val1' => '',
                        'val2' => '',
                        'val3' => '',
                        'link' => site_url('admin/blog/moderated'),
                        'time' => time(),
                        ));
                }

                $zip = new ZipArchive();

                @mkdir(FCPATH . 'files/blogs/' . $blog_id . '/media', 0777, true);
                @mkdir(FCPATH . 'files/blogs/' . $blog_id . '/data', 0777, true);
                @mkdir(FCPATH . 'files/blogs/' . $blog_id . '/templates/mobile', 0777, true);
                @$zip->open(APPPATH . 'templates/mobile.zip');
                @$zip->extractTo(FCPATH . 'files/blogs/' . $blog_id . '/templates/mobile');
                @$zip->close();
                @mkdir(FCPATH . 'files/blogs/' . $blog_id . '/templates/touch', 0777, true);
                @mkdir(FCPATH . 'files/blogs/' . $blog_id . '/templates/desktop', 0777, true);
                @$zip->open(APPPATH . 'templates/desktop.zip');
                @$zip->extractTo(FCPATH . 'files/blogs/' . $blog_id . '/templates/desktop');
                @$zip->close();
                $this->db->where('id', $this->iwb->user_id)->update('users', array('site' =>
                        'http://' . $subdomain . '.' . $domain));
                $this->session->set_flashdata('alert-success', lang('account_cb_ok'));
                redirect('account/blog');
            }
        }

        $this->load->helper('form');
        $blog_domains = array();
        foreach ($domains as $domain)
        {
            $blog_domains[$domain] = $domain;
        }

        $this->load->view('includes/header');
        $this->load->view('account/create_blog', array('domains' => $blog_domains));
        $this->load->view('includes/footer');
    }

    public function delete_blog($id = 0)
    {
        $this->breadcrumbs->set(lang('iwb_account'), 'account');
        $this->breadcrumbs->set(lang('iwb_blog'), 'account/blog');
        $this->breadcrumbs->set(lang('account_delete_blog'), '', true);

        $query = $this->db->get_where('blog_sites', array(
            'id' => $id,
            'user_id' => $this->iwb->user_id,
            ));
        if ($query->num_rows() == 0)
        {
            return $this->display_error(lang('account_blog_not_found'));
        }
        $blog = $query->row();
        if ($this->input->post())
        {
            $this->db->where('id', $blog->id)->delete('blog_sites');
            $this->db->where('site_id', $blog->id)->delete('blog_posts');
            $this->db->where('site_id', $blog->id)->delete('blog_comments');
            $this->db->where('site_id', $blog->id)->delete('blog_categories');
            rmdir_recursive(FCPATH . 'files/blogs/' . $blog->id);
            $this->session->set_flashdata('alert-success', lang('account_blog_deleted'));
            redirect('account/blog');
        }
        return $this->confirm(current_url(), lang('account_delete_blog_conf'));
    }

    public function edit($mod = '')
    {
        $this->config->set_item('page_title', lang('account_edit_account'));
        if (isset($mod))
        {
            switch ($mod)
            {
                case 'photo':
                    return $this->edit_photo();
                    break;

                case 'password':
                    return $this->edit_password();
                    break;

                case 'profile':
                    return $this->edit_profile();
                    break;

                default:
                    redirect('account/edit/profile');
                    break;
            }
        }
        else
        {
            redirect('account/edit/general');
        }
    }

    public function settings($mod = 'index')
    {
        $this->config->set_item('page_title', lang('account_account_settings'));

        $mod = strtolower($mod);
        $settings = array(
            'general' => lang('iwb_general'),
            'messages' => lang('iwb_messages'),
            'privacy' => lang('iwb_privacy'),
            );
        if (in_array($mod, array_keys($settings)))
        {
            $method = $mod . '_settings';
            return $this->$method();
        }
        else
        {
            $this->breadcrumbs->set(lang('iwb_account'), 'account');
            $this->breadcrumbs->set(lang('iwb_settings'));

            $this->load->view('includes/header');
            $this->load->view('account/settings/index', array('settings' => $settings));
            $this->load->view('includes/footer');
        }
    }

    private function general_settings()
    {
        $this->load->model('user_model');
        $this->load->library('form_validation');
        $this->load->helper('form');
        if ($this->input->post())
        {
            $inputs = array(
                'offset' => $this->input->post('offset'),
                'time_zone' => $this->input->post('time_zone'),
                );
            $rules = array(
                array(
                    'field' => 'offset',
                    'label' => lang('account_list_per_page'),
                    'rules' => 'required|in_list[5,10,15,20]',
                    ),
                array(
                    'field' => 'time_zone',
                    'label' => lang('account_time_zone'),
                    'rules' => 'required|in_list[' . implode(',', array_keys(timezones())) . ']',
                    ),
                );

            $this->form_validation->set_rules($rules);
            if ($this->form_validation->run() != false)
            {
                $this->user_model->set_data('account', $this->account);
                $this->user_model->update_settings($inputs);
                $this->session->set_flashdata('alert-success', lang('iwb_change_saved'));
                redirect('account/index');
                return;
            }
        }
        $this->breadcrumbs->set(lang('iwb_account'), 'account');
        $this->breadcrumbs->set(lang('iwb_settings'), 'account/settings');
        $this->breadcrumbs->set(lang('iwb_general'));

        $this->load->view('includes/header');
        $this->load->view('account/settings/general');
        $this->load->view('includes/footer');
    }

    private function messages_settings()
    {
        $this->load->model('user_model');
        $this->load->library('form_validation');
        $this->load->helper('form');
        if ($this->input->post())
        {
            $inputs = array(
                'wccm' => $this->input->post('wccm'),
                'gm_refresh' => $this->input->post('gm_refresh'),
                'pm_refresh' => $this->input->post('pm_refresh'),
                'chat_refresh' => $this->input->post('chat_refresh'),
                );
            $rules = array(
                array(
                    'filed' => 'wccm',
                    'label' => lang('account_wccm'),
                    'rules' => 'required|in_list[all,friend]',
                    ),
                array(
                    'field' => 'gm_refresh',
                    'label' => lang('account_gm_auto_refresh'),
                    'rules' => 'required|in_list[0,5,10,15,20,25,30]',
                    ),
                array(
                    'field' => 'pm_refresh',
                    'label' => lang('account_pm_auto_refresh'),
                    'rules' => 'required|in_list[0,5,10,15,20,25,30]',
                    ),
                array(
                    'field' => 'chat_refresh',
                    'label' => lang('account_chat_auto_refresh'),
                    'rules' => 'required|in_list[0,5,10,15,20,25,30]',
                    ),
                );

            $this->form_validation->set_rules($rules);
            if ($this->form_validation->run() != false)
            {
                $this->user_model->set_data('account', $this->account);
                $this->user_model->update_settings($inputs);
                $this->session->set_flashdata('alert-success', lang('iwb_change_saved'));
                redirect('account/index');
                return;
            }
        }
        $this->breadcrumbs->set(lang('iwb_account'), 'account');
        $this->breadcrumbs->set(lang('iwb_settings'), 'account/settings');
        $this->breadcrumbs->set(lang('iwb_messages'));

        $this->load->view('includes/header');
        $this->load->view('account/settings/messages');
        $this->load->view('includes/footer');
    }

    private function privacy_settings()
    {
        $this->load->model('user_model');
        $this->load->library('form_validation');
        $this->load->helper('form');
        if ($this->input->post())
        {
            $inputs = array(
                'show_email' => $this->input->post('show_email'),
                'show_datebirth' => $this->input->post('show_datebirth'),
                'wccm' => $this->input->post('wccm'),
                );
            $rules = array(
                array(
                    'field' => 'show_email',
                    'label' => lang('account_show_email'),
                    'rules' => 'required|in_list[yes,no]',
                    ),
                array(
                    'filed' => 'show_datebirth',
                    'label' => lang('account_show_datebirth'),
                    'rules' => 'required|in_list[yes,no]',
                    ),
                array(
                    'filed' => 'wccm',
                    'label' => lang('account_wccm'),
                    'rules' => 'required|in_list[all,friend]',
                    ),
                );

            $this->form_validation->set_rules($rules);
            if ($this->form_validation->run() != false)
            {
                $this->user_model->set_data('account', $this->account);
                $this->user_model->update_settings($inputs);
                $this->session->set_flashdata('alert-success', lang('iwb_change_saved'));
                redirect('account/index');
                return;
            }
        }
        $this->breadcrumbs->set(lang('iwb_account'), 'account');
        $this->breadcrumbs->set(lang('iwb_settings'), 'account/settings');
        $this->breadcrumbs->set(lang('iwb_privacy'));
        $this->load->view('includes/header');
        $this->load->view('account/settings/privacy');
        $this->load->view('includes/footer');
    }

    private function edit_profile()
    {
        $this->load->model('user_model');
        $this->load->library('form_validation');
        $this->load->helper('form');
        if ($this->input->post())
        {
            $set_data = array(
                'account' => $this->account,
                'name' => trim($this->input->post('name')),
                'gender' => $this->input->post('gender'),
                'datebirth' => $this->input->post('datebirth'),
                'address' => trim(strip_tags($this->security->xss_clean($this->input->post('address')))),
                'email' => trim(strtolower($this->input->post('email'))),
                'about' => trim($this->security->xss_clean($this->input->post('about'))),
                );
            $this->user_model->set_data($set_data);
            $rules = $this->user_model->rules('edit');

            $this->form_validation->set_data($set_data);
            $this->form_validation->set_rules($rules);
            if ($this->form_validation->run() != false)
            {
                $this->user_model->edit();
                $this->session->set_flashdata('alert-success', lang('iwb_change_saved'));
                redirect('account/index');
                return;
            }
        }
        $this->breadcrumbs->set(lang('iwb_account'), 'account');
        $this->breadcrumbs->set(lang('iwb_edit'), 'account/edit');
        $this->breadcrumbs->set(lang('iwb_profile'));

        $this->load->view('includes/header');
        $this->load->view('account/edit/profile');
        $this->load->view('includes/footer');
    }

    private function edit_password()
    {
        $this->load->model('user_model');
        $this->load->library('form_validation');
        $this->load->helper('form');
        if ($this->input->post())
        {
            $set_data = array(
                'account' => $this->account,
                'old_password' => $this->input->post('old_password'),
                'new_password' => $this->input->post('new_password'),
                're_new_password' => $this->input->post('re_new_password'),
                );
            $this->user_model->set_data($set_data);
            $rules = $this->user_model->rules('change_password');

            $this->form_validation->set_rules($rules);
            if ($this->form_validation->run() != false)
            {
                $this->user_model->change_password();
                set_cookie('uid', $this->iwb->user->id, time() + 1209600);
                set_cookie('upw', md5($this->user_model->get_data('new_password')), time() +
                    1209600);
                $this->session->set_flashdata('alert-success', lang('iwb_change_saved'));
                redirect('account/index');
                return;
            }
        }
        $this->breadcrumbs->set(lang('iwb_account'), 'account');
        $this->breadcrumbs->set(lang('iwb_edit'), 'account/edit');
        $this->breadcrumbs->set(lang('iwb_password'));
        $this->load->view('includes/header');
        $this->load->view('account/edit/password');
        $this->load->view('includes/footer');
    }

    private function edit_photo()
    {
        $this->load->helper('form');
        if (isset($_FILES['image']))
        {
            $this->load->library('image_upload');
            $this->image_upload->upload($_FILES['image']);
            if ($this->image_upload->uploaded)
            {

                $this->image_upload->file_new_name_body = $this->iwb->user->id . '-64';

                $this->image_upload->allowed = array(
                    'image/jpeg',
                    'image/gif',
                    'image/png',
                    );
                $this->image_upload->file_max_size = 1024 * 1000; // 1MB
                $this->image_upload->file_overwrite = true;
                $this->image_upload->image_resize = true;
                $this->image_upload->image_x = 64;
                $this->image_upload->image_y = 64;
                $this->image_upload->image_convert = 'png';
                $this->image_upload->process(FCPATH . 'files/users/avatar/');
                if ($this->image_upload->processed)
                {
                    $sizes = array(
                        24,
                        32,
                        48,
                        );
                    for ($i = 0; $i < 3; $i++)
                    {
                        $this->image_upload->file_new_name_body = $this->iwb->user->id . '-' . $sizes[$i];
                        $this->image_upload->file_overwrite = true;
                        $this->image_upload->image_resize = true;
                        $this->image_upload->image_x = $sizes[$i];
                        $this->image_upload->image_y = $sizes[$i];
                        $this->image_upload->image_convert = 'png';
                        $this->image_upload->process(FCPATH . 'files/users/avatar/');
                        @$this->image_upload->processed;
                    }
                    $this->session->set_flashdata('alert-success', lang('account_photo_upload_ok'));
                }
                else
                {
                    $this->session->set_flashdata('alert-danger', lang('account_photo_upload_err'));
                }
                $this->image_upload->clean();
            }
            redirect('account/index');
        }
        $this->breadcrumbs->set(lang('iwb_account'), 'account');
        $this->breadcrumbs->set(lang('iwb_edit'), 'account/edit');
        $this->breadcrumbs->set(lang('iwb_photo'));

        $this->load->view('includes/header');
        $this->load->view('account/edit/photo');
        $this->load->view('includes/footer');
    }

    public function credit($action = '')
    {
        $this->breadcrumbs->set(lang('iwb_account'), 'account');

        if (in_array($action, array(
            'top_up',
            'send',
            'history',
            'withdraw',
            )))
        {
            $method = 'credit_' . $action;
            return $this->$method();
        }

        $this->breadcrumbs->set(lang('iwb_credit'), '', true);

        $this->load->view('includes/header');
        $this->load->view('account/credit/index');
        $this->load->view('includes/footer');
    }

    protected function credit_top_up()
    {
        $this->breadcrumbs->set(lang('iwb_credit'), 'account/credit');
        $this->breadcrumbs->set(lang('account_crd_top_up'), '', true);
        $data = array();
        $data['credit_top_up_info'] = $this->iwb->get_setting('credit_top_up_info');
        $this->load->view('includes/header');
        $this->load->view('account/credit/top_up', $data);
        $this->load->view('includes/footer');
    }

    protected function credit_send()
    {
        $this->breadcrumbs->set(lang('iwb_credit'), 'account/credit');
        $this->breadcrumbs->set(lang('account_crd_send'), '', true);

        if ($this->input->post())
        {
            $this->data['send_credit'] = 1;
            $this->load->library('form_validation');
            $input = array(
                'username' => strtolower(trim($this->input->post('username', true))),
                'credit' => trim($this->input->post('credit', true)),
                'message' => trim($this->input->post('message', true)),
                );
            $this->form_validation->set_data($input);
            $this->form_validation->set_rules('username', lang('iwb_username'),
                'required|callback_username_check');
            $this->form_validation->set_rules('credit', lang('iwb_credit'),
                'required|is_natural|greater_than_equal_to[5000]|less_than_equal_to[' . $this->
                iwb->user->credit . ']');
            $this->form_validation->set_rules('message', lang('account_crd_msg'),
                'max_length[160]');
            if ($this->form_validation->run() != false)
            {
                $this->db->query("UPDATE `" . $this->db->dbprefix .
                    "users` SET `credit` = `credit` - ? WHERE `id` = ?", array(
                    $input['credit'],
                    $this->iwb->user_id,
                    ));
                $this->db->query("UPDATE `" . $this->db->dbprefix .
                    "users` SET `credit` = `credit` + ? WHERE `username` = ?", array(
                    $input['credit'],
                    $input['username'],
                    ));
                $date = date_sql(time());
                $this->db->insert('credit_history', array(
                    'user_id' => $this->iwb->user->id,
                    'info' => 'Transfer kredit kepada ' . $this->data['credit_send2user']['name'],
                    'credit_out' => $input['credit'],
                    'message' => $input['message'],
                    'code' => 'TC-TO-' . $this->data['credit_send2user']['id'],
                    'date' => $date,
                    ));
                $this->db->insert('credit_history', array(
                    'user_id' => $this->data['credit_send2user']['id'],
                    'info' => 'Transfer kredit dari ' . $this->iwb->user->name,
                    'credit_in' => $input['credit'],
                    'message' => $input['message'],
                    'code' => 'TC-FROM-' . $this->iwb->user->id,
                    'date' => $date,
                    ));
                $this->notifications_model->insert(array(
                    'users_id' => '["' . $this->data['credit_send2user']['id'] . '"]',
                    'users_read' => '["0"]',
                    'type' => 'crd_tc_in',
                    'code' => time(),
                    'val1' => $input['credit'],
                    'val2' => $this->iwb->user->name,
                    'val3' => '',
                    'auto_delete' => 1,
                    'link' => site_url('account/credit/history?show=in'),
                    'time' => time(),
                    ));

                $this->session->set_flashdata('alert-success', strtr(lang('account_crd_send_ok'),
                    array(
                    '{CREDIT}' => 'Rp. ' . number_format($input['credit'], 2, ',', '.'),
                    '{USER}' => '<a href="' . site_url('user/' . $input['username']) . '">' .
                        esc_html($this->data['credit_send2user']['name']) . '</a>.',
                    )));
                redirect('account/credit');
            }
        }

        $data = array();
        $this->load->helper('form');
        $this->load->view('includes/header');
        $this->load->view('account/credit/send', $data);
        $this->load->view('includes/footer');
    }

    public function username_check($str = '')
    {
        if (!isset($this->data['send_credit']))
        {
            show_404(lang('iwb_error_404'));
            return;
        }
        $user = get_user_by_username($str);
        if ($user == false)
        {
            $this->form_validation->set_message('username_check', strtr(lang('account_crd_u404'),
                array('{USER}' => esc_html($str))));
            return false;
        }
        elseif ($user->id == $this->iwb->user_id)
        {
            $this->form_validation->set_message('username_check', lang('account_crd_self'));
            return false;
        }
        else
        {
            $this->data['credit_send2user'] = (array )$user;
            return true;
        }
    }

    protected function credit_history()
    {
        $this->breadcrumbs->set(lang('iwb_credit'), 'account/credit');
        $this->breadcrumbs->set(lang('account_crd_history'), '', true);

        $data = array();
        $data['show'] = $this->input->get('show');
        if ($data['show'] == 'in')
        {
            $filter = " AND `credit_in` != 0";
        }
        elseif ($data['show'] == 'out')
        {
            $filter = " AND `credit_out` != 0";
        }
        else
        {
            $data['show'] = 'all';
            $filter = '';
        }
        $data['current_page'] = get_current_page();
        $data['total'] = $this->db->query("SELECT COUNT(*) AS `num` FROM `" . $this->db->
            dbprefix . "credit_history` WHERE `user_id` = '" . $this->iwb->user->id . "'" .
            $filter)->row()->num;
        if ($data['total'])
        {
            $query = $this->db->query("SELECT * FROM `" . $this->db->dbprefix .
                "credit_history` WHERE `user_id` = '" . $this->iwb->user->id . "'" . $filter .
                " ORDER BY `date` DESC LIMIT " . sql_offset($this->iwb->user_set['offset'], $data['current_page']) .
                ", " . $this->iwb->user_set['offset'] . ";");
            $data['histories'] = $query->result();
        }
        else
        {
            $data['histories'] = null;
        }
        $this->load->view('includes/header');
        $this->load->view('account/credit/history', $data);
        $this->load->view('includes/footer');
    }

    protected function credit_withdraw()
    {
        $this->breadcrumbs->set(lang('iwb_credit'), 'account/credit');
        $this->breadcrumbs->set(lang('account_crd_withdraw'), '', true);
        $data = array();
        $this->load->view('includes/header');
        $this->load->view('account/credit/withdraw', $data);
        $this->load->view('includes/footer');
    }
}
