<?php

/**
 * @package IndoWapBlog
 * @version VERSION.md (see attached file)
 * @copyright (C) 2011 - 2015 IndoWapBlog
 * @license LICENSE.md (see attached file)
 * @author Achunk JealousMan (http://facebook.com/achunks)
 */

if (!function_exists('get_current_page'))
{
    function get_current_page($default = 1)
    {
        $page = abs(intval(get_instance()->input->get_post('page')));
        if ($page == 0)
        {
            $page = $default;
        }
        return $page;
    }
}

if (!function_exists('date_sql'))
{
    function date_sql($time)
    {
        return date('Y-m-d H:i:s', $time);
    }
}

if (!function_exists('star_rating'))
{
    function star_rating($rating = 0, $url = '')
    {
        $stars = array(
            'star-empty.png',
            'star-empty.png',
            'star-empty.png',
            'star-empty.png',
            'star-empty.png',
            );
        switch ($rating)
        {
            case 0:
                break;

            case 1:
                $stars[0] = 'star-full.png';
                break;

            case 2;
                $stars[0] = $stars[1] = 'star-full.png';
                break;

            case 3;
                $stars[0] = $stars[1] = $stars[2] = 'star-full.png';
                break;

            case 4;
                $stars[0] = $stars[1] = $stars[2] = $stars[3] = 'star-full.png';
                break;

            case 5;
            default:
                $stars[0] = $stars[1] = $stars[2] = $stars[3] = $stars[4] = 'star-full.png';
                break;
        }
        $out = '';
        if ($url == '')
        {
            foreach ($stars as $star)
            {
                $out .= '<span><img src="' . base_url('assets/images/' . $star) . '"></span>';
            }
        }
        else
        {
            foreach ($stars as $num => $star)
            {
                $out .= '<a href="' . $url . 'rate=' . ($num + 1) . '"><img src="' . base_url('assets/images/' .
                    $star) . '"></a>';
            }
        }

        return $out;
    }
}
if (!function_exists('get_days_in_month'))
{
    function get_days_in_month($month, $year)
    {
        $days = array();
        for ($d = 1; $d <= 31; $d++)
        {
            $time1 = mktime(12, 0, 0, $month, $d, $year);
            if (date('m', $time1) == $month)
            {
                $days[] = date('Y-m-d', $time1);
            }
        }
        return $days;
    }
}

if (!function_exists('get_week_date'))
{
    function get_week_date($week, $year)
    {
        $dto = new DateTime();
        $dto->setISODate($year, $week);
        $ret = array();
        for ($i = 1; $i <= 7; $i++)
        {
            $ret[] = $dto->format('Y-m-d');
            $dto->modify("+1 days");
        }
        return $ret;
    }
}

if (!function_exists('get_week_number'))
{
    function get_week_number($date)
    {
        $dto = new DateTime($date);
        return $dto->format('W');
    }
}

if (!function_exists('get_blog_images'))
{
    function get_blog_files($blog_id)
    {
        $files = array();
        $glob = glob(FCPATH . "files/blogs/" . $blog_id . "/media/*");
        if (count($glob) > 0)
        {
            foreach ($glob as $file)
            {
                $files[] = basename($file);
            }
        }
        return $files;
    }
}
if (!function_exists('image_types'))
{
    function image_types($dot = true)
    {
        if ($dot == true)
        {
            return array(
                '.jpg',
                '.png',
                '.gif',
                '.jpeg',
                '.ico',
                '.bmp',
                );
        }
        return array(
            'jpg',
            'png',
            'gif',
            'jpeg',
            'ico',
            'bmp',
            );
    }
}
if (!function_exists('word_count'))
{
    function word_count($text, $find = array())
    {
        $probability = 0;
        $text = strtolower($text);
        foreach ($find as $word)
        {
            $count = substr_count($text, $word);
            $probability += $count;
        }
        return $probability;

    }
}

if (!function_exists('file_type_icon'))
{
    function file_type_icon($ext)
    {
        if (file_exists(FCPATH . 'images/systems/' . $ext . '.png'))
        {
            return base_url('images/systems/' . $ext . '.png');
        }
        return base_url('images/systems/_blank.png');
    }

}

if (!function_exists('rmdir_recursive'))
{
    function rmdir_recursive($dir)
    {
        if (is_dir($dir))
        {
            $objects = scandir($dir);
            foreach ($objects as $object)
            {
                if ($object != "." && $object != "..")
                {
                    if (filetype($dir . "/" . $object) == "dir")
                        rmdir_recursive($dir . "/" . $object);
                    else
                        unlink($dir . "/" . $object);
                }
            }
            reset($objects);
            rmdir($dir);
        }
    }
}

if (!function_exists('mutual_friend'))
{
    function mutual_friend($count, $default = false)
    {
        if ((int)$count == 1)
        {
            return $count . ' ' . lang('iwb_mutual_friend');
        }
        elseif ((int)$count > 1)
        {
            return $count . ' ' . lang('iwb_mutual_friends');
        }
        elseif ($default != false)
        {
            return $default;
        }
        else
        {
            return lang('iwb_no_mutual_friend');
        }
    }
}
if (!function_exists('str_link'))
{
    function str_link($str)
    {
        setlocale(LC_ALL, 'en_US.UTF8');
        $plink = iconv('UTF-8', 'ASCII//TRANSLIT', $str);
        $plink = preg_replace("/[^a-zA-Z0-9\/_| -]/", '', $plink);
        $plink = strtolower(trim($plink, '-'));
        $plink = preg_replace("/[\/_| -]+/", '-', $plink);

        return $plink;
    }
}

if (!function_exists('str_tags'))
{
    function str_tags($str)
    {
        $str_split = preg_split("/[,]+/", $str);
        $tags = array();
        foreach ($str_split as $split)
        {
            $split = trim($split);
            if ($split != '')
            {
                $tags[] = str_link($split);
            }
        }
        return $tags;
    }
}

if (!function_exists('blog_url'))
{
    function blog_url($blog)
    {
        $blog = (object)$blog;
        return 'http://' . $blog->subdomain . '.' . $blog->domain;
    }
}

if (!function_exists('get_blog_settings'))
{
    function get_blog_settings($settings)
    {
        return array_merge(get_instance()->iwb->default_blog_settings(), json_decode($settings, true));
    }
}
if (!function_exists('render_data'))
{
    function render_data($data = null)
    {
        $CI = get_instance();
        $controller = strtolower($CI->router->fetch_class());
        $action = strtolower($CI->router->fetch_method());

        $default_data = array(
            'head_meta' => '',
            'head_title' => $controller == $CI->router->default_controller && $action ==
                'index' ? esc_html($CI->iwb->set['site_name']) : (router2word($controller) . ($action ==
                'index' ? '' : ' &gt; ' . router2word($action))) . ' | ' . esc_html($CI->iwb->
                set['site_name']),
            'head_description' => '',
            'head_keywords' => '',
            );
        if (!is_null($data) && is_array($data))
            return array_merge($default_data, $data);

        return $default_data;
    }
}

if (!function_exists('router2word'))
{
    function router2word($str)
    {
        return ucwords(str_replace('_', ' ', str_replace('-', ' ', $str)));
    }
}

if (!function_exists('user_photo'))
{
    function user_photo($id, $size = 64)
    {
        if (!file_exists(FCPATH . 'files/users/avatar/' . $id . '-' . $size . '.png'))
        {
            return base_url('files/users/avatar/default-' . $size . '.png');
        }
        return base_url('files/users/avatar/' . $id . '-' . $size . '.png');
    }
}
if (!function_exists('get_user'))
{
    function get_user($id_name, $select = '*')
    {
        $CI = get_instance();
        if ($user = $CI->db->select($select)->where('id', $id_name)->or_where('username',
            $id_name)->limit(1)->get('users')->result())
        {
            return $user[0];
        }
        return false;
    }
}

if (!function_exists('get_user_by_id'))
{
    function get_user_by_id($id, $select = '*', $friends = false)
    {
        $CI = get_instance();
        $CI->db->select($select);
        if ($friends)
        {
            $CI->db->join('friends', 'friends.user_id = users.id', 'left');
        }
        $CI->db->where('users.id', abs(intval($id)));
        $query = $CI->db->get('users');
        if ($query->num_rows() == 0)
        {
            return false;
        }
        return $query->row();
    }
}
if (!function_exists('get_user_by_username'))
{
    function get_user_by_username($username, $select = '*', $friends = false)
    {
        $CI = get_instance();
        $CI->db->select($select);
        if ($friends)
        {
            $CI->db->join('friends', 'friends.user_id = users.id', 'left');
        }
        $CI->db->where('users.username', $username);
        $query = $CI->db->get('users');
        if ($query->num_rows() == 0)
        {
            return false;
        }
        return $query->row();
    }
}
if (!function_exists('sql_offset'))
{
    function sql_offset($limit, $page)
    {
        $page = abs(intval($page));
        $page = $page <= 1 ? 1 : $page;
        return $page * $limit - $limit;
    }
}
if (!function_exists('pagination_link'))
{
    function pagination_link($url, $offset, $total, $per_page, $query_string = '')
    {
        if ($total <= $per_page)
            return '';
        $out = array();
        $out[] = '<ul class="pagination">';
        $neighbors = 2;
        if ($offset >= $total)
            $offset = max(0, $total - (($total % $per_page) == 0 ? $per_page : ($total % $per_page)));
        else
            $offset = max(0, (int)$offset - ((int)$offset % (int)$per_page));
        $base_link = '<li><a href="' . strtr($url, array('%' => '%%')) . '%d' . strtr($query_string,
            array('%' => '%%')) . '">%s</a></li>';
        $out[] = $offset == 0 ? '<li class="disabled"><span>&laquo;</span></li>' :
            sprintf($base_link, $offset / $per_page, '&laquo;');
        if ($offset > $per_page * $neighbors)
            $out[] = sprintf($base_link, 1, '1');
        if ($offset > $per_page * ($neighbors + 1))
            $out[] = '<li class="disabled"><span>...</span></li>';
        for ($n_count = $neighbors; $n_count >= 1; $n_count--)
            if ($offset >= $per_page * $n_count)
            {
                $tmp_start = $offset - $per_page * $n_count;
                $out[] = sprintf($base_link, $tmp_start / $per_page + 1, $tmp_start / $per_page +
                    1);
            }
        $out[] = '<li class="active"><span>' . ($offset / $per_page + 1) .
            '</span></li>';
        $tmp_max_pages = (int)(($total - 1) / $per_page) * $per_page;
        for ($n_count = 1; $n_count <= $neighbors; $n_count++)
            if ($offset + $per_page * $n_count <= $tmp_max_pages)
            {
                $tmp_start = $offset + $per_page * $n_count;
                $out[] = sprintf($base_link, $tmp_start / $per_page + 1, $tmp_start / $per_page +
                    1);
            }
        if ($offset + $per_page * ($neighbors + 1) < $tmp_max_pages)
            $out[] = '<li class="disabled"><span>...</span></li>';
        if ($offset + $per_page * $neighbors < $tmp_max_pages)
            $out[] = sprintf($base_link, $tmp_max_pages / $per_page + 1, $tmp_max_pages / $per_page +
                1);
        if ($offset + $per_page < $total)
        {
            $display_page = ($offset + $per_page) > $total ? $total : ($offset / $per_page +
                2);
            $out[] = sprintf($base_link, $display_page, '&raquo;');
        }
        else
        {
            $out[] = '<li class="disabled"><span>&raquo;</span></li>';
        }
        $out[] = '</ul>';
        return implode(' ', $out);
    }

}

if (!function_exists('category_link'))
{
    function category_link($url, $category_json, $category_array)
    {
        $links = array();
        $category_json = json_decode($category_json);
        foreach ($category_json as $key)
        {
            if (array_key_exists($key, $category_array))
            {
                $links[] = '<a href="' . $url . $key . '">' . esc_html($category_array[$key]) .
                    '</a>';
            }
        }
        return $links;
    }
}

if (!function_exists('tags_link'))
{
    function tags_link($url, $tags, $query_string = '')
    {
        $links = array();
        $tags_json = json_decode($tags);
        foreach ($tags_json as $tag)
        {
            $links[] = '<a href="' . $url . $tag . $query_string . '">' . strtolower(router2word
                ($tag)) . '</a>';
        }
        return $links;
    }
}

if (!function_exists('timezone_city'))
{
    function timezone_city()
    {
        $timezones = array(
            'Pacific/Midway' => "(GMT-11:00) Midway Island",
            'US/Samoa' => "(GMT-11:00) Samoa",
            'US/Hawaii' => "(GMT-10:00) Hawaii",
            'US/Alaska' => "(GMT-09:00) Alaska",
            'US/Pacific' => "(GMT-08:00) Pacific Time (US &amp; Canada)",
            'America/Tijuana' => "(GMT-08:00) Tijuana",
            'US/Arizona' => "(GMT-07:00) Arizona",
            'US/Mountain' => "(GMT-07:00) Mountain Time (US &amp; Canada)",
            'America/Chihuahua' => "(GMT-07:00) Chihuahua",
            'America/Mazatlan' => "(GMT-07:00) Mazatlan",
            'America/Mexico_City' => "(GMT-06:00) Mexico City",
            'America/Monterrey' => "(GMT-06:00) Monterrey",
            'Canada/Saskatchewan' => "(GMT-06:00) Saskatchewan",
            'US/Central' => "(GMT-06:00) Central Time (US &amp; Canada)",
            'US/Eastern' => "(GMT-05:00) Eastern Time (US &amp; Canada)",
            'US/East-Indiana' => "(GMT-05:00) Indiana (East)",
            'America/Bogota' => "(GMT-05:00) Bogota",
            'America/Lima' => "(GMT-05:00) Lima",
            'America/Caracas' => "(GMT-04:30) Caracas",
            'Canada/Atlantic' => "(GMT-04:00) Atlantic Time (Canada)",
            'America/La_Paz' => "(GMT-04:00) La Paz",
            'America/Santiago' => "(GMT-04:00) Santiago",
            'Canada/Newfoundland' => "(GMT-03:30) Newfoundland",
            'America/Buenos_Aires' => "(GMT-03:00) Buenos Aires",
            'Greenland' => "(GMT-03:00) Greenland",
            'Atlantic/Stanley' => "(GMT-02:00) Stanley",
            'Atlantic/Azores' => "(GMT-01:00) Azores",
            'Atlantic/Cape_Verde' => "(GMT-01:00) Cape Verde Is.",
            'Africa/Casablanca' => "(GMT) Casablanca",
            'Europe/Dublin' => "(GMT) Dublin",
            'Europe/Lisbon' => "(GMT) Lisbon",
            'Europe/London' => "(GMT) London",
            'Africa/Monrovia' => "(GMT) Monrovia",
            'Europe/Amsterdam' => "(GMT+01:00) Amsterdam",
            'Europe/Belgrade' => "(GMT+01:00) Belgrade",
            'Europe/Berlin' => "(GMT+01:00) Berlin",
            'Europe/Bratislava' => "(GMT+01:00) Bratislava",
            'Europe/Brussels' => "(GMT+01:00) Brussels",
            'Europe/Budapest' => "(GMT+01:00) Budapest",
            'Europe/Copenhagen' => "(GMT+01:00) Copenhagen",
            'Europe/Ljubljana' => "(GMT+01:00) Ljubljana",
            'Europe/Madrid' => "(GMT+01:00) Madrid",
            'Europe/Paris' => "(GMT+01:00) Paris",
            'Europe/Prague' => "(GMT+01:00) Prague",
            'Europe/Rome' => "(GMT+01:00) Rome",
            'Europe/Sarajevo' => "(GMT+01:00) Sarajevo",
            'Europe/Skopje' => "(GMT+01:00) Skopje",
            'Europe/Stockholm' => "(GMT+01:00) Stockholm",
            'Europe/Vienna' => "(GMT+01:00) Vienna",
            'Europe/Warsaw' => "(GMT+01:00) Warsaw",
            'Europe/Zagreb' => "(GMT+01:00) Zagreb",
            'Europe/Athens' => "(GMT+02:00) Athens",
            'Europe/Bucharest' => "(GMT+02:00) Bucharest",
            'Africa/Cairo' => "(GMT+02:00) Cairo",
            'Africa/Harare' => "(GMT+02:00) Harare",
            'Europe/Helsinki' => "(GMT+02:00) Helsinki",
            'Europe/Istanbul' => "(GMT+02:00) Istanbul",
            'Asia/Jerusalem' => "(GMT+02:00) Jerusalem",
            'Europe/Kiev' => "(GMT+02:00) Kyiv",
            'Europe/Minsk' => "(GMT+02:00) Minsk",
            'Europe/Riga' => "(GMT+02:00) Riga",
            'Europe/Sofia' => "(GMT+02:00) Sofia",
            'Europe/Tallinn' => "(GMT+02:00) Tallinn",
            'Europe/Vilnius' => "(GMT+02:00) Vilnius",
            'Asia/Baghdad' => "(GMT+03:00) Baghdad",
            'Asia/Kuwait' => "(GMT+03:00) Kuwait",
            'Africa/Nairobi' => "(GMT+03:00) Nairobi",
            'Asia/Riyadh' => "(GMT+03:00) Riyadh",
            'Asia/Tehran' => "(GMT+03:30) Tehran",
            'Europe/Moscow' => "(GMT+04:00) Moscow",
            'Asia/Baku' => "(GMT+04:00) Baku",
            'Europe/Volgograd' => "(GMT+04:00) Volgograd",
            'Asia/Muscat' => "(GMT+04:00) Muscat",
            'Asia/Tbilisi' => "(GMT+04:00) Tbilisi",
            'Asia/Yerevan' => "(GMT+04:00) Yerevan",
            'Asia/Kabul' => "(GMT+04:30) Kabul",
            'Asia/Karachi' => "(GMT+05:00) Karachi",
            'Asia/Tashkent' => "(GMT+05:00) Tashkent",
            'Asia/Kolkata' => "(GMT+05:30) Kolkata",
            'Asia/Kathmandu' => "(GMT+05:45) Kathmandu",
            'Asia/Yekaterinburg' => "(GMT+06:00) Ekaterinburg",
            'Asia/Almaty' => "(GMT+06:00) Almaty",
            'Asia/Dhaka' => "(GMT+06:00) Dhaka",
            'Asia/Novosibirsk' => "(GMT+07:00) Novosibirsk",
            'Asia/Bangkok' => "(GMT+07:00) Bangkok",
            'Asia/Jakarta' => "(GMT+07:00) Jakarta",
            'Asia/Krasnoyarsk' => "(GMT+08:00) Krasnoyarsk",
            'Asia/Chongqing' => "(GMT+08:00) Chongqing",
            'Asia/Hong_Kong' => "(GMT+08:00) Hong Kong",
            'Asia/Kuala_Lumpur' => "(GMT+08:00) Kuala Lumpur",
            'Australia/Perth' => "(GMT+08:00) Perth",
            'Asia/Singapore' => "(GMT+08:00) Singapore",
            'Asia/Taipei' => "(GMT+08:00) Taipei",
            'Asia/Ulaanbaatar' => "(GMT+08:00) Ulaan Bataar",
            'Asia/Urumqi' => "(GMT+08:00) Urumqi",
            'Asia/Irkutsk' => "(GMT+09:00) Irkutsk",
            'Asia/Seoul' => "(GMT+09:00) Seoul",
            'Asia/Tokyo' => "(GMT+09:00) Tokyo",
            'Australia/Adelaide' => "(GMT+09:30) Adelaide",
            'Australia/Darwin' => "(GMT+09:30) Darwin",
            'Asia/Yakutsk' => "(GMT+10:00) Yakutsk",
            'Australia/Brisbane' => "(GMT+10:00) Brisbane",
            'Australia/Canberra' => "(GMT+10:00) Canberra",
            'Pacific/Guam' => "(GMT+10:00) Guam",
            'Australia/Hobart' => "(GMT+10:00) Hobart",
            'Australia/Melbourne' => "(GMT+10:00) Melbourne",
            'Pacific/Port_Moresby' => "(GMT+10:00) Port Moresby",
            'Australia/Sydney' => "(GMT+10:00) Sydney",
            'Asia/Vladivostok' => "(GMT+11:00) Vladivostok",
            'Asia/Magadan' => "(GMT+12:00) Magadan",
            'Pacific/Auckland' => "(GMT+12:00) Auckland",
            'Pacific/Fiji' => "(GMT+12:00) Fiji",
            );
        return $timezones;
    }
}

if (!function_exists('format_date'))
{
    function format_date($time)
    {
        get_instance()->lang->load('calendar');
        return strtr(mdate('%d %M %Y - %H:%i', gmt_to_local($time, get_instance()->iwb->
            user_set['time_zone'])), array(
            'Jan' => lang('cal_jan'),
            'Feb' => lang('cal_feb'),
            'Mar' => lang('cal_mar'),
            'Apr' => lang('cal_apr'),
            'May' => lang('cal_may'),
            'Jun' => lang('cal_jun'),
            'Jul' => lang('cal_jul'),
            'Aug' => lang('cal_aug'),
            'Sep' => lang('cal_sep'),
            'Oct' => lang('cal_oct'),
            'Nov' => lang('cal_nov'),
            'Dec' => lang('cal_dec'),
            ));
    }
}

if (!function_exists('bbsm'))
{
    function bbsm($text)
    {
        get_instance()->load->helper('smiley');
        $text = esc_html($text);
        $text = nl2br($text);
        $text = auto_link($text, 'email');
        $text = auto_link($text, 'url', true);
        $text = word_wrap($text, 25);
        $text = parse_smileys($text, base_url('images/smileys/'));
        return $text;
    }
}

if (!function_exists('esc_html'))
{
    function esc_html($str)
    {
        return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('time_ago'))
{
    function time_ago($time)
    {
        $now = time();
        if (($now - $time) <= 43200)
        {
            return strtolower(timespan($time) . ' ' . lang('iwb_time_ago'));
        }
        return format_date($time);
    }
}

if (!function_exists('random_str'))
{
    function random_str($length = 6)
    {
        $vowels = 'aeuy';
        $consonants = 'bdghjmnpqrstvzBDGHJLMNPQRSTVWXZ23456789';
        $str = '';
        $alt = time() % 2;
        for ($i = 0; $i < $length; $i++)
        {
            if ($alt == 1)
            {
                $str .= $consonants[(rand() % strlen($consonants))];
                $alt = 0;
            }
            else
            {
                $str .= $vowels[(rand() % strlen($vowels))];
                $alt = 1;
            }
        }
        return $str;
    }
}
